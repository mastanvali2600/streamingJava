package com.reactive.cricScore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CricScoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
