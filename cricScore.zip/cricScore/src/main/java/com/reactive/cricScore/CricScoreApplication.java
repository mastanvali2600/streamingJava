package com.reactive.cricScore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CricScoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(CricScoreApplication.class, args);
	}

}
