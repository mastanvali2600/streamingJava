package org.trackme.smscenter;

import org.appTracker.R;

import android.app.Activity;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
 
public class MessageBox extends Activity implements OnClickListener {
 
    //  GUI Widget
    Button btnSent, btnInbox, btnDraft;
    TextView lblMsg, lblNo;
    ListView lvMsg;
 
    // Cursor Adapter
    SimpleCursorAdapter adapter;
 

    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.message_box_activity);
 
        // Init GUI Widget
        btnInbox = (Button) findViewById(R.id.btnInbox);
        btnInbox.setOnClickListener(this);
 
        btnSent = (Button)findViewById(R.id.btnSentBox);
        btnSent.setOnClickListener(this);
 
        btnDraft = (Button)findViewById(R.id.btnDraft);
        btnDraft.setOnClickListener(this);
 
        lvMsg = (ListView) findViewById(R.id.lvMsg);
 
    }
 
    @SuppressWarnings("deprecation")
	@Override
    public void onClick(View v) {
 
        if (v == btnInbox) {
 
            // Create Inbox box URI
            Uri inboxURI = Uri.parse("content://sms/inbox");
            /**
             
        0: _id
        1: thread_id
        2: address
        3: person
        4: date
        5: protocol
        6: read   
        7: status
        8: type
        9: reply_path_present
        10: subject
        11: body
        12: service_center
        13: locked
           
             * */
            // List required columns
            String[] reqCols = new String[] { "_id", "address", "body", };
 
            // Get Content Resolver object, which will deal with Content Provider
            ContentResolver cr = getContentResolver();
 
            // Fetch Inbox SMS Message from Built-in Content Provider
            Cursor c           = cr.query(inboxURI, reqCols, null, null, null);
 
            // Attached Cursor with adapter and display in listview
            adapter = new SimpleCursorAdapter(this, R.layout.row, c, new String[] { "body", "address" }, new int[] {R.id.lblMsg, R.id.lblNumber });
            lvMsg.setAdapter(adapter);
 
        }
 
        if(v==btnSent)
        {
 
            // Create Sent box URI
            Uri sentURI = Uri.parse("content://sms/sent");
 
            // List required columns
            String[] reqCols = new String[] { "_id", "address", "body" };
 
            // Get Content Resolver object, which will deal with Content Provider
            ContentResolver cr = getContentResolver();
 
            // Fetch Sent SMS Message from Built-in Content Provider
            Cursor c = cr.query(sentURI, reqCols, null, null, null);
 
            // Attached Cursor with adapter and display in listview
            adapter = new SimpleCursorAdapter(this, R.layout.row, c, new String[] { "body", "address" }, new int[] { R.id.lblMsg, R.id.lblNumber });
            lvMsg.setAdapter(adapter);
 
        }
 
        if(v==btnDraft)
        {
            // Create Draft box URI
            Uri draftURI = Uri.parse("content://sms/draft");
 
            // List required columns
            String[] reqCols = new String[] { "_id", "address", "body" };
 
            // Get Content Resolver object, which will deal with Content Provider
            ContentResolver cr = getContentResolver();
 
            // Fetch Sent SMS Message from Built-in Content Provider
            Cursor c = cr.query(draftURI, reqCols, null, null, null);
 
            // Attached Cursor with adapter and display in listview
            adapter = new SimpleCursorAdapter(this, R.layout.row, c, new String[] { "body", "address" }, new int[] {  R.id.lblMsg, R.id.lblNumber });
            lvMsg.setAdapter(adapter);
 
        }
 
    }
}