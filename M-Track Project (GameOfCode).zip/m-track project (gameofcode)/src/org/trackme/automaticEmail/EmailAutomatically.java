package org.trackme.automaticEmail;
import org.appTracker.R;

import android.os.Bundle;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;



public class EmailAutomatically extends Activity {
BroadcastReceiver mReceiver;
String TAG = "testing";


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.automatic_email_activity);
        
	
		 Button addImage = (Button) findViewById(R.id.send_email); 
		 
		  addImage.setOnClickListener(new View.OnClickListener() { 
		    public void onClick(View view) { 
		    
		    	
		      Mail m = new Mail("luckyrana321@gmail.com", "jaimatanaubahi"); 
		 
		      String[] toArr = {"luckyrana321@gmail.com", "luckyrana321@gmail.com"}; 
		      m.set_to(toArr); 
		      m.set_from("wooo@wooo.com"); 
		      m.set_subject("This is an email sent using my Mail JavaMail wrapper from an Android device."); 
		      m.setBody("Email body."); 
		 
		      try { 
		      //  m.addAttachment("/sdcard/filelocation"); 
		 
		        if(m.send()) { 
		          Toast.makeText(EmailAutomatically.this, "Email was sent successfully.", Toast.LENGTH_LONG).show(); 
		        } else { 
		          Toast.makeText(EmailAutomatically.this, "Email was not sent.", Toast.LENGTH_LONG).show(); 
		        } 
		      } catch(Exception e) { 
		        //Toast.makeText(MailApp.this, "There was a problem sending the email.", Toast.LENGTH_LONG).show(); 
		        Log.e("MailApp", "Could not send email", e); 
		      } 
		    } 
		  }); 
		} 
		
		 
	
		


	}
	


