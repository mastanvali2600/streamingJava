package org.trackme.systemServicesAndCpuWakeup;

import org.activity.LoginActivity;
import org.appTracker.R;





import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class DevicePolicyActivity extends Activity implements
		OnCheckedChangeListener {
	static final String TAG = "DevicePolicyDemoActivity";
	static final int           ACTIVATION_REQUEST = 47; // identifies our request id
	DevicePolicyManager        devicePolicyManager;
	ComponentName              demoDeviceAdmin;
	ToggleButton               toggleButton;
	Button                     backbutton;TextView logoutBtn;
	private static final int PASSWORD = 1;
	private static final int PASSWORD_ID = 1;
    
    private static final int DLG_EXAMPLE1 = 0;
    private static final int TEXT_ID = 0;
	//---Initialising strings so that they don;'t throw null pointer exception if preferences includes no data.
		String    prefencesEmailID="",prefrencesPassword="";
		
		SharedPreferences pref = null;
		
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE); 
		setContentView(R.layout.system_services_activity);
		
		//---initialisation shared preferences object... 
		pref            =   getSharedPreferences("email_prefrence", Context.MODE_PRIVATE);
		
		getLoginPrefrences();
		
		
		
		InitData();

	}
	
	
	  public void scheduleAlarm()
	    
	    {       
	      /* phone alarm list activity*/
		  Intent addEmailTiming = new Intent(getApplicationContext(),com.alarm.List.class);
		  startActivity(addEmailTiming); 
	        
	    }
	
	  

	private void getLoginPrefrences()    {
		
		backbutton           =    (Button)  findViewById(R.id.backbutton);
		backbutton.setOnClickListener(new View.OnClickListener()  
		
		{			
			@Override
			public void onClick(View v) 
			{
				finish();				
			}
		});
		
    	//---Retreiving Prefrence    
	             prefencesEmailID      =  pref.getString("email"    ,     prefencesEmailID);
                 prefrencesPassword    =  pref.getString("password" ,     prefrencesPassword);
                 
                 //Toast.makeText(getApplicationContext(), "your entered email-id is:prefencesEmailID--:"+prefencesEmailID, 1000).show();
                // Toast.makeText(getApplicationContext(), "your entered email-id prefrencesPassword--:"+prefrencesPassword, 2000).show();
			
	}

	private void InitData() {
		


		
		logoutBtn                     = (TextView)  findViewById(R.id.logoutBtn);
		logoutBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) 
			{
			Intent logout = new Intent(getApplicationContext(),LoginActivity.class);
			logout.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(logout);
				
			}
		});
		
		toggleButton = (ToggleButton) super.findViewById(R.id.toggle_device_admin);
		toggleButton.setOnCheckedChangeListener(this);

		// Initialize Device Policy Manager service and our receiver class
		devicePolicyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
		demoDeviceAdmin = new ComponentName(this, AdminReceiver.class);
	}

	/*
	 * 
	 * Called when a button is clicked on. We have Lock Device and Reset Device
	 * buttons that could invoke this method.
	 * 
	 * 
	 */
	
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.button_lock_device:
			// We lock the screen
			
			Toast.makeText(this, "Locking device...", Toast.LENGTH_LONG).show();
			
			Log.d(TAG, "Locking device now");
			
			devicePolicyManager.lockNow();
			
			break;
		case R.id.backbutton:
			 finish();
			 break;
				
		case R.id.button_reset_device:
			
			// We reset the device - this will erase entire /data partition!
			Toast.makeText(this, "Locking device...", Toast.LENGTH_LONG).show();			
			Log.d(TAG,"RESETing device now - all user data will be ERASED to factory settings");			
			devicePolicyManager.wipeData(ACTIVATION_REQUEST);
			
			break;
			
		case R.id.changeAccountEmailId:

			  Toast.makeText(DevicePolicyActivity.this, "Please enter correct email-id ,either you will not  recieve emails from this application.", Toast.LENGTH_LONG).show(); 
		    
			 // Creates the dialog if necessary, then shows it.
	         // Will show the same dialog if called multiple times.
	           showDialog(DLG_EXAMPLE1);
			
			break;
			
		case R.id.changeAccountPswd:
			
			  Toast.makeText(DevicePolicyActivity.this, "Please enter correct email-id password,either you will not recieve emails from this application.", Toast.LENGTH_LONG).show(); 
		      
			 // Creates the dialog if necessary, then shows it.
	         // Will show the same dialog if called multiple times.
	           showDialog(PASSWORD);
			
			break;
		   case R.id.logoutBtn:
	    	   Intent logoutBtn = new Intent (getApplicationContext(),LoginActivity.class);
	    	   logoutBtn.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	    	   startActivity(logoutBtn);	
			
		case R.id.changeMailTime:
			/*
			// this will change mail sending interval time for daily basis.
			Toast.makeText(this, "changing mail time...", Toast.LENGTH_LONG).show();
			
			Log.d(TAG,"RESETing device now - all user data will be ERASED to factory settings");
			
			
			Intent   i = new Intent(getApplicationContext(),org.activity.CustomDateDialog.class);
			
		    startActivity(i);
			
		  //--slide from left to right
	        overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left );
			*
			*
			*
			*/
		
			

			//===Initialise email sending through alarm process
			scheduleAlarm();
		
			
			break;
		}
	}
	 /**
     * Called to create a dialog to be shown.
     */
    @Override
    protected Dialog onCreateDialog(int id) {
 
        switch (id) {
            case DLG_EXAMPLE1:
                return createExampleDialog();
                
            case PASSWORD:
                return createPasswordDialog();
            default:
                return null;
        }
    }
   
    /**
     * If a dialog has already been created,
     * this is called to reset the dialog
     * before showing it a 2nd time. Optional.
     */
    @Override
    protected void onPrepareDialog(int id, Dialog dialog) {
 
        switch (id) {
            case DLG_EXAMPLE1:
                // Clear the input box.
                EditText text = (EditText) dialog.findViewById(TEXT_ID);
                text.setText(prefencesEmailID);
                break;
                
            case PASSWORD:
                // Clear the input box.
                EditText PSWD = (EditText) dialog.findViewById(PASSWORD_ID);
                PSWD.setText(prefrencesPassword);
                break;
        }
    }


/**
 * Create and return an example alert dialog with an edit text box.
 */
private Dialog createExampleDialog() {

    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setTitle("Edit Email :");
   

     // Use an EditText view to get user input.
     final EditText input = new EditText(this);
    
     input.setId(TEXT_ID);
     
     
     
     builder.setView(input);

      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

        @Override
        public void onClick(DialogInterface dialog, int whichButton) {
            String value = input.getText().toString();
            
            pref.edit().putString("email"   ,value)  .commit();
          //  pref.edit().putString("password",loginpassword.getText().toString()).commit();
            
            Log.d(TAG, "User name: " + value);
            return;
        }
    });

    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

        @Override
        public void onClick(DialogInterface dialog, int which) {
            return;
        }
    });

    return builder.create();
}



/**
 * Create and return an example alert dialog with an edit text box.
 */
private Dialog createPasswordDialog() {

    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setTitle("Edit Password :");
   

     // Use an EditText view to get user input.
     final EditText password_input = new EditText(this);
    
     password_input.setId(PASSWORD_ID);
     
     
     
     builder.setView(password_input);

      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

        @Override
        public void onClick(DialogInterface dialog, int whichButton) {
            String value = password_input.getText().toString();
            
          //  pref.edit().putString("email"   ,value)  .commit();
             pref.edit().putString("password",value).commit();
            
            Log.d(TAG, "User Password: " + value);
            return;
        }
    });

    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

        @Override
        public void onClick(DialogInterface dialog, int which) {
            return;
        }
    });

    return builder.create();
}






	

	/**
	 * Called when the state of toggle button changes. In this case, we send an
	 * intent to activate the device policy administration.
	 */
	@Override
	public void onCheckedChanged(CompoundButton button, boolean isChecked) 
	
	{
		if (isChecked) 
		{
			// Activate device administration
			Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
			intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,demoDeviceAdmin);
			intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,"Your boss saying you to make this applcation unistallable.");
			startActivityForResult(intent, ACTIVATION_REQUEST);
		}
		Log.d(TAG, "onCheckedChanged to: " + isChecked);
	}

	/**
	 * Called when startActivityForResult() call is completed. The result of
	 * activation could be success of failure, mostly depending on user okaying
	 * this app's request to administer the device.
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) 
	
	{
		switch (requestCode) 
		
		{
		case ACTIVATION_REQUEST:
			if (resultCode == Activity.RESULT_OK) {
				Log.i(TAG, "Administration enabled!");
				toggleButton.setChecked(true);
			} else {
				Log.i(TAG, "Administration enable FAILED!");
				toggleButton.setChecked(false);
			}
			return;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}



}