package org.trackme.systemServicesAndCpuWakeup;

import org.activity.LoginActivity;
import org.appTracker.R;
import org.trackme.automaticEmail.Mail;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.StrictMode;
import android.os.SystemClock;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.Menu;
import android.widget.Toast;

public class WakeUpSystemServicesActivity extends Activity {
BroadcastReceiver mReceiver;

String    prefencesEmailID,prefrencesPassword;

SharedPreferences pref = null;
String TAG = "testing";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.system_services_activity);
		
		//---function to remove restrict mode policy exceptions
		StrictModePolicies();
		
		
		//==initializing shared prefrences object... 
		pref            = getSharedPreferences("email_prefrence", Context.MODE_PRIVATE);
				
        mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.v(TAG, "Screen OFF onReceive()");
            screenOFFHandler.sendEmptyMessageDelayed(0, 3000L);
        }
    };


	}


	
	
	

private void StrictModePolicies() {
		
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);
		
	}
protected void onResume()
{
	super.onResume();
	   IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
	    registerReceiver(mReceiver, filter);
	    Log.i(TAG, "broadcast receiver registered!");
}
protected void onDestroy()
  {	
	super.onDestroy();
  unregisterReceiver(mReceiver);
  Log.i(TAG, "broadcast UNregistred!");

  }

	@Override
	public boolean onCreateOptionsMenu(Menu menu)        {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	private Handler screenOFFHandler = new Handler()     {

	    @Override
	    public void handleMessage(Message msg) {

	        super.handleMessage(msg);
	        // do something
	        // wake up phone
	        Log.i(TAG, "wake up the phone and disable keyguard");
	        PowerManager powerManager = (PowerManager) WakeUpSystemServicesActivity.this.getSystemService(Context.POWER_SERVICE);
	        long l = SystemClock.uptimeMillis();
	        //---sending mail to user account to check wheather this code works or not
	        //==sending email id and password details to previously registered account.
			 sendEmailToRegisteredAccount();
			 Log.i("email check", "Email  sent successfully");
			
	        powerManager.userActivity(l, false);//==false will bring the screen back as bright as it was, true - will dim it
	        
	        //Toast.makeText(getApplicationContext(), "We have sent a email on your registered email account.", 1000).show();
			 
	        
	    }
	};

	
	private void sendEmailToRegisteredAccount() {
		
		//==get email id and password
		getSharedPrefrencesData();
				
		
		 Mail m = new Mail(prefencesEmailID, prefrencesPassword); 
		 
	      String[] toArr = {prefencesEmailID, prefencesEmailID}; 
	      m.set_to(toArr); 
	      m.set_from("wooo@wooo.com"); 
	      m.set_subject("Your Track Me application account information mail from java wrapper."); 
	      m.setBody("Hi..." +"                                                                                 "+
	      		"your account email-id is                      :: "+prefencesEmailID+"                         "+
	      		"your account password is                      :: "+prefrencesPassword); 
	 
	      try { 
	      //  m.addAttachment("/sdcard/filelocation"); 
	 
	        if(m.send()) { 
	          
	        	Log.i("email check", "Email was sent successfully");
	        	Log.i("email check", "Email was sent successfully");
	        	Log.i("email check", "Email was sent successfully");
	        	
	        	//Toast.makeText(WakeUpSystemServicesActivity.this, "Email was sent successfully.", Toast.LENGTH_LONG).show(); 
	          
	        	//Toast.makeText(WakeUpSystemServicesActivity.this, "Please check your mail account for login informations.", Toast.LENGTH_LONG).show(); 
	        } else { 
	        	Log.i("email check", "Email not sent ");
	        	//Toast.makeText(WakeUpSystemServicesActivity.this, "Email was not sent.", Toast.LENGTH_LONG).show(); 
	        } 
	      } catch(Exception e) { 
	        //Toast.makeText(MailApp.this, "There was a problem sending the email.", Toast.LENGTH_LONG).show(); 
	        Log.e("MailApp", "Could not send email", e); 
	      } 
	    
		
	}
	
	
public void getSharedPrefrencesData() {
		
    	//---Retreiving Prefrence    
	             prefencesEmailID      =  pref.getString("email"    ,     prefencesEmailID);
                 prefrencesPassword    =  pref.getString("password" ,     prefrencesPassword);
                 
                 
                 Log.i("prefencesEmailID", prefencesEmailID);
                  Log.i("prefrencesPassword", prefrencesPassword);
              //   Toast.makeText(getApplicationContext(), "your entered email-id is:prefencesEmailID--:"+prefencesEmailID, 1000).show();
                // Toast.makeText(getApplicationContext(), "your entered email-id prefrencesPassword--:"+prefrencesPassword, 2000).show();
			
	}
}
