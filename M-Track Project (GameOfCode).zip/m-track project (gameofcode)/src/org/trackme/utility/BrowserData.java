package org.trackme.utility;

public class BrowserData {
	
	String titleIdx,urlIdx,visits,date;

	public String getVisits() {
		return visits;
	}

	public void setVisits(String visits) {
		this.visits = visits;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTitleIdx() {
		return titleIdx;
	}

	public void setTitleIdx(String titleIdx) {
		this.titleIdx = titleIdx;
	}

	public String getUrlIdx() {
		return urlIdx;
	}

	public void setUrlIdx(String urlIdx) {
		this.urlIdx = urlIdx;
	}

}
