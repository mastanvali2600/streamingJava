package org.trackme.utility;

import java.util.Calendar;
import java.util.Date;




import android.app.Activity;
import android.content.Intent;
import android.text.Layout;
import android.util.Log;
import android.widget.LinearLayout;

public class Utils
{
	private static int sTheme;

	public final static int THEME_DEFAULT = 1;
	public final static int THEME_WHITE = 2;
	public final static int THEME_BLUE = 3;
    /////////////////////////////////////////////////////
	public static int syear ;
	public static int smonth ;
	public static int sday;
	public static int vmYear;
	public static int vmMonth;
	public static int  vmDay; 
	public static String[] split_hours;
	public static String[] split_meals;
	/////////////////////////////////////////////////////
	/**
	 * Set the theme of the Activity, and restart it by creating a new Activity
	 * of the same type.
	 */
	public static void changeToTheme(Activity activity, int theme)
	{
		sTheme = theme;
		//activity.finish();

		//activity.startActivity(new Intent(activity, activity.getClass()));
	}

	public static String SeperateRaw(String LaLngVal)
  	{
    	//lat/lng: (32.2456779678369,77.189581990242)
    	    	String[] split_latLong=LaLngVal.split(":");
    	    	String latLong=split_latLong[1];
    	    	//latLong.replaceAll("[(]", "");
    	    	//latLong.replace(("regex"), "replacement");
                String mainString[] = latLong.split("\\(");
                
                String mainsplit = mainString[0];
                String othersplit = mainString[1];
                
                String replacestring = othersplit.replace(")", " ");
                
                Log.e("the result string is", "first half"+mainsplit+"---"+replacestring);
    	    	
    	    	
    	    	Log.e("utils latLong", replacestring);
    	    	
    	return replacestring;
  	}
	
	 //Methods to break the date and time in different values
	
	public static String removeAfterThirdDigit(String days)
    {
		
		String final_string ;
  
             String[] split_datetime = days.split(".");
             
             
             Log.e("**************", " value is"+split_datetime);        
     
     String right_value = split_datetime[1];
     Log.e("**************", "date value is"+right_value);
     
     
     String left_value = split_datetime[0];
     Log.e("**************", "date value is"+left_value);
     
     if(right_value.length()>1)
     {
    	 
    
     String str = right_value;
	 String result = str.substring(0,1);
		
	 System.out.println(result);

     
    final_string = left_value+"."+result;
     }
     else
     {
    	 final_string = right_value;
     }
     return final_string;
            
            
    }
	
	public static String getDays(String days)
    {
             String[] split_datetime = days.split(":");
     String days_value = split_datetime[0];
     Log.e("**************", "date value is"+days_value);
     
     return days_value;
            
            
    }
    
    public static String getHours(String time)
    {
     String[] split_datetime = time.split(":");
     String hours_value = split_datetime[1];
     Log.e("**************", "hours value is"+hours_value);
     
     return hours_value;
    }
    public static String getMinutes(String time)
    {
     String[] split_month = time.split(":");
     String minute_value = split_month[2];
     //String month_str = ev.getMonth(month_value); 
     Log.e("**************", "minutes value is"+minute_value);
     
     return minute_value;
    }
    public static String getSeconds(String time)
    {
     String[] split_seconds = time.split(":");
     String seconds = split_seconds[3];
     String[] split_sec = seconds.split(" ");
     String seconds_value = split_sec[0];
     Log.e("**************", "seconds value is"+seconds_value);

     
     return seconds_value;
    }
  //method to change time in milliseconds
    public static int changeTimeTomilliseconds(int days,int hours,int minutes,int seconds)
    
    
    {
            int milliseconds = days*24*60*60*1000+hours*60*60*1000 + minutes*60*1000 + seconds*1000;
            
            return milliseconds;
    }
    
    public static void getDayMonthYear()
    {
    	final Calendar c = Calendar.getInstance();
		 syear = c.get(Calendar.YEAR);
		 smonth = c.get(Calendar.MONTH);
		 sday = c.get(Calendar.DAY_OF_MONTH);
		Log.d("************YEAR**", "................"+syear		);
		Log.d("************month**", "................"+smonth++);
		Log.d("************day**", "................"+sday);
    }
    
    public static void breakDate(String m)
	{
    	String mYear = "" ;
    	String mMonth = "" ;
    	String mDay = "" ;
		 for(int i=0;i<m.length();i++)
		 {
		 if(i<4)
		 {
			 mYear=mYear+""+m.charAt(i);
		 }
		 if(i>4&&i<7)
		 {
			 mMonth=mMonth+""+m.charAt(i);
		 }
		 if(i>7)
		 {
			 mDay=mDay+""+m.charAt(i);
		 }
		 }
		 vmYear=Integer.parseInt(mYear);
		 vmMonth=Integer.parseInt(mMonth);
		 vmDay=Integer.parseInt(mDay);
		 Log.d("********cccccccc********", "------------="+mYear+"..................="+mMonth+"................="+mDay);
	}
    
   
    public static String[] getMealhours(String hours)
    {
    	
    	 split_hours = hours.split(",");
    	/* split_hours.length
         String seconds = split_hours[0];
         String[] split_sec = seconds.split(" ");
         String seconds_value = split_sec[0];
         Log.e("**************", "seconds value is"+seconds_value);*/

         
         return split_hours; 
    	
    	
    }
    
    public static String[] getMealType(String cuisine)
    {
    	
    	split_meals = cuisine.split(",");
    	/* split_hours.length
         String seconds = split_hours[0];
         String[] split_sec = seconds.split(" ");
         String seconds_value = split_sec[0];
         Log.e("**************", "seconds value is"+seconds_value);*/

         
         return split_meals; 
    	
    	
    }
    

    public static String addZeroToTheEndWithNonZeroNumber(String timeVal)
   	
    {
     	
     	
        	  String timehours = timeVal;
           Log.e("timehours", timehours);
       	 
       	  if(timehours.equals("0")==true){
       		  timehours="0"+timehours;
       		//Log.e("timehours", timehours);
       	  }
       	  if(timehours.equals("1")==true){
       		  timehours="0"+timehours;
       		//Log.e("timehours", timehours);
       	  }
       	 
       	  if(timehours.equals("2")==true){
       		  timehours="0"+timehours;
       		Log.e("value ::", timehours);
       	  }
       	 
       	  if(timehours.equals("3")==true){
       		  timehours="0"+timehours;
       	  }
       	 
       	  if(timehours.equals("4")==true){
       		  timehours="0"+timehours;
       	  }
       	 
       	  if(timehours.equals("5")==true){
       		  timehours="0"+timehours;
       	  }
       	 if(timehours.equals("6")==true){
      		  timehours="0"+timehours;
      	  }
      	 
      	  if(timehours.equals("7")==true){
      		  timehours="0"+timehours;
      	  }
      	 
      	  if(timehours.equals("8")==true){
      		  timehours="0"+timehours;
      	  }
      	 
      	  if(timehours.equals("9")==true){
      		  timehours="0"+timehours;
      	  }
		return timehours;
   	}
    public static String SeperateTime(String timeVal)
  	{
    	
    	
      	String timeValue="";
      	  String[] split_seconds = timeVal.split("-");
      	  String timehours = split_seconds[0];
      	//  Log.e("timehours", timehours);
      	 
      	  if(timehours.equals("0")==true){
      		  timehours="0"+timehours;
      		//Log.e("timehours", timehours);
      	  }
      	  if(timehours.equals("1")==true){
      		  timehours="0"+timehours;
      		//Log.e("timehours", timehours);
      	  }
      	 
      	  if(timehours.equals("2")==true){
      		  timehours="0"+timehours;
      	  }
      	 
      	  if(timehours.equals("3")==true){
      		  timehours="0"+timehours;
      	  }
      	 
      	  if(timehours.equals("4")==true){
      		  timehours="0"+timehours;
      	  }
      	 
      	  if(timehours.equals("5")==true){
      		  timehours="0"+timehours;
      	  }
      	 if(timehours.equals("6")==true){
     		  timehours="0"+timehours;
     	  }
     	 
     	  if(timehours.equals("7")==true){
     		  timehours="0"+timehours;
     	  }
     	 
     	  if(timehours.equals("8")==true){
     		  timehours="0"+timehours;
     	  }
     	 
     	  if(timehours.equals("9")==true){
     		  timehours="0"+timehours;
     	  }
      		     String timeminutes = split_seconds[1];
      		     
      		 	  if(timeminutes.equals("0")==true){
      		 		timeminutes="0"+timeminutes;
      	      		//Log.e("timehours", timeminutes);
      	      	  }
      	      	  if(timeminutes.equals("1")==true){
      	      		timeminutes="0"+timeminutes;
      	      		//Log.e("timehours", timeminutes);
      	      	  }
      	      	 
      	      	  if(timeminutes.equals("2")==true){
      	      		timeminutes="0"+timeminutes;
      	      	  }
      	      	 
      	      	  if(timeminutes.equals("3")==true){
      	      		timeminutes="0"+timeminutes;
      	      	  }
      	      	 
      	      	  if(timeminutes.equals("4")==true){
      	      		timeminutes="0"+timeminutes;
      	      	  }
      	      	 
      	      	  if(timeminutes.equals("5")==true){
      	      		timeminutes="0"+timeminutes;
      	      	  }
      	      	 if(timeminutes.equals("6")==true){
      	      		timeminutes="0"+timeminutes;
      	     	  }
      	     	 
      	     	  if(timeminutes.equals("7")==true){
      	     		timeminutes="0"+timehours;
      	     	  }
      	     	 
      	     	  if(timeminutes.equals("8")==true){
      	     		timeminutes="0"+timeminutes;
      	     	  }
      	     	 
      	     	  if(timeminutes.equals("9")==true){
      	     		timeminutes="0"+timeminutes;
      	     	  }
      	      		
      	     //  String[] split_sec = seconds.split("");
      	     String seconds_value = split_seconds[2];
      	     Log.e("**************", "seconds value is"+seconds_value);
      	     
      	     if (seconds_value.equals("*0")) {
      	    	 
      	    	 

      	    	 timeValue = timehours+"-"+timeminutes+"am";
      	    	 
  			}
      	     else if(seconds_value.equals("*1"))
      	     {
      	    	 timeValue = timehours+"-"+timeminutes+"pm";
      	     }
      	     

      	     
      	     return timeValue;
  		
  	}
    
    
    //----------------------------------------------------------method to format alarm time -------------------------------
    public static String SeperateAlarmTime(String timeVal)
  	{
    	
    	
      	String timeValue="";
      	  String[] split_seconds = timeVal.split(":");
      	  String timehours = split_seconds[0];
      	 // Log.e("timehours", timehours);
      	 
      	  if(timehours.equals("0")==true){
      		  timehours="0"+timehours;
      		//Log.e("timehours", timehours);
      	  }
      	  if(timehours.equals("1")==true){
      		  timehours="0"+timehours;
      		//Log.e("timehours", timehours);
      	  }
      	 
      	  if(timehours.equals("2")==true){
      		  timehours="0"+timehours;
      	  }
      	 
      	  if(timehours.equals("3")==true){
      		  timehours="0"+timehours;
      	  }
      	 
      	  if(timehours.equals("4")==true){
      		  timehours="0"+timehours;
      	  }
      	 
      	  if(timehours.equals("5")==true){
      		  timehours="0"+timehours;
      	  }
      	 if(timehours.equals("6")==true){
     		  timehours="0"+timehours;
     	  }
     	 
     	  if(timehours.equals("7")==true){
     		  timehours="0"+timehours;
     	  }
     	 
     	  if(timehours.equals("8")==true){
     		  timehours="0"+timehours;
     	  }
     	 
     	  if(timehours.equals("9")==true){
     		  timehours="0"+timehours;
     	  }
      		     String timeminutes = split_seconds[1];
      		     
      		 	  if(timeminutes.equals("0")==true){
      		 		timeminutes="0"+timeminutes;
      	      		Log.e("timehours", timeminutes);
      	      	  }
      	      	  if(timeminutes.equals("1")==true){
      	      		timeminutes="0"+timeminutes;
      	      		Log.e("timehours", timeminutes);
      	      	  }
      	      	 
      	      	  if(timeminutes.equals("2")==true){
      	      		timeminutes="0"+timeminutes;
      	      	  }
      	      	 
      	      	  if(timeminutes.equals("3")==true){
      	      		timeminutes="0"+timeminutes;
      	      	  }
      	      	 
      	      	  if(timeminutes.equals("4")==true){
      	      		timeminutes="0"+timeminutes;
      	      	  }
      	      	 
      	      	  if(timeminutes.equals("5")==true){
      	      		timeminutes="0"+timeminutes;
      	      	  }
      	      	 if(timeminutes.equals("6")==true){
      	      		timeminutes="0"+timeminutes;
      	     	  }
      	     	 
      	     	  if(timeminutes.equals("7")==true){
      	     		timeminutes="0"+timehours;
      	     	  }
      	     	 
      	     	  if(timeminutes.equals("8")==true){
      	     		timeminutes="0"+timeminutes;
      	     	  }
      	     	 
      	     	  if(timeminutes.equals("9")==true){
      	     		timeminutes="0"+timeminutes;
      	     	  }
      	      		
      	   /*  //  String[] split_sec = seconds.split("");
      	     String seconds_value = split_seconds[2];
      	     Log.e("**************", "seconds value is"+seconds_value);
      	     
      	     if (seconds_value.equals("*0")) {
      	    	 
      	    	 

      	    	 timeValue = timehours+"-"+timeminutes+"am";
      	    	 
  			}
      	     else if(seconds_value.equals("*1"))
      	     {
      	    	 timeValue = timehours+"-"+timeminutes+"pm";
      	     }*/
      	     
      	     	timeValue = timehours+":"+timeminutes;
      	     
      	     return timeValue;
  	}
    
   public static String SeperateMonth(String timeVal)
  	
    {
    	
    	
      	  String timeValue="";
      	  String[] split_seconds = timeVal.split("-");
      	  String month = split_seconds[0];
      	  Log.e("Date_month", month);
      
		return month;
  	 }
  public static int Seperate_Month(String timeVal)
  	
    {
    	    	
          String timeValue="";
      	  String[] split_seconds = timeVal.split("-");
      	  String month = split_seconds[0];
      	  Log.e("Date_month", month);
          int  Month = Integer.parseInt(month);
          
		return Month;
  	 }
    
  public static String SeperateYear(String timeVal)
	{
  	
  	
    	String timeValue="";
    	
    	String[] split_seconds = timeVal.split("-");
    	 
    	String year_data = split_seconds[1];
    	
    	Log.e("Date_year", year_data);
    	
    	//int year = Integer.parseInt(year_data);
    	
    	//year.trim();
    	
		return year_data;
	}
  
    public static int Seperate_Year(String timeVal)
  	{
    	
    	
      	String timeValue="";
      	
      	String[] split_seconds = timeVal.split("-");
      	 
      	String year_data = split_seconds[1];
      	
      	Log.e("Date_year", year_data);
      	
      	int year = Integer.parseInt(year_data);
      	
      	//year.trim();
      	
		return year;
  	}
    
    public static String SeperateDate(String timeVal)
  	{
    	
    	
      	String timeValue="";
      	
      	  String[] split_seconds = timeVal.split("-");
      	  String timehours = split_seconds[0];
      	  Log.e("Date_month", timehours);
      	  
      	  
      	  if(timehours.equals("0")==true){
    		  timehours="01";
    		Log.e("time_month", timehours);
    	  } 
      	  if(timehours.equals("1")==true){
      		  timehours="02";
      		Log.e("time_month", timehours);
      	  }
      	 
      	  if(timehours.equals("2")==true){
      		  timehours="03";
      	  }
      	 
      	  if(timehours.equals("3")==true){
      		  timehours="04";
      	  }
      	 
      	  if(timehours.equals("4")==true){
      		  timehours="05";
      	  }
      	 
      	  if(timehours.equals("5")==true){
      		  timehours="06";
      	  }
      	 if(timehours.equals("6")==true){
     		  timehours="07";
     	  }
     	 
     	  if(timehours.equals("7")==true){
     		  timehours="08";
     	  }
     	 
     	  if(timehours.equals("8")==true){
     		  timehours="09";
     	  }
     	 
     	  if(timehours.equals("9")==true){
     		  timehours="10";
     	  }
     	 if(timehours.equals("10")==true){
    		  timehours="11";
    	  }
     	if(timehours.equals("11")==true){
   		  timehours="12";
   	      }
      		    String dateSplit = split_seconds[1];
      		  if(dateSplit.equals("0")==true){
      			dateSplit="01";
        		Log.e("time_month", timehours);
        	  } 
          	  if(dateSplit.equals("1")==true){
          		dateSplit="02";
          		Log.e("time_month", timehours);
          	  }
          	 
          	  if(dateSplit.equals("2")==true){
          		dateSplit="03";
          	  }
          	 
          	  if(dateSplit.equals("3")==true){
          		dateSplit="04";
          	  }
          	 
          	  if(dateSplit.equals("4")==true){
          		dateSplit="05";
          	  }
          	 
          	  if(dateSplit.equals("5")==true){
          		dateSplit="06";
          	  }
          	 if(dateSplit.equals("6")==true){
          		dateSplit="07";
         	  }
         	 
         	  if(dateSplit.equals("7")==true){
         		 dateSplit="08";
         	  }
         	 
         	  if(timehours.equals("8")==true){
         		  timehours="09";
         	  }
         	 
         	  if(dateSplit.equals("9")==true){
         		 dateSplit="10";
         	  }
         	 if(dateSplit.equals("10")==true){
         		dateSplit="11";
        	  }
         	if(dateSplit.equals("11")==true){
         		dateSplit="12";
       	      }
      	   //  String[] split_sec = seconds.split("");
      	     String seconds_value = split_seconds[2];
      	     Log.e("**************", "seconds value is"+seconds_value);
      	     
      	    
              timeValue=timehours+"-"+dateSplit+"-"+seconds_value;
      	     
      	     return timeValue;
  		
  	}
  /*  public enum hours {
           1,2,3,4,5,6,7,8,9
	     }*/
    
}
