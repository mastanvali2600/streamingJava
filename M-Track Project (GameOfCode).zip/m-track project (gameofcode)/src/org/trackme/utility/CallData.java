package org.trackme.utility;

public class CallData {

	public  String id;
	public  String number;
	public  String date;
	public  String duration;
	public  String cached_name;
	public  String type;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getCached_name() {
		return cached_name;
	}
	public void setCached_name(String cached_name) {
		this.cached_name = cached_name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
