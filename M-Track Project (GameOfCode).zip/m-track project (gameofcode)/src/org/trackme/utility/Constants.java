package org.trackme.utility;

public class Constants {

	
	
	public static int  emailHour = 16;
	
	public static int  emailMin  = 05;
	
	public static int  emailSec  = 01;
	
	
}
