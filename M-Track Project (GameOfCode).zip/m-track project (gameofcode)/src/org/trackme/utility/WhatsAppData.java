package org.trackme.utility;

public class WhatsAppData {
	
	String  Id , NotificationMsg,NotificationTime ,MsgFrom ;

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getNotificationMsg() {
		return NotificationMsg;
	}

	public void setNotificationMsg(String notificationMsg) {
		NotificationMsg = notificationMsg;
	}

	public String getNotificationTime() {
		return NotificationTime;
	}

	public void setNotificationTime(String notificationTime) {
		NotificationTime = notificationTime;
	}

	public String getMsgFrom() {
		return MsgFrom;
	}

	public void setMsgFrom(String msgFrom) {
		MsgFrom = msgFrom;
	}

}
