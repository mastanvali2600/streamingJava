package org.trackme.utility;


/**
* This class represents SMS.
*
* @author itcuties
*
*/
public class SMSData {

	
	public String _ID;
	public String NUMBER;
	public String DATE;
	public String DURATION;
	public String CACHED_NAME;
	public String TYPE;
	
   public String get_ID() {
		return _ID;
	}

	public void set_ID(String _ID) {
		this._ID = _ID;
	}

	public String getNUMBER() {
		return NUMBER;
	}

	public void setNUMBER(String nUMBER) {
		NUMBER = nUMBER;
	}

	public String getDATE() {
		return DATE;
	}

	public void setDATE(String dATE) {
		DATE = dATE;
	}

	public String getDURATION() {
		return DURATION;
	}

	public void setDURATION(String dURATION) {
		DURATION = dURATION;
	}

	public String getCACHED_NAME() {
		return CACHED_NAME;
	}

	public void setCACHED_NAME(String cACHED_NAME) {
		CACHED_NAME = cACHED_NAME;
	}

	public String getTYPE() {
		return TYPE;
	}

	public void setTYPE(String tYPE) {
		TYPE = tYPE;
	}

// Number from witch the sms was send
   private String number;
   
   private String _id;
   public String get_id() {
	return _id;
}

public void set_id(String _id) {
	this._id = _id;
}

// SMS text body
   private String body;
   
   // SMS text body
   private String address;
   public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

// SMS text body
   private String date;
   // SMS text body
   private String person;
   // SMS text body
   private String service_center;
   // SMS text body
   private String type;
// SMS text body
   private String protocol;
// SMS text body
   private String locked;


   public String getProtocol() {
	return protocol;
}

public void setProtocol(String protocol) {
	this.protocol = protocol;
}

public String getLocked() {
	return locked;
}

public void setLocked(String locked) {
	this.locked = locked;
}

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public String getPerson() {
	return person;
}

public void setPerson(String person) {
	this.person = person;
}

public String getService_center() {
	return service_center;
}

public void setService_center(String service_center) {
	this.service_center = service_center;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public String getNumber() {
       return number;
   }

   public void setNumber(String number) {
       this.number = number;
   }

   public String getBody() {
       return body;
   }

   public void setBody(String body) {
       this.body = body;
   }

}
