package org.trackme.utility;

import android.content.Context;
import android.graphics.Typeface;

public class Appfonts {

       private static final String PATH_PREFIX = "fonts/";
       /*public static final String SEGOEPRB_TTF = "segoeprb.ttf";
       public static final String GABRIOLA_TTF = "Gabriola.ttf";
       public static final String SCRIPT_MTS_BOLD = "scriptmtstd-bold.otf";*/
       public static final String Helvetica="Avenir-Medium.otf";
       public static final String OswaldRegular = "Oswald-Regular.ttf";
       /**
        * Load Font from Assets
        * @param context Application context
        * @param fontName Any font Name declared in SprintFonts class.
        * @return
        */
       public static Typeface getFont(Context context, String fontName){

         return Typeface.createFromAsset(context.getAssets(),
                          new StringBuilder().append(PATH_PREFIX).append(fontName).toString()
                               );
       }

}