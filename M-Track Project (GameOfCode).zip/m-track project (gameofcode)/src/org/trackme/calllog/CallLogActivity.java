/*
 * Copyright (C)  2011  Álvaro Tanarro Santamaría.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.trackme.calllog;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.adapter.CallLogAdapter;

import org.appTracker.R;
import org.trackme.utility.CallData;
import org.trackme.utility.SMSData;


import android.app.Activity;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CallLog;
import android.util.Log;
import android.view.Window;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

/**
 * @author atanarro
 */
public class CallLogActivity extends Activity {
	// public static ArrayList<HashMap<String, String>> order_list;
	ListView myCartList;
	
	ArrayList<CallData> callLog = new ArrayList<CallData>();
	
	
	
	CallLogAdapter callAdaper;
    // Cursor Adapter
    SimpleCursorAdapter adapter;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.call_logs_activity);
		myCartList   = (ListView) findViewById(R.id.callListview);
		
		
		
		

		Uri allCalls = Uri.parse("content://call_log/calls");
		
		 // Get Content Resolver object, which will deal with Content Provider
        ContentResolver cr = getContentResolver();

        // Fetch Sent SMS Message from Built-in Content Provider
        Cursor c = cr.query(allCalls, null, null, null, null);
         while (c.moveToNext()) 
        
        {
			
			String id = c.getString(c.getColumnIndex(CallLog.Calls._ID));
			String callerNumner = c.getString(c.getColumnIndex(CallLog.Calls.NUMBER));
			String date = c.getString(c.getColumnIndex(CallLog.Calls.DATE));
		
					DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

					long milliSeconds= Long.parseLong(date);
					Calendar calendar = Calendar.getInstance();
					calendar.setTimeInMillis(milliSeconds);
					System.out.println(formatter.format(calendar.getTime()));
			        String formatedDate = formatter.format(calendar.getTime());
			
			
			
			String CallDuration = c.getString(c.getColumnIndex(CallLog.Calls.DURATION));
			
			String CallerName = c.getString(c.getColumnIndex(CallLog.Calls.CACHED_NAME));
			
			int type = Integer.parseInt(c.getString(c.getColumnIndex(CallLog.Calls.TYPE)));

			String callLogStr = id + ":--Caller Number" + callerNumner+"-Date--"+date+"--Call Duration--"+CallDuration+"sec"+"---Caller Name--"+CallerName;
			
			 CallData  data = new CallData();
		      
		      
			
			data.setId(id);
			data.setDate(formatedDate);
			data.setNumber(callerNumner);
			data.setDuration(CallDuration);
			
			if( CallerName == null )
			{
				data.setCached_name("No Name");
			}
			else
			{
			
			data.setCached_name(CallerName);
			
			}
			
			Log.i("callLogStr", callLogStr);
			switch (type)  {
			 
			case CallLog.Calls.INCOMING_TYPE:
				callLogStr += " (Incoming)";
				break;
				
			case CallLog.Calls.OUTGOING_TYPE:
				callLogStr += " (Outgoing)";
				break;
				
			case CallLog.Calls.MISSED_TYPE:
				callLogStr += "(Missed)";
				break;
				
				
				
				
			}
			
			
			
			callLog.add(data);
       }
			
        
			
         // ------activity adapter
			
						callAdaper = new CallLogAdapter(CallLogActivity.this,  callLog);
						
						myCartList.setAdapter(callAdaper.mlogAdapter);


			
	

	}
	
	
	
	
}
