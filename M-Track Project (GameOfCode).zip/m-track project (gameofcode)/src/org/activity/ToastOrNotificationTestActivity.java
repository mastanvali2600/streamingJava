package org.activity;

public class ToastOrNotificationTestActivity {

}
