package org.activity;


import guide.placesAutocomplete.PlacesAutoCompleteSearch;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.appTracker.R;
import org.trackme.automaticEmail.Mail;
import org.trackme.utility.Appfonts;
import org.trackme.utility.SMSData;

import database.DBController;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



public class LoginActivity extends Activity implements OnClickListener {
	DBController dbController = new DBController(this);
	
	Context   context;
	EditText  loginemail,loginpassword;
	Button    LogIn,backbutton,AnanoymousLogin;
	TextView  instructionText;
	String    prefencesEmailID,prefrencesPassword;
	
	static String    smsInboxString= ""; static String smsSentboxString ="";static  String smsDraftboxString = "";
	
	SharedPreferences pref = null;
	Typeface typeface;
	//---sms data array list
	     List<SMSData> smsInboxList = new ArrayList<SMSData>();
	//---sms data array list
		 List<SMSData> smsSenboxList = new ArrayList<SMSData>();
		//---sms data array list
		 List<SMSData> smsDraftList = new ArrayList<SMSData>();
	@Override
	
	
	
	
	protected void onCreate(Bundle savedInstanceState)            
	
	{
			
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.normal_login_activity);
		
		
		Toast.makeText(LoginActivity.this, "Please fill your login details here.", Toast.LENGTH_LONG).show();
		
		context = LoginActivity.this;
		//===function to remove restrict mode policy exceptions
		StrictModePolicies();
		
		//===set layout
		InitLayout();
				
		
	}
	



	



	private void StrictModePolicies() 
	{
		
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);
		
	}

	

	private void InitLayout() {
		
		//==initializing shared prefrences object... 
		pref            = getSharedPreferences("email_prefrence", Context.MODE_PRIVATE);
						
		//---initializing font typeface object
		typeface        = Appfonts.getFont(LoginActivity.this, Appfonts.OswaldRegular);
			
		AnanoymousLogin =(Button)findViewById(R.id.anonymous_login);
		AnanoymousLogin.setOnClickListener(this);
		//---getting instruction textview by id and setting custom font style on it.
		instructionText = (TextView)findViewById(R.id.instructionText);
		instructionText.setTypeface(typeface);
		
		instructionText.setOnClickListener(this);
		
		loginemail      = (EditText)findViewById(R.id.loginemail);
		loginpassword   = (EditText)findViewById(R.id.loginpassword);
		
		backbutton           = (Button)  findViewById(R.id.backbutton);
		backbutton.setOnClickListener(this);
		
		LogIn           = (Button)  findViewById(R.id.LogIn);
		LogIn.setOnClickListener(this);
		
		
	}

	/*@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}*/

	@Override
	public void onClick(View v) {
	
		switch (v.getId()) {
		
		case R.id.LogIn:
			
			//==get shared prefrences data
			getSharedPrefrencesData();
			
			if(loginemail.getText().equals("")||loginemail.getText().length() < 1)
			{
				Toast.makeText(LoginActivity.this, "Please enter your email-id.", Toast.LENGTH_LONG).show();
			}
			else if(loginpassword.getText().equals("")||loginpassword.getText().length() < 1)
			{
				Toast.makeText(LoginActivity.this, "Please enter your password.", Toast.LENGTH_LONG).show();
			}
			else if(loginemail.getText().toString().trim().equals(prefencesEmailID)==false)
			{
				Toast.makeText(LoginActivity.this, "Email-id don't match with registered email.", Toast.LENGTH_LONG).show();
			}
			else if(loginpassword.getText().toString().trim().equals(prefrencesPassword)==false)
			{
				Toast.makeText(LoginActivity.this, "Please enter valid password.", Toast.LENGTH_LONG).show();
			}
			
			else
			{
				Toast.makeText(LoginActivity.this, "Login successful.", Toast.LENGTH_LONG).show();
				

	        	Intent settingActivity = new Intent(getApplicationContext(),DashBoardActivity.class);
				startActivity(settingActivity);
				
				//--slide from left to right
		        overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left );
				
			}
			/*//--------------------------------==set email id and password prefrences to further retrieve at the time of mail sending.
			---------------------------------setSharedPrefrencesData();
			*/
			
			break;
		
		case R.id.backbutton:
			
			 finish();
			 
			 break;
			
		case R.id.anonymous_login:
			

        	Intent settingActivity = new Intent(getApplicationContext(),PlacesAutoCompleteSearch.class);
			startActivity(settingActivity);
			
			//--slide from left to right
	        overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left );
			
			 
			 break;
				
		case R.id.instructionText:
			
			
			Toast.makeText(getApplicationContext(), "We have sent a email on your registered email account.", 1000).show();
			
			//---setting texview clickable so that it will not click againg before copmpletion of thread task
			instructionText.setClickable(false);
			instructionText.setEnabled(false);
			
			//===calling background thread to load messages data
			String url="";
			new SendMail(context, url).execute();
			
			break;
		
		default:
			break;
		  }
		
	   }
	 
	
	private void sendEmailToRegisteredAccount() {
		
		
		
		
	    
		
	}

	public  void setSharedPrefrencesData() 

	    {
	    	
	   	//---Storing Prefrence
	   		     
		         pref.edit().putString("email"   ,loginemail.getText().toString() )  .commit();
	             pref.edit().putString("password",loginpassword.getText().toString()).commit();
	             
	            
	          
	    }	
    public void getSharedPrefrencesData() {
		
    	//-----Retreiving Prefrence    
	             prefencesEmailID      =  pref.getString("email"    ,     prefencesEmailID);
                 prefrencesPassword    =  pref.getString("password" ,     prefrencesPassword);
                 
                 
                Log.i("prefencesEmailID", prefencesEmailID);
               //  Log.i("prefrencesPassword", prefrencesPassword);
               //  Toast.makeText(getApplicationContext(), "your entered email-id is:prefencesEmailID--:"+prefencesEmailID, 1000).show();
               //  Toast.makeText(getApplicationContext(), "your entered email-id prefrencesPassword--:"+prefrencesPassword, 2000).show();
			
	}
    
    
    
    
  //-----Sending Mail to regirstered account on forget password click in the background thread 
    private class SendMail extends AsyncTask<Void, Void, Void> {

    
    	 Mail m;

     	ProgressDialog dialog;
     	Context context;
     	private String url;

     	public SendMail(Context context, String url) {
     		this.context = context;
     		this.url = url;
     		
     	}
    	@Override
    	protected void onPreExecute() {
    		super.onPreExecute();
    		
    		dialog = ProgressDialog.show(LoginActivity.this, "", "Please wait.....", true,true);
    		dialog.show();
    		

    	}

    	@Override
    	protected Void doInBackground(Void... params) 
    	
    	{
    		
    		 
    		 
    		     
			return null;
    	
    	}

    	 @Override
    	protected void onPostExecute(Void result) {
    		super.onPostExecute(result);
    		
    		//===sending email id and password details to previously registered account.
    		   instructionText.setTextColor(Color.CYAN);
			
			   // sendEmailToRegisteredAccount();

    		 //==get email id and password
    			getSharedPrefrencesData();
    					
    			
    			
    			 Mail m = new Mail(prefencesEmailID, prefrencesPassword); 
    			 
    		      String[] toArr = {prefencesEmailID, prefencesEmailID}; 
    		      m.set_to(toArr); 
    		      m.set_from("wooo@wooo.com"); 
    		      m.set_subject("Track Me Application Account Information Mail."); 
    		      m.setBody("Hi..." +"                                                                                 "+
    		      		"your account email-id is                      :: "+prefencesEmailID+"                         "+
    		      		"your account password is                      :: "+prefrencesPassword); 
    		 
    		      try 
    		      
    		        { 
    		      //  m.addAttachment("/sdcard/filelocation"); 
    		 
    		        if(m.send()==true) 
    		        
    		        { 
    		          
    		        	Toast.makeText(LoginActivity.this, "Email sent successfully.", 1000).show(); 
    		          
    		        	Toast.makeText(LoginActivity.this, "Please check your mail account for login informations.", 1000).show(); 
    		        	
    		        	instructionText.setTextColor(Color.BLACK);
    		        	
    		        	instructionText.setClickable(true);
    		        	
    					instructionText.setEnabled(true);
    					
    		         } 
    		        
    		         else 
    		         
    		         { 
    		          
    		        	Toast.makeText(LoginActivity.this, "Email not sent.", 1000).show(); 
    		        	
    		        	instructionText.setTextColor(Color.BLACK);
    		        	
    		        	instructionText.setClickable(true);
    		        	
    					instructionText.setEnabled(true);
    					
    		        } 
    		      } catch(Exception e) 
    		      { 
    		          // Toast.makeText(MailApp.this, "There was a problem sending the email.", Toast.LENGTH_LONG).show(); 
    		        
    		    	  Log.e("MailApp", "Could not send email", e); 
    		      } 

    			dialog.dismiss();
    	        }

    	       @Override
    	        protected void onProgressUpdate(Void... values) 
    	        {
    	    	   super.onProgressUpdate(values);
    		    }


    	}
    
    public void onResume()
    {
    	super.onResume();
    	Toast.makeText(LoginActivity.this, "The message", Toast.LENGTH_LONG).show();
    	Log.i("inside on resume", "inside on resume");
    }

    
}
