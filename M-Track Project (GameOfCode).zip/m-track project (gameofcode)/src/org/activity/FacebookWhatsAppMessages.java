package org.activity;



import java.util.ArrayList;
import java.util.HashMap;

import org.adapter.BrowserAdapter;
import org.adapter.WhatsAppAdapter;
import org.appTracker.R;
import org.trackme.utility.WhatsAppData;
import database.DBController;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class FacebookWhatsAppMessages extends Activity            {
	
	WebView teamsConditonsWebView;
	
	public static ArrayList<HashMap<String, String>> UserData = new ArrayList<HashMap<String, String>>();
	Button back_btn;	
    Context context;	
	ArrayList<WhatsAppData> NotificationLog = new ArrayList<WhatsAppData>();	
	WhatsAppAdapter notificationAdaper;   
	ListView NotificationListview;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)   
	
	{		
		super.onCreate(savedInstanceState);		
        requestWindowFeature(Window.FEATURE_NO_TITLE);		
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);		
	    setContentView(R.layout.facebook_whats_app_messages);	
	    context = FacebookWhatsAppMessages.this;	
        NotificationListview = (ListView)findViewById(R.id.NotificationListview); 
    
    
    
     //---get browser history
    GetNotificationMessages();  	

  	//------activity adapter  	
  	notificationAdaper   =   new WhatsAppAdapter(  context,  UserData);  				
  	NotificationListview.setAdapter(notificationAdaper.mNofiAdapter);

    Log.i("size of arraylist", String.valueOf(UserData.size()));
  	if(UserData.size()<1)
  	{
	AlertDialog.Builder alert = new AlertDialog.Builder(FacebookWhatsAppMessages.this);	
	alert.setMessage ("To get messages allow access in device setting: Go to Settings >> Accessibility  >> M-Track and set M-Track checked.");	
	alert.setPositiveButton("Ok",			
			new DialogInterface.OnClickListener() {public void onClick(DialogInterface dialog,int whichButton) 
			    {				
					 dialog.dismiss();					
				}
			});
	
	alert.show();
  	}
	
}

	
	//---Method to get Notification msg list
	private void GetNotificationMessages() 
	{
		
		DBController dbController = new DBController(this);		
		UserData.clear();		
		UserData = dbController.getUserNotiMsgData();
		
	/*    //	Log.e("user location array size-----------", String.valueOf(UserData.size()));
		
		//----adding header to the location data details...
	String	NotificationInformation = String.valueOf(Html.fromHtml(new StringBuilder() 
		
		        .append("<br><p><b><marquee><font color='#145A14'>User Facebook , Whats App and other chatting application Data Detail are as given below:-----------------------------</font></marquee></b></p><br>")
		
		.toString()));

		//---converterting order list data into html format...
		for(int i=0;i< UserData.size();i++)
		
		{
		
			NotificationInformation  =	NotificationInformation + String.valueOf(Html.fromHtml(new StringBuilder()
	           
			    .append("<br><br><p><b><font color='#145A14'> Sr. No -:</font></b><b>"+UserData.get(i).get("Id")+"</b></p>")
	            
	            .append("<p><b><font color='#145A14'>Message   -:</font></b><b>"+UserData.get(i).get("NotificationMsg")+"</b></p>")
	            
	            .append("<p><b><font color='#145A14'> From   -:</font></b><b>"+UserData.get(i).get("MsgFrom")+"</b></p>")
	                
	            .append("<p><b><font color='#145A14'> Time   -:</font></b><b>"+UserData.get(i).get("NotificationTime")+"</b></p>")
	            
	            .toString()));

		}
		*/
	//Log.i("LocationInformation",LocationInformation);
	}

/*if(UserData.size() > 0)
{
	// ------activity adapter
	//---get browser history
		getNotificationMessagesList();
		
	//========================================================================================================
	
	}
*/
	public void getNotificationMessagesList()   
	 {
		DBController dbController = new DBController(this);		
		UserData.clear();		
		UserData = dbController.getUserNotiMsgData(); 		
		Log.i("Nofitification size", String.valueOf(UserData.size()));
		
     }

}
