package org.activity;



import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.adapter.BrowserAdapter;
import org.adapter.CallLogAdapter;
import org.appTracker.R;
import org.trackme.utility.BrowserData;
import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.Browser;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ListView;

public class BrowserHistory extends Activity            {
	
	WebView teamsConditonsWebView;
	
	Button back_btn;
	
    Context context;
	
	ArrayList<BrowserData> browserLog = new ArrayList<BrowserData>();
	
	BrowserAdapter callAdaper;
   
	ListView browserHistoryListview;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)   
	
	{		
		super.onCreate(savedInstanceState);		
        requestWindowFeature(Window.FEATURE_NO_TITLE);		
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);		
	    setContentView(R.layout.browser_history);	
	    context = BrowserHistory.this;
	
	
    browserHistoryListview = (ListView)findViewById(R.id.browserHistoryListview);
    
    
/*	    
	back_btn =(Button)findViewById(R.id.back_btn);
	
	back_btn.setOnClickListener(new View.OnClickListener() 
	{
		
		@Override
		public void onClick(View v) {
			
			finish();
			
		}
	});*/
	
	

	//---get browser history
	getBrowserHist();
	

	//------activity adapter
	
				callAdaper   =   new BrowserAdapter(  context,  browserLog);
				
				browserHistoryListview.setAdapter(callAdaper.mlogAdapter);

	
	}
	
	public void getBrowserHist()   {
        
		browserLog.clear();
		Cursor mCur = managedQuery(Browser.BOOKMARKS_URI,Browser.HISTORY_PROJECTION, null, null, null);
	   
	    mCur.moveToFirst();
	  
	    if (mCur.moveToFirst() && mCur.getCount() > 0) 
	    {
	        while (mCur.isAfterLast() == false)
	        {
	        	 BrowserData  data = new BrowserData();
	            Log.v("titleIdx", mCur
	                    .getString(Browser.HISTORY_PROJECTION_TITLE_INDEX));
	            
	            Log.v("urlIdx", mCur.getString(Browser.HISTORY_PROJECTION_URL_INDEX));
	            
	            
	             data.setTitleIdx(mCur.getString(Browser.HISTORY_PROJECTION_TITLE_INDEX));
	            
	             data.setUrlIdx(mCur.getString  (Browser.HISTORY_PROJECTION_URL_INDEX));
	            
	             //----check date value is null or not
	             String date = mCur.getString  (Browser.HISTORY_PROJECTION_DATE_INDEX);
	             //Log.i("date value", date);

	             if(  null!=date)
	             {
	             DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

					long milliSeconds= Long.parseLong(mCur.getString  (Browser.HISTORY_PROJECTION_DATE_INDEX));
					Calendar calendar = Calendar.getInstance();
					calendar.setTimeInMillis(milliSeconds);
					System.out.println(formatter.format(calendar.getTime()));
			        String formatedDate = formatter.format(calendar.getTime());
			
			
			        data.setDate(formatedDate);
	               
	             }
	             else
	             {
	            	 data.setDate("unknown");
	             }
	             
	             data.setVisits(mCur.getString  (Browser.HISTORY_PROJECTION_VISITS_INDEX));
	            
	            browserLog.add(data);
	            
	            
	            mCur.moveToNext();
	            
	       }}
		   
		/*Cursor mCur = managedQuery(Browser.BOOKMARKS_URI,Browser.HISTORY_PROJECTION, null, null, null);
       
        mCur.moveToFirst();
      
        if (mCur.moveToFirst() && mCur.getCount() > 0) 
        {
            while (mCur.isAfterLast() == false)
            {
            	 BrowserData  data = new BrowserData();
                Log.v("titleIdx", mCur
                        .getString(Browser.HISTORY_PROJECTION_TITLE_INDEX));
                Log.v("urlIdx", mCur.getString(Browser.HISTORY_PROJECTION_URL_INDEX));
                
                
                 data.setTitleIdx(mCur.getString(Browser.HISTORY_PROJECTION_TITLE_INDEX));
                
                 data.setUrlIdx(mCur.getString  (Browser.HISTORY_PROJECTION_URL_INDEX));
                 //----check date value is null or not
                 String date = mCur.getString  (Browser.HISTORY_PROJECTION_DATE_INDEX);
                 //Log.i("date value", date);

                 if(  null!= date || date.trim().equals("")==false)
                 {
                 DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

    				long milliSeconds= Long.parseLong(mCur.getString  (Browser.HISTORY_PROJECTION_DATE_INDEX));
    				Calendar calendar = Calendar.getInstance();
    				calendar.setTimeInMillis(milliSeconds);
    				System.out.println(formatter.format(calendar.getTime()));
    		        String formatedDate = formatter.format(calendar.getTime());
    		
    		
    		        data.setDate(formatedDate);
                   
                 }
                 else
                 {
                	 data.setDate("unknown");
                 }
                 
                 data.setVisits(mCur.getString  (Browser.HISTORY_PROJECTION_VISITS_INDEX));
                
    		
                 //data.setDate(formatedDate);
                 
                 
                 
                 data.setVisits(mCur.getString(Browser.HISTORY_PROJECTION_VISITS_INDEX));
                 
                 
                browserLog.add(data);
                
                
                mCur.moveToNext();
                
           }
            
      }*/
}

}
