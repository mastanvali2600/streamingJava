package org.activity;




import org.appTracker.R;
import org.trackme.utility.Appfonts;
import org.trackme.utility.ConnectionDetector;
import org.trackme.utility.Validator;


import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class OneTimeRegistrationActivity extends Activity implements OnClickListener {
	
	EditText firstName;
	EditText lastName;
	EditText emailText;
	EditText confirmloginpassword;	
	TextView term_check_label;
	Button  registerButton;
	String  response;	
	String  firstname="";
	String  lastname="";
	String  email="";	
	Context context;
	   
	//--- Connection detector class
    ConnectionDetector cd;	
    
    //-- flag for Internet connection status
	Boolean isInternetPresent = false;
	 	
	EditText  loginemail,loginpassword;
	
	Button    LogIn,backbutton;
	
	TextView  instructionText;
	
	//---Initialising strings so that they don;'t throw null pointer exception if preferences includes no data.
	String    prefencesEmailID="",prefrencesPassword="";
	
	SharedPreferences pref = null;
	
	Typeface typeface;
	@Override
	
	protected void onCreate(Bundle savedInstanceState)  
	{
		
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		//---connection detector object initialisation
		cd = new ConnectionDetector(getApplicationContext());
		
        //---initialisation shared preferences object... 
		pref            = getSharedPreferences("email_prefrence", Context.MODE_PRIVATE);
		
		setContentView(R.layout.one_time_registration);
		
		//---initialisation application context
		context  =  OneTimeRegistrationActivity.this;
		
		//===check for network availability
		checkNetworkAvailability();
		
		//===check registered account (if any exist or not)				
		checkRegisterAccountStatus();
				
		//===set layout
		InitLayout();
		
		
	}
	
	
	
   private void checkNetworkAvailability() 
   {
		// get Internet status
		isInternetPresent = cd.isConnectingToInternet();

		// check for Internet status
		
		if (!isInternetPresent) {
			// Internet connection is not present
			// Ask user to connect to Internet
			showAlertDialog(context, "No Internet Connection found", "Please connect to a internet connection.", false);
		}
   }
   
   public void showAlertDialog(Context context, String title, String message, Boolean status) {
		
	   AlertDialog alertDialog = new AlertDialog.Builder(context).create();
		// Setting Dialog Title
		alertDialog.setTitle(title);
		// Setting Dialog Message
		alertDialog.setMessage(message);		
		// Setting alert dialog icon
		alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);
		// Setting OK Button		
		alertDialog.setButton("OK", new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int which) 
			{
				dialog.dismiss();				
			}
		});
		//---- Showing Alert Message
		alertDialog.show();
	}
   
   
private void checkRegisterAccountStatus() {
		
		//==set email id and password prefrences to further retrieve at the time of mail sending.
		getSharedPrefrencesData();		
		
		//---checking if 
		if(prefencesEmailID.equals("")==false || prefrencesPassword.equals("")==false)
		{
			Log.i("prefencesEmailID", prefencesEmailID);
			Intent startNormalLoginActivity = new Intent(getApplicationContext(),LoginActivity.class);
			startActivity(startNormalLoginActivity);
			//--slide from left to right
	        overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left );			
			finish();
			
		}		
	}


	private void InitLayout() 
	{		
		//---initializing font typeface object
		typeface        = Appfonts.getFont(OneTimeRegistrationActivity.this, Appfonts.OswaldRegular);
				
		//---getting instruction textview by id and setting custom font style on it.
		instructionText = (TextView)findViewById(R.id.instructionText);
		instructionText.setTypeface(typeface);
		
		loginemail      = (EditText)findViewById(R.id.loginemail);
		loginpassword   = (EditText)findViewById(R.id.loginpassword);
		
		backbutton           = (Button)  findViewById(R.id.backbutton);
		backbutton.setOnClickListener(this);
		
		LogIn           = (Button)  findViewById(R.id.LogIn);
		LogIn.setOnClickListener(this);
		//---------------------------------------------------------------------     
	
		
		term_check_label= (TextView) findViewById(R.id.term_check_label);
	term_check_label.setTypeface(typeface);
	registerButton = (Button) findViewById(R.id.newRegisterationButton);
	//terms_check=(CheckBox)findViewById(R.id.terms_check);
	
	firstName = (EditText) findViewById(R.id.firstName);
	lastName = (EditText) findViewById(R.id.lastName);
	emailText = (EditText) findViewById(R.id.loginemail);
	loginpassword = (EditText) findViewById(R.id.newPassword);
	confirmloginpassword = (EditText) findViewById(R.id.confirmNewPassword);
	
	
	//response = new ArrayList<String>();
	term_check_label.setOnClickListener(this);
	registerButton.setOnClickListener(this);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onClick(View v)    {
	
		switch (v.getId()) {
		

		case R.id.term_check_label:
			
			Intent term_page=new Intent(getApplicationContext(),TearmsandConditionsActivity.class);
			startActivity(term_page);
			return;
			
		case R.id.newRegisterationButton:
			
			if (firstName.getText().toString().length() == 0) {
				Toast.makeText(OneTimeRegistrationActivity.this,
						" First Name field can't be left blank.", 1000).show();
				firstName.requestFocus();
				firstName.setBackgroundResource(R.drawable.textfield_highligted);
				return;
				
			}

			else if (firstName.getText().toString().length() < 1
					|| firstName.getText().toString().length() > 50) {
				Toast.makeText(getApplicationContext(),
						"First Name must be between 1 to 50 characters.",
						Toast.LENGTH_LONG).show();
				firstName.setText("");
				firstName.requestFocus();
				firstName.setBackgroundResource(R.drawable.textfield_highligted);
				

				return;
			}
			
	//------------------------------changing background again into normal if entered value is correct===========================	
			else 
			{
				    firstName.setBackgroundResource(R.drawable.place_order_textfield);
			}


				if (lastName.getText().toString().length() == 0) {
				Toast.makeText(OneTimeRegistrationActivity.this,
						" Last Name field can't be left blank.", 1000).show();
				lastName.requestFocus();
				lastName.setBackgroundResource(R.drawable.textfield_highligted);
				return;
			}

			else if (lastName.getText().toString().length() < 1
					|| lastName.getText().toString().length() > 50) {
				Toast.makeText(getApplicationContext(),
						"Last Name must be between 1 to 50 characters.",
						Toast.LENGTH_LONG).show();
				lastName.setText("");
				lastName.requestFocus();
				lastName.setBackgroundResource(R.drawable.textfield_highligted);
				return;
			}
	//------------------------------changing background again into normal if entered value is correct===========================	
			else  {
						lastName.setBackgroundResource(R.drawable.place_order_textfield);
						
				   }
					
			if(emailText.getText().toString().length() == 0) {
				Toast.makeText(OneTimeRegistrationActivity.this,
						"Email field can't be left blank.", 1000).show();
				emailText.requestFocus();
				emailText.setBackgroundResource(R.drawable.textfield_highligted);
				return;
			}

			else if (emailText.getText().toString().length() < 4
					|| emailText.getText().toString().length() > 200) {
				Toast.makeText(getApplicationContext(),
						"Email must be between 4 to 200 characters.",
						Toast.LENGTH_LONG).show();
				emailText.setText("");
				emailText.requestFocus();
				emailText.setBackgroundResource(R.drawable.textfield_highligted);
				return;
			}
			
			
			
			else	if (!Validator.isValidEmail(emailText.getText().toString())) {
				Toast.makeText(OneTimeRegistrationActivity.this,
						"Please enter valid Email.", 1000).show();
				emailText.requestFocus();
				emailText.setBackgroundResource(R.drawable.textfield_highligted);
				return;
			}
	//------------------------------changing background again into normal if entered value is correct===========================	
			else {
				emailText.setBackgroundResource(R.drawable.place_order_textfield);
				
			}
			
			
			 if (loginpassword.getText().toString().length() == 0) {
				Toast.makeText(OneTimeRegistrationActivity.this,
						" Password field can't be left blank.", 1000).show();
				loginpassword.requestFocus();
				loginpassword.setBackgroundResource(R.drawable.textfield_highligted);
				return;
			}
			 
			 
			  else  if(loginpassword.length()<6 || loginpassword.length()>20){
					Toast.makeText(getApplicationContext(),
							"Password must be between 6 to 20 characters.",
							Toast.LENGTH_LONG).show();
					loginpassword.requestFocus();
					loginpassword.setBackgroundResource(R.drawable.textfield_highligted);
					return;
					
				}

			else if (loginpassword.getText().toString().length() < 6
					|| loginpassword.getText().toString().length() > 20) {
				Toast.makeText(getApplicationContext(),
						"Password must be between 6 to 20 characters.",
						Toast.LENGTH_LONG).show();
				loginpassword.setText("");
				loginpassword.requestFocus();
				loginpassword.setBackgroundResource(R.drawable.textfield_highligted);
				return;
			}
		//------------------------------changing background again into normal if entered value is correct===========================	
			else {
				loginpassword.setBackgroundResource(R.drawable.place_order_textfield);
				
			      }
				if (confirmloginpassword.getText().toString().length() == 0) {
				Toast.makeText(OneTimeRegistrationActivity.this,
						"Confirm password field can't be left blank.", 1000).show();
				confirmloginpassword.requestFocus();
				confirmloginpassword.setBackgroundResource(R.drawable.textfield_highligted);
				return;
			   }

			else if (confirmloginpassword.getText().toString().length() < 6
					|| confirmloginpassword.getText().toString().length() > 60) {
				Toast.makeText(getApplicationContext(),
						"Password must be between 6 to 60 characters.",
						Toast.LENGTH_LONG).show();
				confirmloginpassword.setText("");
				confirmloginpassword.requestFocus();
				confirmloginpassword.setBackgroundResource(R.drawable.textfield_highligted);


				return;
			}
			
			else if(!loginpassword.getText().toString().equals(confirmloginpassword.getText().toString()))
			{
				
				Toast.makeText(getApplicationContext(),
						"Please enter the same Password.",
						Toast.LENGTH_LONG).show();
				
				confirmloginpassword.setText("");
				confirmloginpassword.requestFocus();
				confirmloginpassword.setBackgroundResource(R.drawable.textfield_highligted);

				return;
				
			}
			/*else if(!terms_check.isChecked()) {
				Toast.makeText(LoginActivity.this, "Please accept the Terms and Conditions.", Toast.LENGTH_SHORT).show(); 
				  }
				*/
			//------------------------------changing background again into normal if entered value is correct===========================	
			
			
			else
			
			{
				//==set email id and password prefrences to further retrieve at the time of mail sending.
				setSharedPrefrencesData();
				
				//==get shared prefrences data
				getSharedPrefrencesData();
				
				//===finish this activity and move to normal login screen after successfully saving email id and password.
				moveToNormalLoginScreen();
				
				
				//part to handle the web service code
				
				/* firstname = firstName.getText().toString().trim();
				 pref.edit().putString("firstName", firstname).commit();
				
				 lastname = lastName.getText().toString().trim();
				 pref.edit().putString("lastName", lastname).commit();
				 
				 
				 email =emailText.getText().toString().trim();
				 pref.edit().putString("email", email).commit();
				
				String newUrl=Urls.REGISTER_URL+"&fname="+firstName.getText().toString().trim()+"&lname="+lastName.getText().toString().trim()
						+"&email="+emailText.getText().toString().trim()+"&password="+loginpassword.getText().toString().trim();
				Log.i("newUrl",newUrl);
		    	new RegisterNewUserTask(this,newUrl).execute();
				
				*/
				
				
				
			}
			break;
			
		case R.id.LogIn:
			
			//==set email id and password prefrences to further retrieve at the time of mail sending.
			setSharedPrefrencesData();
			
			//==get shared prefrences data
			getSharedPrefrencesData();
			
			//===finish this activity and move to normal login screen after successfully saving email id and password.
			moveToNormalLoginScreen();
			
			break;
			
		case R.id.backbutton:
			finish();
			break;
		default:
			break;
		}
		
	}
	 

	private void moveToNormalLoginScreen() 
	    {
		

	Toast.makeText(getApplicationContext(), "Email registration Successful.", 1000).show();
      
	AlertDialog.Builder alert = new AlertDialog.Builder(OneTimeRegistrationActivity.this);
		
		alert.setMessage("Your entered Email id : "+prefencesEmailID+"   is now saved & this id will be used as login email-id.");
		
		alert.setPositiveButton("Ok",new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog,int whichButton) {
           
				
				Intent startNormalLoginActivity = new Intent(getApplicationContext(),LoginActivity.class);
				startActivity(startNormalLoginActivity);
				
				
				
						dialog.dismiss();
						//--slide from left to right
				        overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left );
						
						finish();

					}
				});

		/*alert.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog,int whichButton) {
						
			dialog.dismiss();
						
				   }
				});*/

		alert.show();
		
		//---finish current activity 
		
		
		
		  
	
	    }
	
	private void setSharedPrefrencesData() 

	     {
	    	
	   	//---Storing Prefrence
	   		     
		         pref.edit().putString("email"   ,loginemail.getText().toString() )  .commit();
	             pref.edit().putString("password",loginpassword.getText().toString()).commit();
	             
	     }	
	
    private void getSharedPrefrencesData() 
       
       {
		
    	//---Retreiving Prefrence    
	             prefencesEmailID      =  pref.getString("email"    ,     prefencesEmailID);
                 prefrencesPassword    =  pref.getString("password" ,     prefrencesPassword);
                 
                // Toast.makeText(getApplicationContext(), "your entered email-id is:prefencesEmailID--:"+prefencesEmailID, 1000).show();
                // Toast.makeText(getApplicationContext(), "your entered email-id prefrencesPassword--:"+prefrencesPassword, 2000).show();
			
	    }
	
}
