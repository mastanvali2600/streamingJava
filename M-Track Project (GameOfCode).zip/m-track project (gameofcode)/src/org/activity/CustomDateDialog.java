package org.activity;


import java.util.Calendar;
import org.appTracker.R;

import org.trackme.utility.Constants;
import org.trackme.utility.TimePicker;
import org.trackme.utility.TimePicker.TimeWatcher;




import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;

import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class CustomDateDialog extends Activity implements TimeWatcher,OnClickListener {
	
	TimePicker t;
	
	private         Button           backbutton,   cancel,confirm;
	
	public	static	String				CurrentCustomerName	="Guest";
	
	TimePicker timepicker;
	
	ImageView icon_image;
	
	TextView title;
	
	final Context context = this;
	
	public String eventID,Result,calenderSelectedDate,timePickerSelectedTime;
	
	int button_id;
	
	String web_response, line;
	
	String server_request;
	
	SharedPreferences pref = null;
	/** Called when the activity is first created. */
	
	@Override
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.custom_alert_dialog_layout);
		
		//-------initialisation shared preferences object... 
		pref     = getSharedPreferences("email_prefrence", Context.MODE_PRIVATE);
		
		
		
		Calendar c=Calendar.getInstance();
		calenderSelectedDate=c.get(Calendar.MONTH)+1+ "-" + c.get(Calendar.YEAR) + "-" + c.get(Calendar.DAY_OF_MONTH);
//----------------Intent to receive id from RequestForServices-------------------------------
		Bundle extras = getIntent().getExtras();
		if (extras == null) {
		Log.e("No id recieved", "No id recieved");
		
		   //.......do nothing.....
		}
		   else 
		{
// Get data via the key
		  button_id= extras.getInt("ID");
		  
		  Log.e("ID..",String.valueOf(button_id));
		  
		  }
		

		 initViews();  
		 SetValues();
	
		    timepicker.setTimeChangedListener(this);
			timepicker.setCurrentTimeFormate(TimePicker.HOUR_12);
		    timepicker.setAMPMVisible(true);
//---------------------timepicker and Time Picker changeListeners----------------------		
		//timepicker.setDateChangedListener(this);
		
//-----------------------------------------------------------------------------------------		
  }

	private void SetValues() {
		// TODO Auto-generated method stub
		
	}

	private void initViews() {
		 cancel = (Button)findViewById(R.id.dialogButtonCancel);	
		
        //  icon_image     =(ImageView)findViewById(R.id.icon_image);
		 title =(TextView)findViewById(R.id.title);
		//--- comments=(EditText)findViewById(R.id.comments_editText);
		 timepicker = (TimePicker) findViewById(R.id.datePicker1);
		//--- timepicker = (TimePicker) findViewById(R.id.timePicker1);
		 confirm = (Button)findViewById(R.id.dialogButtonOK);
		 
		 
		 confirm.setFocusable(false);
		 cancel.setOnClickListener(this);
		 confirm.setOnClickListener(this);
		 
		 
		//------------------code to remove auto focus of editText
			
		
	}

	
	
	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) {
		
		
		case R.id.dialogButtonOK:
			
           
		Toast.makeText(getApplicationContext(), "Email timing saved Successfully on "+timePickerSelectedTime, 1000).show();
		
		//----editing shared prefrences email timing value
		pref.edit().putString("emailTime"   ,timePickerSelectedTime.toString() )  .commit();
		// CreditCardEntry.month_and_year.setText("");
   	 CustomDateDialog.this.finish();
   	 
			break;
			
         case R.id.dialogButtonCancel:
			
        	// CreditCardEntry.month_and_year.setText("");
        	 CustomDateDialog.this.finish();
        	 
			break;
			
		default:
			
			break;
		}
		
	
	}



	

	@Override
	public void onTimeChanged(int h, int m, int am_pm)  {
		
		if(am_pm==0)
		{
			timePickerSelectedTime=+ h + "-" + m + "am";
		}
		else
		{
			timePickerSelectedTime=+ h + "-" + m + "pm";
		}
		
		/*
		 * timePickerSelectedTime=+ h + "-" + m + "-" +"*"+am_pm;
		*/
		
		if(am_pm==1)
		{
			if(h==1)
			{
				h = 13;
			}
			
			if(h==2)
			{
				h = 14;
			}
			
			if(h==3)
			{
				h = 15;
			}
			
			if(h==4)
			{
				h = 16;
			}
			
			if(h==5)
			{
				h = 17;
			}
			
			if(h==6)
			{
				h = 18;
			}
			
			if(h==7)
			{
				h = 19;
			}
			
			if(h==8)
			{
				h = 20;
			}
			
			if(h==9)
			{
				h = 21;
			}
			
			if(h==10)
			{
				h = 22;
			}
			
			if(h==11)
			{
				h = 23;
			}
			
			if(h==12)
			{
				h = 24;
			}
		}
		
		Constants.emailHour = h;
		
		Constants.emailMin  = m;
		
	
		
		Log.e("hi...", "" + h + " " + m + " "+am_pm);
		
	}

	
}
