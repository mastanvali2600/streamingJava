package org.activity;



import org.appTracker.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;

public class TearmsandConditionsActivity extends Activity {
	
	WebView teamsConditonsWebView;
	
	Button back_btn;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
        requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
	    setContentView(R.layout.termsandconditionsscreen);
	
	
	back_btn =(Button)findViewById(R.id.back_btn);
	
	back_btn.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			
			finish();
			
		}
	});

	teamsConditonsWebView= (WebView) findViewById(R.id.tearmsandconditionsWebview);
	
	teamsConditonsWebView.loadUrl("file:///android_asset/tandc.html");
	
	
	}

}
