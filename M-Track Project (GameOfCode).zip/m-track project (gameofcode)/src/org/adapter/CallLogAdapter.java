package org.adapter;

import java.util.ArrayList;
import org.appTracker.R;
import org.trackme.utility.BrowserData;
import org.trackme.utility.CallData;
import org.trackme.utility.SMSData;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;


import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Handler;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.TextView;

public class CallLogAdapter extends BaseAdapter {
	

	ArrayList<CallData> callLog = new ArrayList<CallData>();
	
	ArrayList<BrowserData> BrowserLog = new ArrayList<BrowserData>();
	Context context;
	Typeface typeface;

	
	Handler handler;
    Activity a;
	Runnable runnable;
	

       //********************************TourImageAdapter**************************************************
      // Event adapter constructor
	  public CallLogAdapter(Context context, ArrayList<CallData> callLog) {

		this.context	    =   context;
		this.callLog		=   callLog;
		this.a = a;
		
		 ;
		//Log.d(".....bitmap. size in the event adapter class...==", ""+imagelist.length);
	}
	  

      //********************************TourImageAdapter**************************************************
     // Event adapter constructor
	  public CallLogAdapter(Activity a,Context context, ArrayList<BrowserData> callLog) {

		this.context	    =   context;
		this.BrowserLog		=   callLog;
		this.a = a;
		
		 ;
		//Log.d(".....bitmap. size in the event adapter class...==", ""+imagelist.length);
	}


	// Baseadapter to the set the data response from web service into listview.
	 public BaseAdapter mlogAdapter  = new BaseAdapter()                      {

    @Override
		public int getCount() {
			return callLog.size();
		}

		@Override
		public Object getItem(int position) {
			return callLog.get(position);
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		class ViewHolder {
			TextView 	Name,size_tv,caller_name,call_date;
		}

		public View getView(final int position, View convertView, final ViewGroup parent) {
			final ViewHolder 	vh  ;
			CallData data ;
			//Log.e("in the get view method testing for getview",""+vh);

			if(convertView	==	null) {

				vh                    =         new                                                          ViewHolder();  
				convertView           =        LayoutInflater.from(context).inflate (R.layout.row,null,false);
				
				vh.Name         =        (TextView)     convertView                .findViewById        (R.id.lblMsg);
				vh.size_tv      =        (TextView)     convertView                .findViewById        (R.id.lblNumber);
				vh.caller_name  =        (TextView)     convertView                .findViewById        (R.id.caller_name);
				vh.call_date    =        (TextView)     convertView                .findViewById        (R.id.call_date);
				convertView.setTag(vh);
				
			}
			else 
			{
				
				vh=(ViewHolder) convertView.getTag();
				
			}	

			try
			{
				//-------------------------set Typeface of the text----------------------------------
				
				//typeface =Appfonts.getFont(context,Appfonts.OswaldRegular);

				data = callLog.get(position);
				
				vh.Name         .setText(data.getNumber());
				Log.i("callLog name",data.getNumber());
				
				
				vh.size_tv      .setText(data.getDuration());
				Log.i("callLog size",data.getDuration());
				
				
				vh.caller_name  .setText(data.getCached_name());
				
				vh.call_date .setText(data.getDate());
				
			}
                 
			catch (Exception e) 
            
			{
			
				e.printStackTrace();
				
			}
			
			return convertView;
		}
		};


	@Override
	public int getCount() {
		
		return 0;
	}


	@Override
	public Object getItem(int arg0) {
		
		return null;
	}


	@Override
	public long getItemId(int position) {
		
		return 0;
	}


	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		return null;
	}




	
	}
;

		

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////







