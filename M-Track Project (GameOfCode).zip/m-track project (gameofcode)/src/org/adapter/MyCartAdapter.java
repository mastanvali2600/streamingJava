package org.adapter;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;

import org.appTracker.R;
import org.trackme.utility.SMSData;

import database.DBController;






import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Handler;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class MyCartAdapter {
	//public static ArrayList<KakzVideoBean> list=new ArrayList<Event>();
	public static ArrayList<HashMap<String, String>> locationData = new ArrayList<HashMap<String, String>>();

	Context context,context2;
	Typeface typeface;
	public static String videoUrl = "";
	
	Handler handler;
    Activity a;
	Runnable runnable;
	

       //********************************TourImageAdapter**************************************************
      // Event adapter constructor
	  public MyCartAdapter(Context context, ArrayList<HashMap<String, String>> myCartList) {

		this.context	    =   context;
		this.locationData		=   myCartList;
		this.a = a;
		
		 ;
		//Log.d(".....bitmap. size in the event adapter class...==", ""+imagelist.length);
	}


	// Baseadapter to the set the data response from web service into listview.
	 public BaseAdapter mEventAdapter  = new BaseAdapter() {

    @Override
		public int getCount() {
			return locationData.size();
		}

		@Override
		public Object getItem(int position) {
			return locationData.get(position);
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		class ViewHolder {
			TextView 	pId,Name,price_tv,size_tv,quantity;
			ImageView   delete_btn;
		}

		public View getView(final int position, View convertView, final ViewGroup parent) {
			final ViewHolder 	vh  ;

			//Log.e("in the get view method testing for getview",""+vh);

			if(convertView	==	null) {

				vh                    =         new                                                          ViewHolder();  
				convertView           =        LayoutInflater.from(context).inflate (R.layout.row,null,false);
				
				
				vh.Name         =        (TextView)     convertView                .findViewById        (R.id.lblMsg);
				vh.size_tv      =        (TextView)     convertView                .findViewById        (R.id.lblNumber);
				
				convertView.setTag(vh);
			}
			else 
			{
				vh=(ViewHolder) convertView.getTag();
			}	

			try
			{
				//-------------------------set Typeface of the text----------------------------------
				
				//typeface =Appfonts.getFont(context,Appfonts.OswaldRegular);
				
				
				
				vh.Name  .setText(locationData.get(position).get("Time").toString());
				
				vh.size_tv   .setText(locationData.get(position).get("PlaceName").toString());
				
			
				
						}
                 catch (Exception e) {
				// TODO: handle exception
				
				e.printStackTrace();
			}
			
			return convertView;
		}
		};
	
	}
;

		

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////







