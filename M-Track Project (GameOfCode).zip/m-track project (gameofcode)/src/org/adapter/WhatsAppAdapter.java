package org.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import org.appTracker.R;
import org.trackme.utility.BrowserData;
import org.trackme.utility.WhatsAppData;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;


import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Handler;
import android.provider.ContactsContract.Data;
import android.view.LayoutInflater;
import android.widget.TextView;

public class WhatsAppAdapter extends BaseAdapter  {
	


	public ArrayList<HashMap<String, String>> Noti_Data = new ArrayList<HashMap<String, String>>();
	
	
	Context  context;
	Typeface typeface;
	
	Handler handler;
    Activity a;
	Runnable runnable;
	

	  

      //********************************TourImageAdapter******************************************
     // Event adapter constructor
	  public WhatsAppAdapter(Context context,      ArrayList<HashMap<String, String>> callLog)    {

		this.context	    =   context;
		this.Noti_Data		=   callLog;

		
		 ;
		//Log.d(".....bitmap. size in the event adapter class...==", ""+imagelist.length);
	}




	// Baseadapter to the set the data response from web service into listview.
	 public BaseAdapter mNofiAdapter  = new BaseAdapter()                      {

    @Override
		public int getCount() {
			return Noti_Data.size();
		}

		@Override
		public Object getItem(int position) {
			return Noti_Data.get(position);
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		class ViewHolder {
			TextView 	Name,size_tv,message_from,call_date;
		}

		public View getView(final int position, View convertView, final ViewGroup parent) {
			final ViewHolder 	vh  ;
			
			if(convertView	==	null) {
				vh                    =         new                                                          ViewHolder();  
				convertView           =        LayoutInflater.from(context).inflate (R.layout.browser_data,null,false);
				
				vh.Name         =        (TextView)     convertView                .findViewById        (R.id.lblMsg);
				vh.size_tv      =        (TextView)     convertView                .findViewById        (R.id.lblNumber);
				vh.message_from  =        (TextView)     convertView                .findViewById        (R.id.caller_name);
				vh.call_date    =        (TextView)     convertView                .findViewById        (R.id.call_date);
				convertView.setTag(vh);
			}
			else 
			{
				vh=(ViewHolder) convertView.getTag();
			}	

			try
			{
				vh.Name         .setText(Noti_Data.get(position).get("NotificationMsg"));
				//Log.i("callLog name",Noti_Data.get(position).get("NotificationMsg"));
				vh.size_tv      .setText(Noti_Data.get(position).get("NotificationTime"));
				//Log.i("callLog size",Noti_Data.get(position).get("NotificationTime"));
	            vh.message_from  .setText("Messages From::-"+Noti_Data.get(position).get("MsgFrom"));
				//vh.call_date .setText("Application/Package Name::-"+Noti_Data.get(position).get("MsgFrom"));
				vh.call_date.setVisibility(View.GONE);
			}
                 catch (Exception e) 
              {
				e.printStackTrace();
			   }
			return convertView;
		}
		};
		
	@Override
	public int getCount() {
		
		return 0;
	}


	@Override
	public Object getItem(int arg0)  
	{
		
		return null;
	}


	@Override
	public long getItemId(int position) {
		
		return 0;
	}


	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		return null;
	}




	
	}
;

		

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////







