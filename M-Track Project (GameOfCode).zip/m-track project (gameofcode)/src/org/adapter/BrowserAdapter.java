package org.adapter;

import java.util.ArrayList;
import org.appTracker.R;
import org.trackme.utility.BrowserData;
import org.trackme.utility.CallData;
import org.trackme.utility.SMSData;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;


import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Handler;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.TextView;

public class BrowserAdapter extends BaseAdapter  {
	


	
	ArrayList<BrowserData> BrowserLog = new ArrayList<BrowserData>();
	Context context;
	Typeface typeface;

	
	Handler handler;
    Activity a;
	Runnable runnable;
	

	  

      //********************************TourImageAdapter**************************************************
     // Event adapter constructor
	  public BrowserAdapter(Context context, ArrayList<BrowserData> callLog) {

		this.context	    =   context;
		this.BrowserLog		=   callLog;

		
		 ;
		//Log.d(".....bitmap. size in the event adapter class...==", ""+imagelist.length);
	}


	// Baseadapter to the set the data response from web service into listview.
	 public BaseAdapter mlogAdapter  = new BaseAdapter()                      {

    @Override
		public int getCount() {
			return BrowserLog.size();
		}

		@Override
		public Object getItem(int position) {
			return BrowserLog.get(position);
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		class ViewHolder {
			TextView 	Name,size_tv,caller_name,call_date;
		}

		public View getView(final int position, View convertView, final ViewGroup parent) {
			final ViewHolder 	vh  ;
			BrowserData data ;
			
			if(convertView	==	null) {

				vh                    =         new                                                          ViewHolder();  
				convertView           =        LayoutInflater.from(context).inflate (R.layout.browser_data,null,false);
				
				
				vh.Name         =        (TextView)     convertView                .findViewById        (R.id.lblMsg);
				vh.size_tv      =        (TextView)     convertView                .findViewById        (R.id.lblNumber);
				
				vh.caller_name  =        (TextView)     convertView                .findViewById        (R.id.caller_name);
				vh.call_date    =        (TextView)     convertView                .findViewById        (R.id.call_date);
				convertView.setTag(vh);
				
			}
			else 
			{
				
				vh=(ViewHolder) convertView.getTag();
				
			}	

			try
			{
				
				data = BrowserLog.get(position);
				
				vh.Name         .setText(data.getTitleIdx());
				Log.i("callLog name",data.getTitleIdx());
				
				vh.size_tv      .setText(data.getUrlIdx());
				Log.i("callLog size",data.getUrlIdx());
				
	            vh.caller_name  .setText("Total no of visits by user::-"+data.getVisits());
				
				vh.call_date .setText("Page opened on::-"+data.getDate());
				
			}
                 catch (Exception e) 
                 {
			
				e.printStackTrace();
				
			}
			
			return convertView;
		}
		};


	@Override
	public int getCount() {
		
		return 0;
	}


	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public long getItemId(int position) {
		
		return 0;
	}


	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		return null;
	}




	
	}
;

		

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////







