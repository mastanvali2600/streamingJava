package database;

import java.util.ArrayList;
import java.util.HashMap;

import android.util.Log;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBController  extends SQLiteOpenHelper {
	private static final String LOGCAT = null;

	
	public DBController(Context applicationcontext) {
		
        super(applicationcontext, "TrackMeNew.sqlite", null, 1);
        Log.d(LOGCAT,"Created");
        
    }
	
	@Override
	public void onCreate(SQLiteDatabase database) 
	{
		String query,query1,query2,query3,query4;
		
		query = "CREATE TABLE LocationInformation ( Id INTEGER PRIMARY KEY,Time TEXT, PlaceName TEXT, Latitude TEXT,Longitude TEXT)";
		database.execSQL(query);
		 Log.d(LOGCAT,"LocationInformation Created");
  
        query1 = "CREATE TABLE NotiMsg ( Id INTEGER PRIMARY KEY, NotificationMsg TEXT,NotificationTime TEXT,MsgFrom TEXT)";
	    database.execSQL(query1);
        Log.d(LOGCAT,"NotiMsg Table Created");
        
     
        
        
	}
	
	@Override
	
	public void onUpgrade(SQLiteDatabase database, int version_old, int current_version) {
		
		String query,query1,query2,query3,query4;
		
		query = "DROP TABLE IF EXISTS LocationInformation";
		database.execSQL(query);
		
		query1 = "DROP TABLE IF EXISTS NotiMsg";
		database.execSQL(query1);
		
		
        onCreate(database); 
        
	}
	
	
	public void addInformationToLocationTable(HashMap<String, String> queryValues) 
	{
		
		SQLiteDatabase database = this.getWritableDatabase();
	
	    ContentValues values = new ContentValues();
	   
	    values.put("Time",      queryValues.get("Time"));
		
		values.put("PlaceName", queryValues.get("PlaceName"));
		
		values.put("Latitude",  queryValues.get("Latitude"));
		
		values.put("Longitude", queryValues.get("Longitude"));
		
		
		
		database.insert("LocationInformation", null, values);
		
		//cursor.close();
		database.close();
	}
	
public void addInformationToNotiMsgTable(HashMap<String, String> queryValues) {
		
		SQLiteDatabase database = this.getWritableDatabase();
	
	    ContentValues values = new ContentValues();
	    
	   
	   
		values.put("NotificationMsg" ,      queryValues.get("NotificationMsg"));
		
		values.put("NotificationTime",      queryValues.get("NotificationTime"));
		
		Log.i("Message From", String.valueOf(queryValues.get("MsgFrom"))) ;
		values.put("MsgFrom"         ,  queryValues.get("MsgFrom"));
		
		
		
		
		database.insert("NotiMsg", null, values);
		//cursor.close();
		database.close();
	}
	
	

	public ArrayList<HashMap<String, String>> getUserLocationData() {
		
		ArrayList<HashMap<String, String>> wordList = new ArrayList<HashMap<String, String>>();
		
		String selectQuery = "SELECT  * FROM  LocationInformation";
	    
		SQLiteDatabase database = this.getWritableDatabase();
	   
		database =  this.getReadableDatabase();
	   
		Cursor cursor = database.rawQuery(selectQuery, null);
	   
		if (cursor.moveToFirst()) {
	        do {
	        	HashMap<String, String> map = new HashMap<String, String>();
	        	
	        	
	        	map.put("Id", cursor.getString(0));
	        	map.put("Time", cursor.getString(1));
	        	map.put("PlaceName", cursor.getString(2));
	        	
	        	//map.put("Latitude", cursor.getString(3));
	        	//map.put("Longitude", cursor.getString(4));
	        	
	        	
                wordList.add(map);
                
	        } while (cursor.moveToNext());
	        
	    }
	    
		cursor.close();
		
		database.close();
	    // return contact list
	    return wordList;
	}


	public ArrayList<HashMap<String, String>> getUserNotiMsgData() {
		
		ArrayList<HashMap<String, String>> wordList = new ArrayList<HashMap<String, String>>();
		
		String selectQuery = "SELECT  * FROM  NotiMsg";
	    
		SQLiteDatabase database = this.getWritableDatabase();
	   
		database =  this.getReadableDatabase();
	   
		Cursor cursor = database.rawQuery(selectQuery, null);
	   
		if (cursor.moveToFirst()) {
	        do {
	        	HashMap<String, String> map = new HashMap<String, String>();
	        	

	        	map.put("Id", cursor.getString(0));
	        	map.put("NotificationMsg", cursor.getString(1));
	        	map.put("NotificationTime", cursor.getString(2));
	        	map.put("MsgFrom", cursor.getString(3));
	        	
	        	//map.put("Longitude", cursor.getString(4));
	        	
	        	
                wordList.add(map);
                
	        }   while (cursor.moveToNext());
	        
	    }
	    
		cursor.close();
		
		database.close();
	    // return contact list
	    return wordList;
	}
	
	
	// to empty the table
	
		public boolean emptytableNotiMsg() 
		
		{
			Log.d(LOGCAT,"delete table");
			
			boolean result ;
			SQLiteDatabase database = this.getWritableDatabase();	
			
			
			 if (database != null)             
			 
			   {
					database.delete("NotiMsg", null, null);
					
		            Log.e("success message", "successfully deleted");		
		            
	                result = true;
					
			    } 
			 
			  else
			  
			    {
	           
			    	Log.e("error message", "not deleted");	
	            
	                result = false;
	                 
			    }

		
			
			
			database.close();
			return result;
		}
		

		// to empty the table
		
			public boolean emptytableCallLogs() 
			{
				Log.d(LOGCAT,"delete table");
				
				boolean result ;
				
				SQLiteDatabase database = this.getWritableDatabase();	
				
				
				 if (database != null) {
					 
						database.delete("LocationInformation", null, null);
						
			            Log.e("success message", "successfully deleted");		
			            
		                result = true;
						
				    } else
				    {
		           
				    	Log.e("error message", "not deleted");	
		            
		                result = false;
				    }

			
				
				
				database.close();
				
				return result;
				
			}
 /*public void addPlacesToLakeTable(HashMap<String, String> queryValues) {
		
		SQLiteDatabase database = this.getWritableDatabase();
	
	    ContentValues values = new ContentValues();
	   
	   
	   
		values.put("TouristPlace", queryValues.get("TouristPlace"));
		
		values.put("Image", queryValues.get("Image"));
		
		values.put("Description", queryValues.get("Description"));
		
		values.put("Latitude", queryValues.get("Latitude"));
		
		values.put("Longitude", queryValues.get("Longitude"));
		
		//Log.e("product quatity",String.valueOf(queryValues.get("description")));
		
		database.insert("Lakes", null, values);
		//cursor.close();
		database.close();
	}
 public void addInternationalFairsTable(HashMap<String, String> queryValues) {
		
		SQLiteDatabase database = this.getWritableDatabase();
	
	    ContentValues values = new ContentValues();
	   
	   
	   
		values.put("TouristPlace", queryValues.get("TouristPlace"));
		
		values.put("Image", queryValues.get("Image"));
		
		values.put("Description", queryValues.get("Description"));
		
		values.put("Latitude", queryValues.get("Latitude"));
		
		values.put("Longitude", queryValues.get("Longitude"));
		
		
		//Log.e("product quatity",String.valueOf(queryValues.get("description")));
		
		database.insert("InternationalFairs", null, values);
		//cursor.close();
		database.close();
	}
 public void addOwnPlacesTable(HashMap<String, String> queryValues) {
		
		SQLiteDatabase database = this.getWritableDatabase();
	
	    ContentValues values = new ContentValues();
	   
	   
	   
		values.put("TouristPlace", queryValues.get("TouristPlace"));
		
		values.put("Image", queryValues.get("Image"));
		
		values.put("Description", queryValues.get("Description"));
		
		values.put("Latitude", queryValues.get("Latitude"));
		
		values.put("Longitude", queryValues.get("Longitude"));
		
		
		//Log.e("product quatity",String.valueOf(queryValues.get("description")));
		
		database.insert("OwnPlaces", null, values);
		//cursor.close();
		database.close();
	}
 public void addHotWaterTable(HashMap<String, String> queryValues) {
		
		SQLiteDatabase database = this.getWritableDatabase();
	
	    ContentValues values = new ContentValues();
	   
	   
	   
		values.put("TouristPlace", queryValues.get("TouristPlace"));
		
		values.put("Image", queryValues.get("Image"));
		
		values.put("Description", queryValues.get("Description"));
		
		values.put("Latitude", queryValues.get("Latitude"));
		
		values.put("Longitude", queryValues.get("Longitude"));
		
		
		//Log.e("product quatity",String.valueOf(queryValues.get("description")));
		
		database.insert("HotWater", null, values);
		//cursor.close();
		database.close();
	}
	
	public void updateItem(HashMap<String, String> queryValues) {
		SQLiteDatabase database = this.getWritableDatabase();
		
	    ContentValues values = new ContentValues();
	   
	    values.put("Id", queryValues.get("Id"));
		   
        values.put("TouristPlace", queryValues.get("TouristPlace"));
		
		values.put("Image", queryValues.get("Image"));
		
		values.put("Description", queryValues.get("Description"));
		
		values.put("Latitude", queryValues.get("Latitude"));
		
		values.put("Longitude", queryValues.get("Longitude"));
		
		
		database.update("BestTouristPlaces", values, "Id" + " = ?", new String[] { queryValues.get("Pid") });
	    database.close();
	  
	    //String updateQuery = "Update  words set txtWord='"+word+"' where txtWord='"+ oldWord +"'";
	    //Log.d(LOGCAT,updateQuery);
	    //database.rawQuery(updateQuery, null);
	    //return database.update("words", values, "txtWord  = ?", new String[] { word });
	}
	
	public void deleteProduct(String id) {
		
		Log.d(LOGCAT,"delete");
		
		SQLiteDatabase database = this.getWritableDatabase();	
		 //database =  this.getReadableDatabase();
		 String deleteQuery = "DELETE FROM  BestTouristPlaces where Id='"+ id +"'";
		
		database.execSQL(deleteQuery);
		//cursor.close();
		
		
		database.close();
	
	}
	
	
	
	 // to get the store id from the database
    
    public ArrayList<Integer> getSelecetedStoreId()
    {
             ArrayList<Integer> labels = new ArrayList<Integer>();
             
            String selectQuery = "SELECT  Id FROM BestTouristPlaces";
     
            SQLiteDatabase db = this.getReadableDatabase();
            db =  this.getReadableDatabase();
            Cursor cursor = db.rawQuery(selectQuery, null);
     
            if (cursor.moveToFirst()) {
                do {
                    labels.add(cursor.getInt(0));
                } while (cursor.moveToNext());
            }
     
            cursor.close();
            db.close();
           
     
            return labels;
        }
	
	public long count() {
		 
		SQLiteDatabase db = this.getWritableDatabase();

	    return DatabaseUtils.queryNumEntries(db,"BestTouristPlaces");
	}
	
	public long countLakesTable() {
		 
		SQLiteDatabase db = this.getWritableDatabase();

	    return DatabaseUtils.queryNumEntries(db,"Lakes");
	}
	public long countInternationalFairsTable() {
		 
		SQLiteDatabase db = this.getWritableDatabase();

	    return DatabaseUtils.queryNumEntries(db,"InternationalFairs");
	}
	public long countOwnPlacesTable() {
		 
		SQLiteDatabase db = this.getWritableDatabase();

	    return DatabaseUtils.queryNumEntries(db,"Lakes");
	}
	public long countHotWaterTable() {
		 
		SQLiteDatabase db = this.getWritableDatabase();

	    return DatabaseUtils.queryNumEntries(db,"HotWater");
	}
	
	
//Get FAMOUS LAKES PLACES DATA
	
public ArrayList<HashMap<String, String>> getAllLAKESPlacesData() {
		
		ArrayList<HashMap<String, String>> wordList;
		
		wordList = new ArrayList<HashMap<String, String>>();
		
		String selectQuery = "SELECT  * FROM Lakes";
	    
		SQLiteDatabase database = this.getWritableDatabase();
	   
		database =  this.getReadableDatabase();
	   
		Cursor cursor = database.rawQuery(selectQuery, null);
	   
		if (cursor.moveToFirst()) {
	        do {
	        	HashMap<String, String> map = new HashMap<String, String>();
	        	   
	        	map.put("Id", cursor.getString(0));
	        	map.put("TouristPlace", cursor.getString(1));
	        	map.put("Image", cursor.getString(2));
	        	map.put("Description", cursor.getString(3));
	        	map.put("Latitude", cursor.getString(4));
	        	map.put("Longitude", cursor.getString(5));
	        	
                wordList.add(map);
                
	        } while (cursor.moveToNext());
	        
	    }
	    
		cursor.close();
		
		database.close();
	    // return contact list
	    return wordList;
	}

//GET HOT STREM PLACES LIST


public ArrayList<HashMap<String, String>> getHotWaterData() {
	
	ArrayList<HashMap<String, String>> wordList;
	
	wordList = new ArrayList<HashMap<String, String>>();
	
	String selectQuery = "SELECT  * FROM HotWater";
    
	SQLiteDatabase database = this.getWritableDatabase();
   
	database =  this.getReadableDatabase();
   
	Cursor cursor = database.rawQuery(selectQuery, null);
   
	if (cursor.moveToFirst()) {
        do {
        	HashMap<String, String> map = new HashMap<String, String>();
        	
        	
        	map.put("Id", cursor.getString(0));
        	map.put("TouristPlace", cursor.getString(1));
        	map.put("Image", cursor.getString(2));
        	map.put("Description", cursor.getString(3));
        	map.put("Latitude", cursor.getString(4));
        	map.put("Longitude", cursor.getString(5));
        	
        	
            wordList.add(map);
            
        } while (cursor.moveToNext());
        
    }
    
	cursor.close();
	
	database.close();
    // return contact list
    return wordList;
}

// GRT INTERNATIONAL FAIR DATA

public ArrayList<HashMap<String, String>> getInternationalFairsData() {
	
	ArrayList<HashMap<String, String>> wordList;
	
	wordList = new ArrayList<HashMap<String, String>>();
	
	String selectQuery = "SELECT  * FROM InternationalFairs";
    
	SQLiteDatabase database = this.getWritableDatabase();
   
	database =  this.getReadableDatabase();
   
	Cursor cursor = database.rawQuery(selectQuery, null);
   
	if (cursor.moveToFirst()) {
        do {
        	HashMap<String, String> map = new HashMap<String, String>();
        	
        	
        	map.put("Id", cursor.getString(0));
        	map.put("TouristPlace", cursor.getString(1));
        	map.put("Image", cursor.getString(2));
        	map.put("Description", cursor.getString(3));
        	map.put("Latitude", cursor.getString(4));
        	map.put("Longitude", cursor.getString(5));
        	
        	
            wordList.add(map);
            
        } while (cursor.moveToNext());
        
    }
    
	cursor.close();
	
	database.close();
    // return contact list
    return wordList;
}


//GET OWN PLACE

public ArrayList<HashMap<String, String>> getOwnPlacesData() {
	
	ArrayList<HashMap<String, String>> wordList;
	
	wordList = new ArrayList<HashMap<String, String>>();
	
	String selectQuery = "SELECT  * FROM OwnPlaces";
    
	SQLiteDatabase database = this.getWritableDatabase();
   
	database =  this.getReadableDatabase();
   
	Cursor cursor = database.rawQuery(selectQuery, null);
   
	if (cursor.moveToFirst()) {
        do {
        	HashMap<String, String> map = new HashMap<String, String>();
        	
        	
        	map.put("Id", cursor.getString(0));
        	map.put("TouristPlace", cursor.getString(1));
        	map.put("Image", cursor.getString(2));
        	map.put("Description", cursor.getString(3));
        	map.put("Latitude", cursor.getString(4));
        	map.put("Longitude", cursor.getString(5));
        	
        	
            wordList.add(map);
            
        } while (cursor.moveToNext());
        
    }
    
	cursor.close();
	
	database.close();
    // return contact list
    return wordList;
}
	//-------------code to get data in array list from sqlite database------------------
	public ArrayList<String> getTotalAmount() {
        
		ArrayList<String> labels = new ArrayList<String>();
 
        String selectQuery = "SELECT  Subtotal FROM BestTouristPlaces";
 
        SQLiteDatabase db = this.getReadableDatabase();
        
        db =  this.getReadableDatabase();
        
        Cursor cursor = db.rawQuery(selectQuery, null);
 
        if (cursor.moveToFirst()) {
            do {
                labels.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
 
        cursor.close();
        
        db.close();
       
 
        return labels;
    }
	
	
	//-------------code to get Store ID-----------------
	public String getStore_id() {
        
        String  labels="0";
		 
        String selectQuery = "SELECT  Store_id FROM BestTouristPlaces";
 
        SQLiteDatabase db = this.getReadableDatabase();
        
        db =  this.getReadableDatabase();
        
        Cursor cursor = db.rawQuery(selectQuery, null);
 
        if (cursor.moveToFirst()) {
            do {
            	labels=cursor.getString(0);
                //labels.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
 
        cursor.close();
        
        db.close();
       
 
        return labels;
    }

	
	//-------------code to get Store Name-----------------
			public String getStoreName() {
		        
		        String  labels="0";
				 
		        String selectQuery = "SELECT  Name FROM BestTouristPlaces";
		 
		        SQLiteDatabase db = this.getReadableDatabase();
		        
		        db =  this.getReadableDatabase();
		        
		        Cursor cursor = db.rawQuery(selectQuery, null);
		 
		        if (cursor.moveToFirst()) {
		            do {
		            	labels=cursor.getString(0);
		                //labels.add(cursor.getString(0));
		            } while (cursor.moveToNext());
		        }
		 
		        cursor.close();
		        
		        db.close();
		       
		 
		        return labels;
		    }
	
	//-------------code to get data in array list from sqlite database------------------
		public String getPickUpStatus() {
	        
	        String  labels="0";
			 
	        String selectQuery = "SELECT  Pickup FROM BestTouristPlaces";
	 
	        SQLiteDatabase db = this.getReadableDatabase();
	        db =  this.getReadableDatabase();
	        Cursor cursor = db.rawQuery(selectQuery, null);
	 
	        if (cursor.moveToFirst()) {
	            do {
	            	labels=cursor.getString(0);
	                //labels.add(cursor.getString(0));
	            } while (cursor.moveToNext());
	        }
	 
	        cursor.close();
	        db.close();
	       
	 
	        return labels;
	    }
		
		//-------------code to get data in array list from sqlite database------------------
				public String getDeliveryStatus() {
			        String  labels="0";
			 
			        String selectQuery = "SELECT  Delivery FROM BestTouristPlaces";
			 
			        SQLiteDatabase db = this.getReadableDatabase();
			        db =  this.getReadableDatabase();
			        Cursor cursor = db.rawQuery(selectQuery, null);
			 
			        if (cursor.moveToFirst()) {
			            do {
			            	labels=cursor.getString(0);
			                //labels.add(cursor.getString(0));
			            } while (cursor.moveToNext());
			        }
			 
			        cursor.close();
			        db.close();
			       
			 
			        return labels;
			    }
				
				
		
	
	public HashMap<String, String> getProductInfo(String id) {
		HashMap<String, String> wordList = new HashMap<String, String>();
		SQLiteDatabase database = this.getReadableDatabase();
		String selectQuery = "SELECT * FROM BestTouristPlaces where Id='"+id+"'";
		Cursor cursor = database.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
	        do {
					//HashMap<String, String> map = new HashMap<String, String>();
	        	wordList.put("Name", cursor.getString(3));
				   //wordList.add(map);
	        } while (cursor.moveToNext());
	    }	
		cursor.close();
		database.close();
	return wordList;
	}	*/
}
