package guide.placesAutocomplete;

import java.util.List;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class PlacesApiAdapter extends ArrayAdapter<Places> {

	private List<Places> restaurants;
	private int resourceId;

	public PlacesApiAdapter(Context context, int textViewResourceId,
			List<Places> objects) {
		super(context, textViewResourceId, objects);
		this.resourceId = textViewResourceId;
		this.restaurants = objects;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		View v = convertView;
		if (v == null) {
			LayoutInflater vi = (LayoutInflater) getContext().getSystemService(
					Context.LAYOUT_INFLATER_SERVICE);
			v = vi.inflate(resourceId, null);
		}
		
		Places restaurant = restaurants.get(position);
		if (restaurant != null) {
			TextView name = (TextView) v.findViewById(android.R.id.text1);
			TextView vicinity = (TextView) v.findViewById(android.R.id.text2);
			name.setText(restaurant.getName());
			vicinity.setText(restaurant.getVicinity());
		}
		return v;
	}
}