package guide.placesAutocomplete;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.json.JSONObject;
import org.appTracker.R;
import org.trackme.utility.Appfonts;
import org.trackme.utility.ConnectionDetector;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class PlacesAutoCompleteSearch extends Activity {

	AutoCompleteTextView atvPlaces;
	PlacesTask placesTask;
	ParserTask parserTask;
	TextView   Lat_Long_textview;
	Typeface   typeface;
	Button     show_place_on_map;
	public static String lat,lng;
	        // flag for Internet connection status
			Boolean isInternetPresent = false;
			
		    // Connection detector class
		    ConnectionDetector cd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		 super.onCreate(savedInstanceState);
		 requestWindowFeature(Window.FEATURE_NO_TITLE);
	    // getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		 setContentView(R.layout.places_auto_complete_view);
		 //---------------------------------Check for gps------------------------------------------------------
		     final LocationManager manager = (LocationManager) getSystemService( Context.LOCATION_SERVICE );
             if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) 
             {
		        buildAlertMessageNoGps();
		     }
		  //-----------------------------check for network-----------------------------------------------------
		  // creating connection detector class instance
			 cd = new ConnectionDetector(getApplicationContext());
             Check_Network();
		 
		    init_layout();
		
	}
	private void Check_Network() {
		// get Internet status
		isInternetPresent = cd.isConnectingToInternet();

		// check for Internet status
		if (isInternetPresent) {
			// Internet Connection is Present
			// -do nothing
			//showAlertDialog(HomeActivity.this, "Internet Connection",
					//"You have internet connection", true);
		} else {
			// Internet connection is not present
			// Ask user to connect to Internet
			showAlertDialog(PlacesAutoCompleteSearch.this, "No Internet Connection found",
					"Please connect to a internet connection.", false);
		}
		
	}
	
	private void buildAlertMessageNoGps() {
	    final AlertDialog.Builder builder = new AlertDialog.Builder(this);
	    builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
	           .setCancelable(false)
	           .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
	               public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
	                   startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
	               }
	           })
	           .setNegativeButton("No", new DialogInterface.OnClickListener() {
	               public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
	                    dialog.cancel();
	               }
	           });
	    final AlertDialog alert = builder.create();
	    alert.show();
	}
	/**
	 * Function to display simple Alert Dialog
	 * @param context - application context
	 * @param title - alert dialog title
	 * @param message - alert message
	 * @param status - success/failure (used to set icon)
	 * */
	public void showAlertDialog(Context context, String title, String message, Boolean status) {
		AlertDialog alertDialog = new AlertDialog.Builder(context).create();

		// Setting Dialog Title
		alertDialog.setTitle(title);

		// Setting Dialog Message
		alertDialog.setMessage(message);
		
		// Setting alert dialog icon
		alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);

		// Setting OK Button
		alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
			}
		});

		// Showing Alert Message
		alertDialog.show();
	}
	private void init_layout() {
        
		
		
		
		TextView title_label=(TextView)findViewById(R.id.title_label);
		
		Lat_Long_textview=(TextView)findViewById(R.id.Lat_Long_label);
		
		atvPlaces = (AutoCompleteTextView) findViewById(R.id.atv_places);
		atvPlaces.setThreshold(1);		
		
		
		//---------------------show_place_on_map------------------------
		
		show_place_on_map=(Button)findViewById(R.id.show_place_on_map);
		show_place_on_map.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Log.i("btn click", "click ");
				String lat_lng_text = atvPlaces.getText().toString();Log.i("lat_lng_text",lat_lng_text);
				String auto_complete_lat_lng_text=Lat_Long_textview.getText().toString();Log.i("auto_complete_lat_lng_text",auto_complete_lat_lng_text);
				
			if(lat_lng_text.equals("")==true && lat_lng_text.length()<=3 ){
				Log.i("inside ", "if ");
				Toast.makeText(getApplicationContext(), "Please enter a place name.", 1000).show();
			}
			else if(auto_complete_lat_lng_text.equals("hello")==true)
			{
				Log.i("inside", "else if ");
				Toast.makeText(PlacesAutoCompleteSearch.this, "Please enter text slowly ,doing background task and after on display of drop-down , click on the place of your choice.", Toast.LENGTH_SHORT).show();
			}
			
			else{
				Log.i("inside", "else");
				Intent map=new Intent(getApplicationContext(),MapsActivity.class);
				map.putExtra("Latitude", lat);
				map.putExtra("Longitude", lng);
				map.putExtra("place_name", atvPlaces.getText().toString());
				
				Log.i("place lat long", lat+"---"+lng);
				startActivity(map);
			  }
				
			}
		});
		atvPlaces.setOnItemClickListener(new OnItemClickListener() {
		    @Override
		    public void onItemClick (AdapterView<?> parent, View view, int position, long id) {
		    	System.out.println("selected from list");
		    
				location(atvPlaces.getText().toString());
		    }
		});
		
		
		atvPlaces.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				System.out.println("call     "+s);
				placesTask = new PlacesTask();				
				placesTask.execute(s.toString());		
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,int after) {
				System.out.println("no text");
				// TODO Auto-generated method stub
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				System.out.println("changed");
				// TODO Auto-generated method stub				
			}
		});	
		
		//---------------setting text font---------------------------------------
		typeface = Appfonts.getFont(PlacesAutoCompleteSearch.this, Appfonts.Helvetica);
		title_label.setTypeface(typeface);
		atvPlaces.setTypeface(typeface);

		/*=========================== top bar============================================= */
	       ImageButton Home_btn=(ImageButton)findViewById(R.id.option_button);
		   ImageButton Back_btn=(ImageButton)findViewById(R.id.back_button);
		      
		   // Home_btn.setBackgroundColor(Color.TRANSPARENT);
		   // Back_btn.setBackgroundColor(Color.TRANSPARENT);
		   Back_btn.setOnClickListener(new View.OnClickListener() {
				
				public void onClick(View v) {
					
					overridePendingTransition(0, 0);
					/*Intent intent = new Intent(getApplicationContext(),Utility_Home.class);
					startActivity(intent);*/
					finish();
					//overridePendingTransition(R.drawable.push_down, 0);
				 }
			});
		  

	}

	public void location(String placeString) {
Log.d("inside geo coder ", "inside geo coder");
    Geocoder geoCoder = new Geocoder(getApplicationContext(), Locale.getDefault());	    
//	    
////	    	  String[] temp;
////	    	 
////	    	  /* delimiter */
////	    	  String delimiter = ",";
////	    	  /* given string will be split by the argument delimiter provided. */
////	    	  temp = placeString.split(delimiter);
////	    		System.out.println("place     :-  "+temp[0]);
//	    	 
//	    try {
//	    	System.out.println("enter");
//	    	List<Address> addresses = geoCoder.getFromLocationName("mohali, punjab, india", 5);
//	    	System.out.println("size of list     :_"+addresses.size());	    	
//	    	
//	 
//	    	if (addresses.size() > 0) {
//	    		Log.d("pos", "############Address not correct #########");
//	    	}
//	    
//	    	Address location = addresses.get(0);
//
//	    	Log.d("pos", "Address Latitude : "+ location.getLatitude()+ "Address Longitude : "+ location.getLongitude());
//	    	
//
//	    }
//	    catch(Exception e){
//	    	Log.d("pos", "MY_ERROR : ############Address Not Found");
		
		  
	        List<Address> address;
	        try {
	            address = geoCoder.getFromLocationName(placeString, 8);
	 
	            if (address == null) {
	                // Log.d(TAG, "############Address not correct #########");
	                System.out.println("Adress not correct");
	            }
	            Address location = address.get(0);
	           
	            System.out.println("lati 77777777------------" + location.getLatitude());
	            System.out.println("Long 88888888-----------"  + location.getLongitude());
	          
	            Lat_Long_textview.setText(String.valueOf(location.getLatitude()+","+location.getLongitude()));
	            lat=String.valueOf(location.getLatitude());
	            lng=String.valueOf(location.getLongitude());
	            Log.e("geo coder lat long", String.valueOf(lat+"----"+lng));
	 
	        }    catch (Exception e) {
	        	 System.out.println("error    "+e);
	             Log.d("hi", "MY_ERROR : ############Address Not Found");
	    	
	    }
	    
			}

	/** A method to download json data from url */
    private String downloadUrl(String strUrl) throws IOException{
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try{
                URL url = new URL(strUrl);                

                // Creating an http connection to communicate with url 
                urlConnection = (HttpURLConnection) url.openConnection();

                // Connecting to url 
                urlConnection.connect();

                // Reading data from url 
                iStream = urlConnection.getInputStream();

                BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

                StringBuffer sb  = new StringBuffer();

                String line = "";
                while( ( line = br.readLine())  != null){
                        sb.append(line);
                     }
                
                
                data = sb.toString();

                br.close();

        }catch(Exception e){
                Log.d("Exception while downloading url", e.toString());
        }finally{
                iStream.close();
                urlConnection.disconnect();
        }
        return data;
     }	
	
	    // Fetches all places from GooglePlaces AutoComplete Web Service
	    private class PlacesTask extends AsyncTask<String, Void, String>{

		@Override
		protected String doInBackground(String... place) {
			
			// For storing data from web service
			String data = "";
			
			// Obtain browser key from https://code.google.com/apis/console
			String key = "key=AIzaSyA_Xa57C0oj6WLYWZo66K-Cgbp416nfXPk";
			
			String input="";
			
			try {
				input = "input=" + URLEncoder.encode(place[0], "utf-8");
				
			} catch (UnsupportedEncodingException e1) {
				e1.printStackTrace();
			}		
			
			
			// place type to be searched
			String types = "types=geocode";
			
			// Sensor enabled
			String sensor = "sensor=true";			
			
			// Building the parameters to the web service
			String parameters = input+"&"+types+"&"+sensor+"&"+key;
			
			// Output format
			String output = "json";
			
			// Building the url to the web service
			String url = "https://maps.googleapis.com/maps/api/place/autocomplete/"+output+"?"+parameters;
	System.out.println("url     "+url);
			try{
				// Fetching the data from web service in background
				data = downloadUrl(url);
			}catch(Exception e){
                Log.d("Background Task",e.toString());
			}
			return data;		
		}
		
		@Override
		protected void onPostExecute(String result) {			
			super.onPostExecute(result);
			
			// Creating ParserTask
			parserTask = new ParserTask();
			
			// Starting Parsing the JSON string returned by Web Service
			parserTask.execute(result);
		}		
	}
	
	
	/** A class to parse the Google Places in JSON format */
    private class ParserTask extends AsyncTask<String, Integer, List<HashMap<String,String>>>{

    	JSONObject jObject;
    	
		@Override
		protected List<HashMap<String, String>> doInBackground(String... jsonData) {			
			
			List<HashMap<String, String>> places = null;
			
            PlaceJSONParser placeJsonParser = new PlaceJSONParser();
            
            try{
            	jObject = new JSONObject(jsonData[0]);
            	
            	// Getting the parsed data as a List construct
            	places = placeJsonParser.parse(jObject);

            }catch(Exception e){
            	Log.d("Exception",e.toString());
            }
            return places;
		}
		
		@Override
		protected void onPostExecute(List<HashMap<String, String>> result) {			
			
				String[] from = new String[] { "description"};
				int[] to = new int[] { android.R.id.text1 };
				
				// Creating a SimpleAdapter for the AutoCompleteTextView			
				SimpleAdapter adapter = new SimpleAdapter(getBaseContext(), result, android.R.layout.simple_list_item_1, from, to);				
				
				// Setting the adapter
				atvPlaces.setAdapter(adapter);
		}			
        
    
		
    	
    }


}