package guide.placesAutocomplete;


import java.util.List;
import org.appTracker.R;
import org.trackme.utility.Appfonts;
import org.trackme.utility.ConnectionDetector;
import org.trackme.utility.Utils;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

public class MapsActivity extends  Activity implements PlacesReceiver {
	
	private Marker myLocationMarker,destination;
	
	private static BitmapDescriptor markerIconBitmapDescriptor;
	
	private GoogleMap map;
	
    public String place_type;
  
  	private List<Places> restaurants;
  	
     PlacesReceiver p;
    
	private String previousRequestUrl;
	
	private String pageToken;
   
	//private static SinglePlacesSearchMapActivity instance;
	
	
	
	
	private  LatLng  User_selected_place;
	
	private static final LatLng MOUNTAIN_VIEW = new LatLng(30.7353, 76.7911);
	
	GoogleMap mMap;Button driving_direction;
	
	Button place_detail;
	
	public static double Lat=0;
	
	public static double Lng=0;
	//private static final double lat = 0;
	public String pinpoint_lat_lon,Trimed_Lat_lng;
	String  Name;
	public Typeface typeface;
	public  String selected_item;
	
	/*public static SinglePlacesSearchMapActivity getInstance() {
		return instance;
	}
*/
	public List<Places> getRestaurants() {
		return restaurants;
	}
	
	// flag for Internet connection status
			Boolean isInternetPresent = false;
			
	// Connection detector class
		    ConnectionDetector cd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		 super.onCreate(savedInstanceState);
		 requestWindowFeature(Window.FEATURE_NO_TITLE);
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		 setContentView(R.layout.map_activity);
		 GetBundleData();
		 //GetCurrentLocation();
		 Init_layout();
		 //---------------------------------Check for gps------------------------------------------------------ 
		    final LocationManager manager = (LocationManager) getSystemService( Context.LOCATION_SERVICE );

		    if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
		        buildAlertMessageNoGps();
		     }
		  //-----------------------------check for network-----------------------------------------------
		  // creating connection detector class instance
			 cd = new ConnectionDetector(getApplicationContext());
	        Check_Network();
		    
		
		
		User_selected_place = new LatLng(Lat,Lng);
		//mMap = ((SupportMapFragment)  getSupportFragmentManager().findFragmentById(R.id.map)).getMap();
		mMap = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
		//mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
		mMap.addMarker(new MarkerOptions()
		.position(new LatLng(Lat, Lng))
		.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN))
		.title(Name));
		mMap.setMyLocationEnabled(true);		
		//private static final LatLng MyLocation=(new LatLng())
		
		// Move the camera instantly to Sydney with a zoom of 15.
		mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(User_selected_place, 18));

		// Zoom in, animating the camera.
		mMap.animateCamera(CameraUpdateFactory.zoomIn());

		// Zoom out to zoom level 10, animating with a duration of 2 seconds.
		mMap.animateCamera(CameraUpdateFactory.zoomTo(18), 2000, null);

		// Construct a CameraPosition focusing on Mountain View and animate the camera to that position.
		CameraPosition cameraPosition = new CameraPosition.Builder()
		    //.target(MOUNTAIN_VIEW)      // Sets the center of the map to Mountain View
		   
		
		.target(new LatLng(Lat,Lng))
		    .zoom(18)                   // Sets the zoom
		    //.target(Latitude,Longitude)
		    .bearing(60)                // Sets the orientation of the camera to east
		    .tilt(90)                   // Sets the tilt of the camera to 30 degrees
		    .build();                   // Creates a CameraPosition from the builder
		mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
		
		
          		
      
		
		
		//----------------------------------Google Map Info window click event-------------------------------------------------
		 mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
		    public void onInfoWindowClick(Marker marker) {
		        /*Intent rest_list = new Intent(getParent(), RestFullDetail.class);
		        TabGroupActivity parentActivity = (TabGroupActivity)getParent();
		        parentActivity.startChildActivity("mapRestDetail", rest_list);*/
		    	
		    	
		    	/*Toast.makeText(getBaseContext(), 
		    			   "Info Window clicked@" + marker.getPosition(), 
		    			    Toast.LENGTH_SHORT).show();*/
		         LatLng	lat_lng=marker.getPosition();
		    	 pinpoint_lat_lon=lat_lng.toString();
		    	 Log.i("pinpoint_lat_lon replace", pinpoint_lat_lon);
		    	 Trimed_Lat_lng=Utils.SeperateRaw(pinpoint_lat_lon);
		    	
		    	// Lat_lng_trimed.replaceAll("[()]", "");
		    	 
		    	 Log.i("pinpoint_lat_lon replace", Trimed_Lat_lng);
		         //String	replace = pinpoint_lat_lon.replaceAll("(","");
		    
		    	 
		    	//-----------------dialog method to get low comments reasons from user
				// create a Dialog component
				final Dialog dialog = new Dialog(MapsActivity.this);
				
				//tell the Dialog to use the dialog.xml as it's layout description
				dialog.setContentView(R.layout.driving_navigation_dialog);
				dialog.setTitle("Driving Navigation");

				TextView txt = (TextView) dialog.findViewById(R.id.txt);
				//---------------setting text font---------------------------------------
				typeface = Appfonts.getFont(MapsActivity.this, Appfonts.Helvetica);
			
				txt.setText("Would like to See Driving Navigation.");
			  
				txt.setTypeface(typeface);
			
				Button dialogButton1 = (Button) dialog.findViewById(R.id.dialogButton1);
				dialogButton1.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Location location = mMap.getMyLocation();
				        Intent intent = new Intent(android.content.Intent.ACTION_VIEW, 
	        		    Uri.parse("http://maps.google.com/maps?saddr="+location.getLatitude()+","+location.getLongitude()+"&daddr="+Trimed_Lat_lng));
	        		    startActivity(intent);
						dialog.dismiss();
					}
				});
				
	            Button dialogButton2 = (Button) dialog.findViewById(R.id.dialogButton2);
				dialogButton2.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						
						
						dialog.dismiss();
					}
				});

				dialog.show();
		    	
		    	
		    }

			
		});

	}
	
	//--------------------Gps alert dialog---------------------------------------------------------------------
	private void buildAlertMessageNoGps() {
	    final AlertDialog.Builder builder = new AlertDialog.Builder(this);
	    builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
	           .setCancelable(false)
	           .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
	               public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
	                   startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
	               }
	           })
	           .setNegativeButton("No", new DialogInterface.OnClickListener() {
	               public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
	                    dialog.cancel();
	               }
	           });
	    final AlertDialog alert = builder.create();
	    alert.show();
	}
	        
	
private void Check_Network() {
	// get Internet status
	isInternetPresent = cd.isConnectingToInternet();

	// check for Internet status
	if (isInternetPresent) {
		// Internet Connection is Present
		// -do nothing
		//showAlertDialog(HomeActivity.this, "Internet Connection",
				//"You have internet connection", true);
	} else {
		// Internet connection is not present
		// Ask user to connect to Internet
		showAlertDialog(MapsActivity.this, "No Internet Connection found",
				"Please connect to a internet connection.", false);
	}
	
}
/**
* Function to display simple Alert Dialog
* @param context - application context
* @param title - alert dialog title
* @param message - alert message
* @param status - success/failure (used to set icon)
* */
public void showAlertDialog(Context context, String title, String message, Boolean status) {
	AlertDialog alertDialog = new AlertDialog.Builder(context).create();

	// Setting Dialog Title
	alertDialog.setTitle(title);

	// Setting Dialog Message
	alertDialog.setMessage(message);
	
	// Setting alert dialog icon
	alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);

	// Setting OK Button
	alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
		public void onClick(DialogInterface dialog, int which) {
		}
	});

	// Showing Alert Message
	alertDialog.show();
}
	
	
	
	
	//--------------------------------------On Map refresh --------------------------------------------------------------		
	
	
	private void refresh() {
				
				//Location location = getCurrentLocation();
			    
				/*Log.i("current Lat Long value",String.valueOf( location.getLatitude()+""+
							location.getLongitude()));
				
				if (location != null) {*/
					Log.i("calling refresh", "inside  refresh");
					/*PlacesTask.executeFor(this, location.getLatitude(),
							location.getLongitude(), 100 ,selected_item);*/
					/*String	latitude=NearBySearch_Activity.lat;
					String	longitutde=NearBySearch_Activity.lng;
					lat   = Double.parseDouble(latitude);
					lng   = Double.parseDouble(longitutde);*/
					//Log.i("Row id and Lat Long from PlaceMap Activity ", latitude+"--"+longitutde);
			
					
					PlaceTask_Neraby.executeFor(this, Lat,Lng, "100000" ,selected_item);
					mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(Lat, Lng), 12));
					        //map.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(
							//location.getLatitude(), location.getLongitude()), 12));
				/*} else {
					Log.d("ShowMapActivity", "Cannot get location");
				}*/
			}

			public void flyToRestaurant(Places restaurant) {
				mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(
						restaurant.getPosition(), 17));
			}

			private Location getCurrentLocation() {
				Location location = mMap.getMyLocation();
				if (location == null) { // It seems that the above usually returns null
					LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
					Criteria criteria = new Criteria();
					String provider = service.getBestProvider(criteria, false);
					location = service.getLastKnownLocation(provider);
				}
				return location;
			}

			
			
			
			
			
	private Location GetCurrentLocation() {
		Location location = mMap.getMyLocation();
		if (location == null) { // It seems that the above usually returns null
			LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
			Criteria criteria = new Criteria();
			String provider = service.getBestProvider(criteria, false);
			location = service.getLastKnownLocation(provider);
		}
		return location;
	}
	
	private void GetBundleData() {
		//-------------------Recieving   data from previous Activity-----------
		Bundle extras = getIntent().getExtras();
		if (extras == null) 
		{
		    //.......do nothing.....................---------------------------
		}else
		{
		    // Get data via the key
			
        String  Lati= extras.getString("Latitude");
		String	Longi= extras.getString("Longitude");
		        Name = extras.getString("place_name");
		Log.i("-Latitude--Longitude-from Maps Activity", Lati+"--"+Longi);
		
		Lat=Double.parseDouble(Lati);
		Lng=Double.parseDouble(Longi);
		Log.i("-Latitude--Longitude-", String.valueOf(Lat)+"--"+String.valueOf(Lng));
		
		}
		
	}




	public void Init_layout()
		{
		driving_direction=(Button)findViewById(R.id.driving_direction);
		//place_detail=(Button)findViewById(R.id.place_detail);
		driving_direction.setOnClickListener(new View.OnClickListener() 
		{
			
			@Override
			public void onClick(View v) {
				Location location = GetCurrentLocation();
				        Intent intent = new Intent(android.content.Intent.ACTION_VIEW, 
	        		    Uri.parse("http://maps.google.com/maps?saddr="+location.getLatitude()+","+location.getLongitude()+"&daddr="+Lat+","+Lng));
	        		    startActivity(intent);
			}
		});
		
		Button option_btn=(Button)findViewById(R.id.option_btn);
		//option btn function----------------------------------------------------------
				option_btn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				open_search_dialog();
			}
		});
			
		
		
		}

	//-----------------------------Option Button function-------------------------------------
private void open_search_dialog() {
		
		AlertDialog.Builder builderSingle = new AlertDialog.Builder(
				MapsActivity.this);
		
        builderSingle.setIcon(R.drawable.place_type_icon);
        builderSingle.setTitle("Select Place Type:");
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
        		MapsActivity.this,
                android.R.layout.select_dialog_singlechoice);
        arrayAdapter.add("airport");
        arrayAdapter.add("atm");
        arrayAdapter.add("bank");
        arrayAdapter.add("bar");
        arrayAdapter.add("bus_station");
        
       
        arrayAdapter.add("cafe");
        arrayAdapter.add("church");
        arrayAdapter.add("department_store");
        arrayAdapter.add("embassy");
        arrayAdapter.add("food");
        
        arrayAdapter.add("gas_station");
        arrayAdapter.add("hindu_temple");
        arrayAdapter.add("hospital");
        arrayAdapter.add("liquor_store");
        arrayAdapter.add("mosque");
        
        arrayAdapter.add("movie_theater");
        arrayAdapter.add("museum");
        arrayAdapter.add("night_club");
        arrayAdapter.add("park");
        arrayAdapter.add("parking");
        
        arrayAdapter.add("place_of_worship");
        arrayAdapter.add("police");
        arrayAdapter.add("post_office");
        arrayAdapter.add("restaurant");
        arrayAdapter.add("stadium");
        
        arrayAdapter.add("subway_station");
        arrayAdapter.add("taxi_stand");
        arrayAdapter.add("train_station");
        arrayAdapter.add("travel_agency");
        arrayAdapter.add("zoo");
        builderSingle.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        builderSingle.setAdapter(arrayAdapter,
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        selected_item = arrayAdapter.getItem(which);
                        Log.i("selected item by user",selected_item);
                        AlertDialog.Builder builderInner = new AlertDialog.Builder(MapsActivity.this);
                        builderInner.setMessage(selected_item);
                        builderInner.setTitle("Your Selected Item is");
                        builderInner.setPositiveButton("Ok",
                                new DialogInterface.OnClickListener() {

                                    @Override
                                    public void onClick(
                                            DialogInterface dialog,
                                            int which) {
                                    	refresh();
                                        dialog.dismiss();
                                    }
                                });
                        builderInner.show();
                    }
                });
        builderSingle.show();
        
		
	}



/*
@Override
public boolean onCreateOptionsMenu(Menu menu) {
	Log.d("ShowMapActivity", "onCreateOptionsMenu");
	getMenuInflater().inflate(R.menu.main, menu);
	return true;
}

@Override
public boolean onPrepareOptionsMenu(Menu menu) {
	Log.d("ShowMapActivity", "onPrepareOptionsMenu");
	if (pageToken == null)
		menu.removeItem(R.id.action_more);
	return true;
}*/

@Override
public boolean onOptionsItemSelected(MenuItem item) {
	switch (item.getItemId()) {
	/*case R.id.action_list:
		final Intent intent = new Intent().setClass(this,SinglePlacesSearch.class);
		startActivity(intent);
		return true;
	case R.id.action_more:
		if (pageToken != null)
			PlacesTask.executeFor(this, previousRequestUrl, pageToken);
		return true;*/
		
	/*case R.id.open_search_dialog:
		//open_search_dialog();
		return true;
		
	case R.id.action_refresh:
		//refresh();
		return true;*/
	default:
		return super.onOptionsItemSelected(item);
	}
}

	
	public void handleResults(List<Places> restaurants) {
		if (restaurants != null && restaurants.size() > 0) {
			mMap.clear();
			for (Places restaurant : restaurants) {
				Log.d("ShowMapActivity", restaurant.toString());
				mMap.addMarker(new MarkerOptions()
					.position(restaurant.getPosition())
					.title(restaurant.getName())
					.snippet(restaurant.getVicinity())
					//.icon(BitmapDescriptorFactory.fromResource(R.drawable.ne)));
				    //.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN)));
					.icon(BitmapDescriptorFactory.fromResource(R.drawable.pinpoint_click)));
			}
			this.restaurants = restaurants;
		}
		// Leave the previous results if not
	}
	@Override
	public void handleNextPage(String previousRequestUrl, String pageToken) {
		this.pageToken = pageToken;
		this.previousRequestUrl = previousRequestUrl;
	}
	
	
	//-----------------------on Back presss----------------------------------------------------
		public void onBackPressed() {
			
			this.finish();
		}

		

}
