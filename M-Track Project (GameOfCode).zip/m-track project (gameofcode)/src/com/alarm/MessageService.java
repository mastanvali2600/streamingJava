package com.alarm;

import org.appTracker.R;



import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;

public class MessageService extends Service {
	public static final String ACTION_UPDATE_LOCATION_DATABASE = "update_location";
	
	
	public static final String EXTRA_SHOW_NOTIF = "show_notification";
	public static final String EXTRA_DONT_DISABLE = "dont_disable";
	
	public static final boolean DEFAULT_SHOW_NOTIF = false;
	public static final String EXTRA_DONT_SHOW_SNOOZE = "dont_show_snooze";
	public static final boolean DEFAULT_DONT_SHOW_SNOOZE = false;

	
	public static final String PREF_FILE_NAME = "AutoAppLauncherPrefs";
	private static final int NOTIFY_ID = R.layout.main;
	private PackageManager mPackageManager;
	private NotificationManager mNotificationManager;
	private PowerManager.WakeLock mFullWakeLock;
	private PowerManager.WakeLock mPartialWakeLock;
	private final Handler mHandler = new Handler();
	
	private AalDbAdapter mDbAdapter;
	
	private Item mCurrentItem;
	
	private boolean mIsWaitingForWifi, mIsGoingSnooze, mIsShowingSnooze;
	
	
	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
		mPartialWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Tracker AlarmTag");
		mPartialWakeLock.acquire();
		
		mPackageManager = getPackageManager();
		mNotificationManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
		
		mDbAdapter = new AalDbAdapter(this);
		mDbAdapter.open();
		
		mIsGoingSnooze = false;
		mIsWaitingForWifi = false;
		mIsShowingSnooze = false;
	}

	@Override
	public void onDestroy()       {
		//setNextAlarm();
		unregisterWifiReciever();
		if (mCurrentItem != null) {
			
			if (!mIsGoingSnooze)    {
				try {
					if (mCurrentItem.getBool(Item.KEY_WIFI) && mCurrentItem.getBool(Item.KEY_TURN_OFF_WIFI)) {
						WifiManager wm = (WifiManager)getSystemService(WIFI_SERVICE);
						wm.setWifiEnabled(false);
					}
				} catch (Exception e) {}
			}
		}
		if (mIsShowingSnooze) {
		/*	Intent i = new Intent(getBaseContext(), SnoozeActivity.class);
			i.putExtra(SnoozeActivity.EXTRA_CLOSE_ACTIVITY, true);	
			i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(i);*/
		}
		mDbAdapter.close();
		try {
			mFullWakeLock.release();
		} catch (Exception e) {}
		try {
			mNotificationManager.cancel(NOTIFY_ID);
		} catch (Exception e) {}
//		Toast.makeText(this, "Service Destroyed", Toast.LENGTH_SHORT).show();
		
		super.onDestroy();
	}

	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		
		doAction(intent);
		
		try {
			mPartialWakeLock.release();
		} catch (Exception e) {}
	}
	
	private void unregisterWifiReciever() {
		if (mIsWaitingForWifi) {
			try {
			//	unregisterReceiver(mWifiReceiver);
			} catch (Exception e) {}				
		}
		mIsWaitingForWifi = false;
	}
	
//	private void stopApp() {
//		if (mCurrentItem != null) {
//			if (mCurrentItem.hasPackageName()) {
//				ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
//				am.restartPackage(mCurrentItem.getString(Item.KEY_PACKAGE_NAME));
//			}
//		}
//	}
	
	private void doAction(Intent intent)  {
		String action = intent.getAction();
		if (action.equals(ACTION_UPDATE_LOCATION_DATABASE)) 
		{
			Intent openUpdateLocation = new Intent(this,UpdateLocationDatabase.class);
			openUpdateLocation.addFlags  (Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(openUpdateLocation);
		} 
	}
	
	

	

	
	
	
	
	
	
	
	

}
