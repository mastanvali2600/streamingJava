package com.alarm;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.activity.DashBoardActivity;
import org.appTracker.R;
import org.trackme.automaticEmail.Mail;
import org.trackme.utility.BrowserData;
import org.trackme.utility.CallData;
import org.trackme.utility.ConnectionDetector;
import org.trackme.utility.SMSData;

import com.alarm.SendMailToUserAccount.CityAsyncTask;

import database.DBController;
import android.app.Activity;
import android.app.KeyguardManager;
import android.app.ProgressDialog;
import android.app.KeyguardManager.KeyguardLock;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.StrictMode;
import android.os.SystemClock;
import android.provider.Browser;
import android.provider.CallLog;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class UpdateLocationDatabase extends Service implements LocationListener {
	
	String userLoc;
	/** Called when the activity is first created. */
	Spanned userLocationInformation;
	
	double latitude ;	public static String LocationInformation=""; 
	
	double longitude ;
	
	String result;
	
	Long subtractedMillisecFromCurrentSystemHour;
	//---location address string
	String add = "";

	TextView contactView;
	
	Location location = new Location("any string"); 

		 public static String    browserLogString      = "";
		 
		 ArrayList<BrowserData> browserLog = new ArrayList<BrowserData>();
		  
	   Context ctx;

	   String  latituteField;
	  
	   String  longitudeField;	  
	   LocationManager locationManager;	  
	   String provider;	  
	DBController dbController = new DBController(this);	
	BroadcastReceiver mReceiver;	
	String TAG = "WakeUp-----BroadCast----testing";
	
	static Context context;
	//--- Connection detector class
    ConnectionDetector cd;
	
   
	
	
	
	
    public UpdateLocationDatabase() {
    }
    @Override
    public IBinder onBind(Intent intent) {
     throw new UnsupportedOperationException("Not yet implemented");
    }
    @Override
    public void onCreate() {
    
		
    	Toast.makeText(this, "Service was Created", Toast.LENGTH_LONG).show();
    	System.out.println("Service was Created");
        
		//---Dashboard items
		
		//---connection detector object initialisation
		cd = new ConnectionDetector(getApplicationContext());
		
		System.out.println("inside Update Location Database method");
     
		//---function to remove restrict mode policy exceptions
		StrictModePolicies();
		
	
		//===get device location using network opertor lat-long
		GetCurrentLocation();
		
		
		//---run background thread to get device current location names
		new CityAsyncTask().execute();
			
	
	
    
    
    
}

 @Override
public void onStart(Intent intent, int startId) {
 // Perform your long running operations here.
 Toast.makeText(this, "Service Started", Toast.LENGTH_LONG).show();
 System.out.println("Service Started");
}

 @Override
public void onDestroy() 
 {
   Toast.makeText(this, "Service Destroyed", Toast.LENGTH_LONG).show();
   System.out.println("Service Destroyed");
   
   //  unregisterReceiver(mReceiver);
   //  unregisterReceiver(mReceiver);
   Log.i(TAG, "broadcast UNregistred!");
   }

	
	private void GetCurrentLocation() 
	{

	System.out.println("inside get current location method");
	// Get the location manager
	locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

	// Define the criteria how to select the locatioin provider -> use  default
	Criteria criteria = new Criteria();

	provider          = locationManager.getBestProvider(criteria, false);

	Location location = locationManager.getLastKnownLocation(provider);



	// Initialize the location fields
	if (location != null) 

	{
	  System.out.println("Provider " + provider + " has been selected.");
	  
	  onLocationChanged(location);
	}

	else

	{
	  
	  latituteField  = "Location not available";
	  
	  longitudeField = "Location not available";
	  
	  System.out.println("not able to find locations inside GetCurrentLocation() method.");
	  
	  System.out.println("latituteField   value---"+latituteField);
	  
	  System.out.println("longitudeField  value---"+longitudeField);

	}
		
	}


	
	/*@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		
	}

	@Override
	protected void onPause() {
		
		//mKeyguardLock.reenableKeyguard();
		
		super.onPause();

	    locationManager.removeUpdates(this);
	}

	@Override
	protected void onResume() {
		
	//	    
		//mKeyguardLock.disableKeyguard();
//		Toast.makeText(this, "mNoSnooze = " + mNoSnooze, Toast.LENGTH_LONG).show();
		super.onResume();
		

		//---for location
	    locationManager.requestLocationUpdates(provider, 400, 1, this);
		
	    //---for wake up reciever
		  /*  IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
		    registerReceiver(mReceiver, filter);
		    Log.i(TAG, "broadcast receiver registered!");
	}

*/
	
	//-----Background thread to generate places names and andress detail

	public class CityAsyncTask extends AsyncTask<String , String,String>
	{

	  @Override
	  protected String doInBackground(String... params) {
	  	//Log.i("current Lat Long value",String.valueOf( location.getLatitude()+""+location.getLongitude()));
	  	System.out.println("latituteField--longitudeField---"+latituteField+"----"+longitudeField);
	  	//double latitude = location.getLatitude();
	  	//double longitude =location.getLongitude();
	  	String add ;StringBuffer UserLocationResutl = new StringBuffer();
	       Geocoder geocoder = new Geocoder(UpdateLocationDatabase.this, Locale.getDefault());
	          try
	          {
	          	if (latituteField.equals("Location not available"))
	          	{
	          		latituteField =longitudeField = "0.0";
	          		
	          	}
	              List<Address> addresses = geocoder.getFromLocation(Double.parseDouble(latituteField), Double.parseDouble(longitudeField), 4);
	              
	              Log.e("Addresses","-->"+addresses);
	              
	              if(addresses.size()>1)
	              {
	            
	              result = addresses.get(1).toString();
	              
	              
	             Address obj = addresses.get(1);
		         add = obj.getAddressLine(1);
		         String currentAddress = obj.getSubAdminArea() + ","+ obj.getAdminArea();
		         double latitude = obj.getLatitude();
		         double longitude = obj.getLongitude();
		         String currentCity= "City:  "+obj.getSubAdminArea();
		         String currentState= "state: "+obj.getAdminArea();
		      
		       UserLocationResutl = UserLocationResutl.append( "State:"+obj.getAdminArea()    +"_________");
		         // add = add + "\n" + obj.getPostalCode();
		       UserLocationResutl = UserLocationResutl.append("City:"+obj.getSubAdminArea()  +"_________");
		       UserLocationResutl = UserLocationResutl.append( "Town:"+obj.getLocality()      +"_________");
		       UserLocationResutl = UserLocationResutl.append("Country:"+obj.getCountryName()+"_________");
		       UserLocationResutl = UserLocationResutl.append("Latitude:"+obj.getLatitude()  +"_________");
		       UserLocationResutl = UserLocationResutl.append( "Longitude:"+obj.getLongitude());
		       
		        // add = add + "\n" + obj.getCountryCode();
		        // add = add + "\n" + obj.getSubThoroughfare();
	             Log.d("GPS address value", "country"+obj.getCountryName()+"country-code"+obj.getCountryCode()+"admin area"+obj.getAdminArea()+"postal code"+obj.getPostalCode()+"sub admin area"+obj.getSubAdminArea()+"locality"+obj.getLocality()); 
		        
	             
	             Log.v("IGA", "Address" + latitude+longitude+ "--------"+UserLocationResutl);
	             userLoc = String.valueOf(UserLocationResutl);
		         //HomescreenActivity.current_address = add;
	              
	              }
	              
	              else if(addresses.size()==1)
	            	  
	              {
	                result = addresses.get(0).toString();
	                
	                Address obj = addresses.get(0);
	  	          add = obj.getAddressLine(0);
	  	         String currentAddress = obj.getSubAdminArea() + ","
	  	                 + obj.getAdminArea();
	  	         double latitude = obj.getLatitude();
	  	         double longitude = obj.getLongitude();
	  	         String currentCity= obj.getSubAdminArea();
	  	         String currentState= obj.getAdminArea();
	  	        
	  	        
	  	           UserLocationResutl = UserLocationResutl.append( "State:"+obj.getAdminArea()    +"_________");
	    	         // add = add + "\n" + obj.getPostalCode();
	    	       UserLocationResutl = UserLocationResutl.append("City:"+obj.getSubAdminArea()  +"_________");
	    	       UserLocationResutl = UserLocationResutl.append( "Town:"+obj.getLocality()      +"_________");
	    	       UserLocationResutl = UserLocationResutl.append("Country:"+obj.getCountryName()+"_________");
	    	       UserLocationResutl = UserLocationResutl.append("Latitude:"+obj.getLatitude()  +"_________");
	  	           UserLocationResutl = UserLocationResutl.append( "Longitude:"+obj.getLongitude());
	  	        // add = add + "\n" + obj.getCountryCode();
	  	        // add = add + "\n" + obj.getSubThoroughfare();
	               Log.d("GPS address value", "country"+obj.getCountryName()+"country-code"+obj.getCountryCode()+"admin area"+obj.getAdminArea()+"postal code"+obj.getPostalCode()+"sub admin area"+obj.getSubAdminArea()+"locality"+obj.getLocality()); 
	  	        
	               userLoc = String.valueOf(UserLocationResutl);
	               Log.v("IGA", "Address" +latitude+longitude+ add);
	  	         
	  	        // HomescreenActivity.current_address = add;
	                
	              }
	              else
	              {
	              	userLoc = "Sorry, current place information is not available.";
	              }
	              //result=String.valueOf(addresses);
	          }
	          catch (IOException e)
	          {
	              e.printStackTrace();
	          }
	      return userLoc;
	  }
	  

	  @Override
	  protected void onPostExecute(String result) 
	  {
	      
	      super.onPostExecute(result);
	      
	      
	      //---updating database with the new entries...
	      UpdateDatabase();
	    
	  	
	  //	UpdateLocationDatabase.this.finish();
	  }
	  
	  
	}


/*public void finishMethod()
{
	
	UpdateLocationDatabase obj = new UpdateLocationDatabase();
	obj.finish();


}*/


//------=================================Dashboard items



private void StrictModePolicies() {
	
	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

    StrictMode.setThreadPolicy(policy);
	
}


/*//---activity on destroy method unregistering broadcast receiver
public void onDestroy()
  {	
	super.onDestroy();
     //  unregisterReceiver(mReceiver);
       Log.i(TAG, "broadcast UNregistred!");

  }
*/



public void UpdateDatabase() 
{

DBController dbController = new DBController(this);

//---get system data
 Date systemTime = new Date(System.currentTimeMillis());

  HashMap<String, String> queryValues =  new  HashMap<String, String>();
	
  
	queryValues.put("Time",String.valueOf(systemTime));
	
	queryValues.put("PlaceName"  ,   userLoc);
	
	queryValues.put("Latitude",   latituteField);
	
	queryValues.put("Longitude",  longitudeField);
	
	dbController.addInformationToLocationTable(queryValues);  

    System.out.println("database updated successfully111.");
    stopService(new Intent(this, UpdateLocationDatabase.class));
   // this.stopSelf();
    
}


public void turnGPSOn()
{

//---get current position using gps
location.setLatitude(latitude);

location.setLongitude(longitude);

//location = CurrentLocationvalue();
/* Intent intent = new Intent("android.location.GPS_ENABLED_CHANGE");
 intent.putExtra("enabled", true);
 sendBroadcast(intent);

String provider = Settings.Secure.getString(SnoozeActivity.this.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
if(!provider.contains("gps"))
    { 
    //if gps is disabled
    final Intent poke = new Intent();
    poke.setClassName("com.android.settings", "com.android.settings.widget.SettingsAppWidgetProvider"); 
    poke.addCategory(Intent.CATEGORY_ALTERNATIVE);
    poke.setData(Uri.parse("3")); 
    sendBroadcast(poke);
}*/
}

public void turnGPSOff()
{
/*String provider = Settings.Secure.getString(SnoozeActivity.this.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
if(provider.contains("gps")){ //if gps is enabled
    final Intent poke = new Intent();
    poke.setClassName("com.android.settings", "com.android.settings.widget.SettingsAppWidgetProvider");
    poke.addCategory(Intent.CATEGORY_ALTERNATIVE);
    poke.setData(Uri.parse("3")); 
    sendBroadcast(poke);
}*/
}


public void onLocationChanged(Location location) 
{
double lat = (double) (location.getLatitude());
double lng = (double) (location.getLongitude());
latituteField = String.valueOf(lat);
longitudeField = String.valueOf(lng);

System.out.println("latituteField--longitudeField---"+latituteField+"----"+longitudeField);
}


public void onStatusChanged(String provider, int status, Bundle extras) {


}


public void onProviderEnabled(String provider) 
{
//Toast.makeText(this, "Enabled new provider " + provider, Toast.LENGTH_SHORT).show();

}


public void onProviderDisabled(String provider) 

{

//Toast.makeText(this, "Disabled provider " + provider,Toast.LENGTH_SHORT).show();

}





	 }
