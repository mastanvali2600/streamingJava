package com.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.widget.Toast;

public class AlarmReciever extends BroadcastReceiver {
	Context context;
	@Override
	public void onReceive(Context ctx, Intent arg1) {
		PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
		PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE, "AppAlarmReceiver");
		wl.acquire(120000);
		
	
		
		Intent i = new Intent(ctx, AalService.class);
		i.setAction(AalService.ACTION_LAUNCH_ALARM);
		ctx.startService(i);
	}

}
