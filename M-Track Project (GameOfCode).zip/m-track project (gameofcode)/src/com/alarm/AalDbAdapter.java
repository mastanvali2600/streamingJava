package com.alarm;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class AalDbAdapter {
	public static final String TABLE_NAME_ALARMS = "alarms";
	
	public static final String DATABASE_NAME = "dbE6AlarmAppChooser";
	public static final int DATABASE_VERSION = 12;
	public static final String[] DATABASE_DROP =                       {
		
		"DROP TABLE IF EXISTS " + TABLE_NAME_ALARMS
		
	};
	
	
	private final Context mCtx;
	
	private static final String TAG = "AalDbAdapter";
    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    private static class DatabaseHelper extends SQLiteOpenHelper  {
        DatabaseHelper(Context context)                           {
                                          
        	super(context, DATABASE_NAME, null, DATABASE_VERSION);
        	
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
        	db.execSQL(SimplePropertyCollection.getCreateTableStatement(Item.ALARM_DEFAULTS_ALL, TABLE_NAME_ALARMS));
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            for (int i = 0; i < DATABASE_DROP.length; i++) {
        		db.execSQL(DATABASE_DROP[i]);
        	}
            onCreate(db);
        }
    }

    public AalDbAdapter(Context ctx) {
    	this.mCtx = ctx;
    }
    
    public AalDbAdapter open() {
        mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }
    
    public void close() {
        mDbHelper.close();
    }
    
    public Cursor fetchAllAlarms() {
    	return mDb.query(TABLE_NAME_ALARMS, SimplePropertyCollection.getKeyArray(Item.ALARM_DEFAULTS_LIST), null, null, null, null, Item.KEY_ROWID);
    }
    
    public Cursor fetchAllAlarmsForBackup() {
    	return mDb.query(TABLE_NAME_ALARMS, SimplePropertyCollection.getKeyArray(Item.ALARM_DEFAULTS_ALL), null, null, null, null, Item.KEY_ROWID);
    }

    public Cursor fetchEnabledAlarms() {
    	return mDb.query(TABLE_NAME_ALARMS, SimplePropertyCollection.getKeyArray(Item.ALARM_DEFAULTS_LIST), Item.KEY_ENABLED+"=1", null, null, null, Item.KEY_ROWID);
    }
    
    public Item getAlarmById(long id) {
    	if (id == 0) {
    		return new Item();
    	} 
    	
    	Cursor cur = mDb.query(TABLE_NAME_ALARMS, SimplePropertyCollection.getKeyArray(Item.ALARM_DEFAULTS_ALL), Item.KEY_ROWID+"="+id, null, null, null, Item.KEY_ROWID);
    	
    	if (cur == null) {
    		return new Item();
    	}
    	
		cur.moveToFirst();
		if (cur.isAfterLast()) {
			cur.close();
			return new Item();
		} else {
			Item ai = new Item(cur);
			cur.close();
			return ai;
		}
    }
    
    public Item getNewAlarm() {
    	return new Item();
    }
    
    public void saveAlarm(Item ai) {
    	ai.saveItem(mDb, TABLE_NAME_ALARMS, Item.KEY_ROWID);
    }
    
    public void setAlarmEnabled(long alarmId, boolean enabled) {
    	ContentValues cv = new ContentValues();
    	cv.put(Item.KEY_ENABLED, enabled);
    	mDb.update(TABLE_NAME_ALARMS, cv, Item.KEY_ROWID+"="+alarmId, null);
    }
    
    public void deleteAlarm(long alarm_id) {
    	mDb.delete(TABLE_NAME_ALARMS, Item.KEY_ROWID+"="+alarm_id, null);
    }   
    public void deleteAllAlarms() {
    	mDb.delete(TABLE_NAME_ALARMS, null, null);
    }
}
