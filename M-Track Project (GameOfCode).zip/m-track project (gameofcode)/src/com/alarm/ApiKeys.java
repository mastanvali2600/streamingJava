package com.alarm;

public interface ApiKeys {
	public static final String BITLY_API_LOGIN_AND_KEY = "&login=< bit.ly login >&apiKey=< bit.ly api key >";

}
